package com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect

data class Pt(val x: Int, val y: Int)

/** Кадр экрана: bitmap может быть шире экрана из-за выравнивания строк, поэтому w и h хранятся отдельно. */
class Frame(val bmp: android.graphics.Bitmap, val w: Int, val h: Int)

/**
 * Определение элементов интерфейса маркета без привязки к конкретному разрешению или
 * аспекту экрана — все точки находятся на лету по кадру, координат «под один телефон»
 * здесь нет.
 *
 * Кнопка «Заказать» на странице предмета и синие кнопки «Купить»/«Отмена» ищутся
 * цветовым поиском (AnchorScan) — проверено на реальных скриншотах с телефона и с ПК,
 * цвет этих кнопок одинаков на обеих платформах, меняется только положение.
 *
 * Кнопка «Заказать» ВНУТРИ модального окна «Запрос на покупку» — того же цвета, что и
 * кнопка на странице, поэтому тоже находится цветовым поиском, когда открыто окно.
 * Поле цены и крестик закрытия окна у неё нет собственного цвета (тёмно-серые на
 * тёмно-сером), поэтому их положение вычисляется как смещение от найденной кнопки —
 * соотношение подобрано по реальному скриншоту открытого окна и не зависит от
 * разрешения экрана (в отличие от прежнего варианта с фиксированными долями экрана).
 */
object Profile {
    // --- смещения элементов окна «Запрос на покупку» относительно его кнопки «Заказать», ---
    // --- в единицах ширины этой кнопки (измерено по реальному скриншоту окна) ---
    private const val PRICE_FIELD_DXW = -0.122f
    private const val PRICE_FIELD_DYW = -0.792f
    private const val CLOSE_DXW = 1.524f
    private const val CLOSE_DYW = -1.190f

    var orderBand: AnchorScan.Band? = null; private set
    var actionBand: AnchorScan.Band? = null; private set
    var dialogOrderBand: AnchorScan.Band? = null; private set

    /** Поиск кнопки «Заказать» на СТРАНИЦЕ: ищем только в правой половине экрана, где она всегда находится — это отсекает случайные совпадения цвета слева (картинка предмета, фон). */
    private fun rescanPage(f: Frame) {
        val region = Rect(f.w / 2, 0, f.w, f.h)
        val order = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5, region = region)
        orderBand = order
        actionBand = if (order != null) AnchorScan.scanBelow(f, AnchorScan.ACTION_COLOR, order, maxGapPx = (f.h * 0.22f).toInt()) else null
    }

    /** Поиск кнопки «Заказать» ВНУТРИ открытого модального окна — окно центрировано, поэтому ищем по всему кадру. */
    private fun rescanDialog(f: Frame): AnchorScan.Band? {
        val found = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5, region = null)
        if (found != null) dialogOrderBand = found
        return found ?: dialogOrderBand
    }

    /** Страница предмета: кнопка «Заказать» видна (ярко-оранжевая) в правой половине экрана. */
    fun isPage(f: Frame): Boolean {
        val b = orderBand
        if (b != null && AnchorScan.probe(f, b, AnchorScan.ORDER_COLOR)) return true
        rescanPage(f)
        return orderBand != null
    }

    /** Открыта белая панель ввода текста (клавиатура с полем цены). */
    fun isKeyboard(f: Frame): Boolean = inputBarY(f) != null

    /** Не страница и не поле ввода — считаем, что открыто модальное окно поверх страницы. */
    fun isDialog(f: Frame): Boolean = !isPage(f) && !isKeyboard(f)

    fun orderTap(f: Frame): Pt? = orderBand?.let { Pt(it.cx, it.cy) }
    fun actionTap(f: Frame): Pt? = actionBand?.let { Pt(it.cx, it.cy) }

    fun requestPriceRegion(f: Frame): Rect? = orderBand?.let { AnchorScan.priceRegionLeftOf(it) }
    fun lotPriceRegion(f: Frame): Rect? = actionBand?.let { AnchorScan.priceRegionLeftOf(it) }

    /** Кнопка «Заказать» внутри окна — её же центр одновременно и точка подтверждения. */
    fun dialogConfirmTap(f: Frame): Pt? = rescanDialog(f)?.let { Pt(it.cx, it.cy) }

    /** Поле ввода цены — смещение от найденной кнопки окна. */
    fun dialogPriceFieldTap(f: Frame): Pt? {
        val b = dialogOrderBand ?: rescanDialog(f) ?: return null
        val p = AnchorScan.offsetFrom(b, PRICE_FIELD_DXW, PRICE_FIELD_DYW)
        return Pt(p.x, p.y)
    }

    /** Крестик закрытия окна — тоже смещение от кнопки, используется только если не сработал системный «назад». */
    fun dialogCloseTap(f: Frame): Pt? {
        val b = dialogOrderBand ?: rescanDialog(f) ?: return null
        val p = AnchorScan.offsetFrom(b, CLOSE_DXW, CLOSE_DYW)
        return Pt(p.x, p.y)
    }

    fun resetDialogCache() {
        dialogOrderBand = null
    }

    /** Полный сброс всех найденных координат. Обязательно перед каждым новым запуском —
     * Profile хранится как один общий объект, и без сброса калибровка могла бы принять
     * координаты с прошлого запуска (или с другого предмета) за «уже проверено». */
    fun reset() {
        orderBand = null
        actionBand = null
        dialogOrderBand = null
    }

    fun requestHash(f: Frame): Int? = requestPriceRegion(f)?.let { regionHash(f, it) }

    fun regionHash(f: Frame, r: Rect): Int {
        var hash = 17
        var y = r.top
        while (y < r.bottom) {
            var x = r.left
            while (x < r.right) {
                val c = f.bmp.getPixel(x.coerceIn(0, f.w - 1), y.coerceIn(0, f.h - 1))
                val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                hash = hash * 31 + (lum shr 5)
                x += 2
            }
            y += 2
        }
        return hash
    }

    /** Центр белой панели ввода по вертикали в пикселях экрана, и её левый/правый край — или null, если панели нет. */
    fun inputBar(f: Frame): Triple<Int, Int, Int>? {
        val x = (f.w * 0.25f).toInt().coerceIn(0, f.w - 1)
        var first = -1
        var last = -1
        var y = 0
        while (y < f.h) {
            val c = f.bmp.getPixel(x, y)
            val white = Color.red(c) > 240 && Color.green(c) > 240 && Color.blue(c) > 240
            if (white) {
                if (first < 0) first = y
                last = y
            } else if (first >= 0 && y - last > 12) {
                break
            }
            y += 3
        }
        if (first < 0 || last - first <= f.h * 0.03f) return null
        val rowY = (first + last) / 2
        var left = -1
        var right = -1
        var xx = 0
        while (xx < f.w) {
            val c = f.bmp.getPixel(xx, rowY)
            val white = Color.red(c) > 235 && Color.green(c) > 235 && Color.blue(c) > 235
            if (white) {
                if (left < 0) left = xx
                right = xx
            }
            xx += 4
        }
        return Triple(rowY, if (left >= 0) left else 0, if (right >= 0) right else f.w - 1)
    }

    fun inputBarY(f: Frame): Int? = inputBar(f)?.first
}
