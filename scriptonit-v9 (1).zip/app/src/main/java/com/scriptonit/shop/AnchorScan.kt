package com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs

/**
 * Поиск элементов интерфейса по цвету, без привязки к конкретному разрешению или
 * раскладке экрана. Кнопка «Заказать» и синие кнопки «Купить»/«Отмена» в Standoff 2
 * имеют один и тот же цвет независимо от размера окна — меняется только их положение
 * и масштаб. Находит САМОЕ БОЛЬШОЕ СВЯЗНОЕ пятно нужного цвета (не просто границы
 * всех подходящих точек), поэтому не путает кнопку с случайными похожими пикселями
 * в другом месте экрана — это проверено на реальных скриншотах из разных мест игры.
 */
object AnchorScan {
    data class Band(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
        val w get() = x1 - x0
        val h get() = y1 - y0
        val cx get() = (x0 + x1) / 2
        val cy get() = (y0 + y1) / 2
    }

    val ORDER_COLOR = Triple(242, 163, 52)   // кнопка «Заказать»
    val ACTION_COLOR = Triple(131, 154, 202) // кнопки «Купить» / «Отмена»
    private const val TOL = 46

    private fun matches(c: Int, t: Triple<Int, Int, Int>): Boolean {
        val d = abs(Color.red(c) - t.first) + abs(Color.green(c) - t.second) + abs(Color.blue(c) - t.third)
        return d < TOL
    }

    /**
     * Ищет самый большой сплошной блок нужного цвета в кадре (или в заданной области).
     * step — шаг выборки пикселей (производительность), region — куда смотреть (null = весь кадр).
     */
    fun scan(frame: Frame, target: Triple<Int, Int, Int>, step: Int = 5, region: Rect? = null): Band? {
        val bmp = frame.bmp
        val rx0 = (region?.left ?: 0).coerceIn(0, frame.w - 1)
        val ry0 = (region?.top ?: 0).coerceIn(0, frame.h - 1)
        val rx1 = (region?.right ?: frame.w).coerceIn(rx0 + 1, frame.w)
        val ry1 = (region?.bottom ?: frame.h).coerceIn(ry0 + 1, frame.h)

        // шаг 1: собираем ячейки сетки (gx,gy), где нашёлся подходящий пиксель
        val cells = HashSet<Long>()
        fun key(gx: Int, gy: Int) = (gx.toLong() shl 20) or (gy.toLong() and 0xFFFFF)
        var y = ry0
        while (y < ry1) {
            var x = rx0
            while (x < rx1) {
                if (matches(bmp.getPixel(x, y), target)) cells.add(key(x / step, y / step))
                x += step
            }
            y += step
        }
        if (cells.size < 6) return null

        // шаг 2: ищем самую большую связную группу ячеек (соседние по сетке, с запасом в 1 ячейку на разрывы)
        val visited = HashSet<Long>()
        var bestSize = 0
        var bestMinGx = 0; var bestMinGy = 0; var bestMaxGx = 0; var bestMaxGy = 0
        for (start in cells) {
            if (start in visited) continue
            val stack = ArrayDeque<Long>()
            stack.addLast(start); visited.add(start)
            var size = 0
            var minGx = Int.MAX_VALUE; var minGy = Int.MAX_VALUE; var maxGx = Int.MIN_VALUE; var maxGy = Int.MIN_VALUE
            while (stack.isNotEmpty()) {
                val c = stack.removeLast()
                val gx = (c shr 20).toInt()
                val gy = (c and 0xFFFFF).toInt()
                size++
                if (gx < minGx) minGx = gx
                if (gx > maxGx) maxGx = gx
                if (gy < minGy) minGy = gy
                if (gy > maxGy) maxGy = gy
                for (dx in -2..2) for (dy in -2..2) {
                    val n = key(gx + dx, gy + dy)
                    if (n in cells && n !in visited) {
                        visited.add(n); stack.addLast(n)
                    }
                }
            }
            if (size > bestSize) {
                bestSize = size; bestMinGx = minGx; bestMinGy = minGy; bestMaxGx = maxGx; bestMaxGy = maxGy
            }
        }
        if (bestSize < 6) return null

        val x0 = bestMinGx * step
        val y0 = bestMinGy * step
        val x1 = bestMaxGx * step
        val y1 = bestMaxGy * step
        val w = x1 - x0
        val h = y1 - y0
        if (w < frame.w * 0.025f || w > frame.w * 0.38f) return null
        if (h < frame.h * 0.01f || h > frame.h * 0.2f) return null
        return Band(x0, y0, x1, y1)
    }

    /** Кнопка такого же вида сразу под указанной (тот же цвет, похожая ширина, ниже по кадру). */
    fun scanBelow(frame: Frame, target: Triple<Int, Int, Int>, above: Band, maxGapPx: Int, step: Int = 5): Band? {
        val pad = above.w / 6
        val region = Rect(above.x0 - pad, above.y1, above.x1 + pad, (above.y1 + maxGapPx).coerceAtMost(frame.h))
        return scan(frame, target, step, region)
    }

    fun probe(frame: Frame, band: Band, target: Triple<Int, Int, Int>): Boolean =
        band.cx in 0 until frame.w && band.cy in 0 until frame.h && matches(frame.bmp.getPixel(band.cx, band.cy), target)

    /** Полоса с ценой слева от кнопки: соотношение выведено из реальных скриншотов игры и не зависит от разрешения. */
    fun priceRegionLeftOf(button: Band): Rect {
        val l = (button.x0 - button.w * 0.58f).toInt()
        val r = (button.x0 - button.w * 0.03f).toInt()
        return Rect(l.coerceAtLeast(0), button.y0, r.coerceAtLeast(l + 10), button.y1)
    }

    /** Точка со смещением (dxW, dyW) от центра band, в единицах ширины band — не зависит от разрешения. */
    fun offsetFrom(band: Band, dxW: Float, dyW: Float): android.graphics.Point =
        android.graphics.Point((band.cx + dxW * band.w).toInt(), (band.cy + dyW * band.w).toInt())
}
