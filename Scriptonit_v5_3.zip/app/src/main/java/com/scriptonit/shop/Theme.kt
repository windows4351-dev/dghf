package com.scriptonit.shop

import android.content.Context

/** Цветовая схема приложения и панели. */
class Palette(
    val id: String,
    val name: String,
    val dot: Int,        // цвет кружка в выборе темы
    val bg0: Int,        // фон экрана (верх)
    val bg1: Int,        // фон экрана (низ)
    val card0: Int,      // карточка (верх)
    val card1: Int,      // карточка (низ)
    val stroke: Int,     // рамка карточек
    val accent: Int,     // основной акцент
    val accent2: Int,    // второй цвет градиента кнопок
    val onAccent: Int,   // текст на акценте
    val text: Int,
    val dim: Int,
    val field: Int,      // фон полей ввода
    val warn: Int,
    val ok: Int
)

object Themes {
    private const val P = "scriptonit"
    private fun c(v: Long) = v.toInt()

    val emerald = Palette(
        "emerald", "Изумруд", c(0xFF10B981),
        c(0xFF020E09), c(0xFF05231A), c(0xFF0B3A2A), c(0xFF072A1E), c(0xFF13694B),
        c(0xFF10B981), c(0xFF34D399), c(0xFF01130B), c(0xFFE8FFF4), c(0xFF7FB9A0), c(0xFF030F0A),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val night = Palette(
        "night", "Ночь", c(0xFF5B6CFF),
        c(0xFF050A18), c(0xFF0B1431), c(0xFF15234A), c(0xFF0E1832), c(0xFF25366E),
        c(0xFF4D7CFF), c(0xFF7A5CFF), c(0xFFFFFFFF), c(0xFFEAF0FF), c(0xFF8795C4), c(0xFF060C1E),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val ice = Palette(
        "ice", "Лёд", c(0xFF22B8F0),
        c(0xFF04121A), c(0xFF08202E), c(0xFF0F3144), c(0xFF0A2130), c(0xFF1C5470),
        c(0xFF1FB6FF), c(0xFF2D7BFF), c(0xFF031018), c(0xFFE6F8FF), c(0xFF7FAFC6), c(0xFF051722),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val violet = Palette(
        "violet", "Фиолет", c(0xFFB25CFF),
        c(0xFF0A0612), c(0xFF130B24), c(0xFF231742), c(0xFF170F2D), c(0xFF3F2D7A),
        c(0xFFA24BFF), c(0xFFEC4DFF), c(0xFFFFFFFF), c(0xFFF3EBFF), c(0xFF9C8BC9), c(0xFF0B0716),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val blood = Palette(
        "blood", "Кровь", c(0xFFFF7A18),
        c(0xFF100605), c(0xFF1E0B08), c(0xFF321512), c(0xFF210E0B), c(0xFF5C2A1D),
        c(0xFFFF7A18), c(0xFFFF3D2E), c(0xFF1A0A02), c(0xFFFFEDE6), c(0xFFC99A8B), c(0xFF120807),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val neon = Palette(
        "neon", "Неон", c(0xFF10D9A0),
        c(0xFF030D0B), c(0xFF07201A), c(0xFF0D3328), c(0xFF08221B), c(0xFF146B52),
        c(0xFF10D9A0), c(0xFF22E0FF), c(0xFF02140F), c(0xFFE4FFF6), c(0xFF78B8A4), c(0xFF041410),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )

    val all = listOf(emerald, night, ice, violet, blood, neon)

    fun current(ctx: Context): Palette {
        val id = ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getString("theme", "emerald")
        return all.firstOrNull { it.id == id } ?: emerald
    }

    fun set(ctx: Context, id: String) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("theme", id).apply()
    }

    fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
}
