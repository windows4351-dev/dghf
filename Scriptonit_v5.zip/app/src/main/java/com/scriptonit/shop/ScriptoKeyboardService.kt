package com.scriptonit.shop

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

/**
 * Собственная клавиатура. В числовых полях показывает крупный цифровой блок.
 * Бот вводит цену напрямую через replaceText(), без тапов по клавишам.
 */
class ScriptoKeyboardService : InputMethodService() {

    companion object {
        @Volatile
        var instance: ScriptoKeyboardService? = null
    }

    private var russian = false
    private var shift = false
    private var numeric = false
    private lateinit var container: LinearLayout

    private val en = listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val ru = listOf("1234567890", "йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** В альбомной ориентации Android по умолчанию растягивает клавиатуру на весь экран. Отключаем. */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Themes.current(this@ScriptoKeyboardService).bg0)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        render()
        return container
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        if (::container.isInitialized) render()
    }

    /** Полностью заменяет текст в поле. Вызывать на главном потоке. */
    fun replaceText(text: String): Boolean {
        val ic = currentInputConnection ?: return false
        ic.beginBatchEdit()
        ic.performContextMenuAction(android.R.id.selectAll)
        ic.commitText("", 1)
        ic.deleteSurroundingText(64, 64)
        ic.commitText(text, 1)
        ic.endBatchEdit()
        return true
    }

    /** Подтверждает ввод (аналог «Готово»). Вызывать на главном потоке. */
    fun done(): Boolean {
        val ic = currentInputConnection ?: return false
        ic.performEditorAction(EditorInfo.IME_ACTION_DONE)
        return true
    }

    private fun key(
        label: String,
        weight: Float = 1f,
        accent: Boolean = false,
        height: Int = 46,
        size: Float = 17f,
        onClick: () -> Unit
    ): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = size
        typeface = Typeface.DEFAULT_BOLD
        minWidth = 0
        minimumWidth = 0
        setPadding(0, 0, 0, 0)
        setTextColor(if (accent) Themes.current(this@ScriptoKeyboardService).onAccent else Themes.current(this@ScriptoKeyboardService).text)
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (accent) Themes.current(this@ScriptoKeyboardService).accent else Themes.current(this@ScriptoKeyboardService).card0)
        }
        layoutParams = LinearLayout.LayoutParams(0, dp(height), weight).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
        }
        setOnClickListener { onClick() }
    }

    private fun row(vararg keys: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        keys.forEach { addView(it) }
    }

    private fun type(ch: String) {
        currentInputConnection?.commitText(if (shift) ch.uppercase() else ch, 1)
        if (shift) {
            shift = false
            render()
        }
    }

    private fun render() {
        container.removeAllViews()
        if (BotPrefs.flag(this, "kb_hidden", false)) {
            // «невидимая клавиатура»: на экране остаётся только поле ввода игры, цифры вставляются командой
            container.setBackgroundColor(0)
            container.setPadding(0, 0, 0, 0)
            container.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, 1) })
            return
        }
        if (numeric) renderNumeric() else renderText()
    }

    private fun renderNumeric() {
        val h = 34
        val s = 20f
        fun digits(a: String, b: String, c: String, side: Button) = row(
            key(a, height = h, size = s) { type(a) },
            key(b, height = h, size = s) { type(b) },
            key(c, height = h, size = s) { type(c) },
            side
        )
        container.addView(digits("1", "2", "3", key("−", height = h, size = s) { type("-") }))
        container.addView(digits("4", "5", "6", key("␣", height = h, size = s) { currentInputConnection?.commitText(" ", 1) }))
        container.addView(digits("7", "8", "9", key("⌫", height = h, size = s) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) }))
        container.addView(
            row(
                key(",", height = h, size = s) { type(",") },
                key("0", height = h, size = s) { type("0") },
                key(".", height = h, size = s) { type(".") },
                key("✓", accent = true, height = h, size = s) { done() }
            )
        )
    }

    private fun renderText() {
        val layout = if (russian) ru else en
        for (line in layout) {
            val keys = line.map { c ->
                val s = c.toString()
                key(if (shift) s.uppercase() else s) { type(s) }
            }
            container.addView(row(*keys.toTypedArray()))
        }
        container.addView(
            row(
                key(if (shift) "⇧" else "⬆", 1.3f, accent = shift) { shift = !shift; render() },
                key(if (russian) "RU" else "EN", 1.3f) { russian = !russian; render() },
                key(",") { type(",") },
                key("пробел", 4f) { currentInputConnection?.commitText(" ", 1) },
                key(".") { type(".") },
                key("⌫", 1.3f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) },
                key("⏎", 1.3f, accent = true) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) }
            )
        )
    }
}
