package com.scriptonit.shop

import android.accessibilityservice.AccessibilityService
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.util.Locale
import kotlin.math.abs

data class BotConfig(
    val min: Double,
    val max: Double,
    val step: Double,
    val gap: Double,
    val cancelDelayMs: Long,
    val refreshMs: Long,
    val maxMinutes: Int,
    val maxBids: Int,
    val aggressive: Boolean,
    val matchEqual: Boolean
)

object BotPrefs {
    private const val P = "bot"

    fun raw(c: Context, key: String, def: String): String =
        c.getSharedPreferences(P, Context.MODE_PRIVATE).getString(key, null) ?: def

    fun save(c: Context, values: Map<String, String>) {
        val e = c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }

    fun load(c: Context): BotConfig {
        fun d(k: String, def: String) = raw(c, k, def).replace(',', '.').toDoubleOrNull() ?: def.toDouble()
        return BotConfig(
            min = d("min", "10"),
            max = d("max", "99999"),
            step = d("step", "0.01").coerceAtLeast(0.01),
            gap = d("gap2", "0.01").coerceAtLeast(0.01),
            cancelDelayMs = (d("cancel", "2") * 1000).toLong().coerceAtLeast(0),
            refreshMs = (d("refresh", "5") * 1000).toLong().coerceAtLeast(2000),
            maxMinutes = d("minutes", "119").toInt().coerceAtLeast(1),
            maxBids = d("bids", "300").toInt().coerceAtLeast(1),
            aggressive = raw(c, "aggr", "0") == "1",
            matchEqual = raw(c, "equal", "1") == "1"
        )
    }
}

/**
 * Встроенная логика перебива запросов. Координаты кнопок и областей цен определяются
 * динамически по цвету (Profile/AnchorScan), а не по фиксированным пикселям, поэтому
 * работает на разных экранах и раскладках без ручной калибровки под каждое устройство.
 *
 * Цикл: на странице предмета ищем кнопку «Заказать» и первую синюю кнопку под ней —
 * это «Отмена» (если наш запрос уже стоит) или «Купить» первого лота (если нет).
 * Читаем цену лота и верхнего запроса, запоминаем их, открываем поле ввода и остаёмся
 * там. Пока запрос не растёт, ничего не делаем. Как только он вырос — мгновенно ставим
 * цену (см. chooseBid), подтверждаем и через cancelDelayMs отменяем свой запрос.
 * Раз в refreshMs выходим на страницу и заново запоминаем лот и запрос.
 */
class MarketBot(
    private val svc: ClickService,
    private val grab: ScreenGrabber,
    private val ocr: Ocr,
    private val cfg: BotConfig,
    private val onBid: () -> Unit,
    private val log: (String) -> Unit
) {
    private enum class Screen { PAGE, DIALOG, KEYBOARD, UNKNOWN }

    private var fw = 1
    private var fh = 1

    private var lot: Double? = null
    private var req: Double? = null
    private var baseReq: Double? = null
    private var refreshedAt = 0L
    private var needRefresh = true
    private var firstRefresh = true
    private var inHold = false
    private var lastHash = 0
    private var lastOcrAt = 0L
    private var lowCount = 0
    private var bids = 0
    private var noActionCount = 0

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun round2(v: Double) = Math.round(v * 100.0) / 100.0

    private fun track(f: Frame) {
        fw = f.w
        fh = f.h
    }

    private fun screenOf(f: Frame) = when {
        Profile.isKeyboard(f) -> Screen.KEYBOARD
        Profile.isPage(f) -> Screen.PAGE
        else -> Screen.DIALOG
    }

    private suspend fun tap(p: Pt) {
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), 30)
        delay(15)
    }

    private suspend fun waitFor(timeoutMs: Long, cond: (Frame) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (cond(f)) return true
            }
            delay(8)
        }
        return false
    }

    private suspend fun typeText(text: String): Boolean =
        withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.replaceText(text) == true }

    private suspend fun imeDone() {
        val ok = withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.done() == true }
        if (!ok) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    /** Закрывает поле ввода через действие IME; если поле его игнорирует, жмёт кнопку в правом краю найденной белой панели. */
    private suspend fun closeKeyboard(): Boolean {
        imeDone()
        if (waitFor(600) { !Profile.isKeyboard(it) }) return true
        val f = grab.frame() ?: return false
        track(f)
        val bar = Profile.inputBar(f) ?: return false
        val (rowY, _, right) = bar
        tap(Pt((right - (right - bar.second) * 0.06f).toInt(), rowY))
        return waitFor(700) { !Profile.isKeyboard(it) }
    }

    /** Открывает окно, находит в нём кнопку «Заказать» по цвету и тапает поле цены как смещение от неё. */
    private suspend fun enterHold(price: Double): Boolean {
        val order = Profile.orderTap(grab.frame() ?: return false) ?: return false
        Profile.resetDialogCache()
        tap(order)
        // ловим момент, пока окно ещё не затемнило свою кнопку клавиатурой — тогда проще всего найти её по цвету
        var priceTap: Pt? = null
        val end = System.currentTimeMillis() + 1500
        while (System.currentTimeMillis() < end && priceTap == null) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                priceTap = Profile.dialogPriceFieldTap(f)
            }
            delay(10)
        }
        if (priceTap == null) return false
        tap(priceTap)
        if (!waitFor(1500) { Profile.isKeyboard(it) }) return false
        delay(40)
        if (!typeText(fmt(price))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return false
        }
        inHold = true
        lastHash = 0
        lastOcrAt = 0
        return true
    }

    /** Закрывает окно: сперва обычная кнопка «Назад», и только если это не помогло — крестик по смещению. */
    private suspend fun exitHold() {
        closeKeyboard()
        svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        if (!waitFor(500) { Profile.isPage(it) }) {
            val f = grab.frame()
            val close = f?.let { Profile.dialogCloseTap(it) }
            if (close != null) tap(close)
            waitFor(1200) { Profile.isPage(it) }
        }
        inHold = false
    }

    /** Одно полное обновление: страница, галочка «Мои запросы», чтение цен через найденные кнопки. */
    private suspend fun refreshPage(): Boolean {
        var prevR: Double? = null
        var prevL: Double? = null
        val end = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f == null) { delay(8); continue }
            track(f)
            if (!Profile.isPage(f)) { delay(20); continue }
            val rr = Profile.requestPriceRegion(f)
            val lr = Profile.lotPriceRegion(f)
            if (rr == null || lr == null) {
                if (rr != null && lr == null) {
                    noActionCount++
                    if (noActionCount == 40) log("Не вижу кнопку «Купить» — проверь, не включена ли галочка «Только мои запросы»")
                } else {
                    noActionCount = 0
                }
                delay(20); continue
            }
            noActionCount = 0
            val r = ocr.readPrice(f, rr)
            val l = ocr.readPrice(f, lr)
            if (r != null && l != null) {
                if (prevR != null && prevL != null && abs(prevR - r) < 0.001 && abs(prevL - l) < 0.001) {
                    req = r
                    lot = l
                    refreshedAt = System.currentTimeMillis()
                    log("Лот ${fmt(l)} · запрос ${fmt(r)}")
                    return true
                }
                prevR = r
                prevL = l
            }
            delay(20)
        }
        return false
    }

    /**
     * Цена ставки. Потолок = запомненный лот минус gap, поэтому ставка не может
     * сравняться с лотом или превысить его (защита от фуллпрайса).
     * Обычно: r + шаг. Если на шаг перебить уже нельзя, а r сам ниже потолка —
     * при включённом «Нельзя перебить на шаг» ставим ровно r (тот же запрос).
     * «Агрессивно» сразу ставит на потолок (копейка ниже лота).
     */
    private fun chooseBid(r: Double): Double? {
        val l = lot ?: return null
        if (l < cfg.min || l > cfg.max) return null
        val ceiling = round2(l - cfg.gap)
        val outbid = round2(r + cfg.step)
        val bid = when {
            outbid <= ceiling -> if (cfg.aggressive) ceiling else outbid
            cfg.matchEqual && r <= ceiling -> round2(r)
            else -> return null
        }
        return if (bid > cfg.max) null else bid
    }

    private suspend fun bidFromHold(bid: Double) {
        inHold = false
        needRefresh = true
        baseReq = null
        if (!typeText(fmt(bid))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return
        }
        if (!closeKeyboard()) return
        if (!waitFor(800) { Profile.isDialog(it) }) return
        val confirm = grab.frame()?.let { Profile.dialogConfirmTap(it) }
        if (confirm != null) tap(confirm) else { log("Не нашёл кнопку «Заказать» в окне"); return }
        bids++
        onBid()
        log("#$bids: ${fmt(bid)} G · лот ${fmt(lot ?: 0.0)}")
        if (cfg.cancelDelayMs > 0) {
            delay(cfg.cancelDelayMs)
            cancelOwnRequest(bid)
        }
        waitFor(1500) { Profile.isPage(it) }
    }

    /**
     * Нажимает «Отмена» на нашей строке запроса. Если после этого в той же строке
     * всё ещё видна НАША цена bid — значит отмена не прошла (лаг сети, промах),
     * пробует ещё раз, чтобы бот не принял собственный незакрытый запрос за лот
     * и не начал бы торговаться сам с собой.
     */
    private suspend fun cancelOwnRequest(bid: Double, attempt: Int = 0) {
        if (attempt >= 3) { log("Не удалось отменить запрос $attempt-й попыткой, проверь вручную"); return }
        val f0 = grab.frame() ?: return
        track(f0)
        val action = Profile.actionTap(f0) ?: return
        tap(action)
        delay(350)
        val f1 = grab.frame() ?: return
        track(f1)
        val lr = Profile.lotPriceRegion(f1) ?: return
        val still = ocr.readPrice(f1, lr)
        if (still != null && Math.abs(still - bid) < 0.001) {
            cancelOwnRequest(bid, attempt + 1)
        }
    }

    private suspend fun pageTick() {
        inHold = false
        val now = System.currentTimeMillis()
        if (needRefresh || now - refreshedAt >= cfg.refreshMs) {
            if (!refreshPage()) { delay(100); return }
            needRefresh = false
            firstRefresh = false
            val r = req ?: return
            val base = baseReq
            baseReq = r
            if (base != null && r > base + 0.001) {
                val bid = chooseBid(r)
                if (bid != null) {
                    if (enterHold(bid)) bidFromHold(bid)
                    return
                }
                log("Пропуск: запрос ${fmt(r)} вплотную к лоту ${fmt(lot ?: 0.0)}")
            }
        }
        val r = baseReq ?: req ?: return
        val bid = chooseBid(r) ?: round2(r + cfg.step)
        if (!enterHold(bid)) delay(150)
    }

    private suspend fun holdTick(f: Frame?) {
        val now = System.currentTimeMillis()
        if (now - refreshedAt >= cfg.refreshMs) {
            exitHold()
            needRefresh = true
            return
        }
        if (f == null) return
        val region = Profile.requestPriceRegion(f) ?: return
        val hash = Profile.regionHash(f, region)
        if (hash == lastHash && now - lastOcrAt < 600) return
        lastHash = hash
        lastOcrAt = now
        val r = ocr.readPrice(f, region) ?: return
        val base = baseReq
        if (base == null) {
            baseReq = r
            return
        }
        if (r > base + 0.001) {
            baseReq = r
            lowCount = 0
            val bid = chooseBid(r)
            if (bid != null) {
                bidFromHold(bid)
            } else {
                log("Пропуск: запрос ${fmt(r)} вплотную к лоту ${fmt(lot ?: 0.0)}")
            }
        } else if (r < base - 0.001) {
            lowCount++
            if (lowCount >= 2) { baseReq = r; lowCount = 0 }
        } else {
            lowCount = 0
        }
    }


    /**
     * Перед началом торговли до 10 секунд ищет и проверяет все нужные кнопки:
     * сперва «Заказать» и «Купить»/«Отмена» на странице, затем один раз открывает
     * окно «Запрос на покупку», чтобы найти кнопку внутри него — и сразу закрывает
     * окно обратно, ничего не вводя и не отправляя. Торговля начинается только
     * после успешной проверки.
     */
    private suspend fun calibrate(): Boolean {
        log("Калибровка: ищу кнопки на странице…")
        val pageStart = System.currentTimeMillis()
        var pageOk = false
        while (System.currentTimeMillis() - pageStart < 10_000) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (Profile.isPage(f) && Profile.actionBand != null) { pageOk = true; break }
            }
            delay(60)
        }
        if (!pageOk) {
            log("Не нашёл кнопки «Заказать»/«Купить» — открой страницу предмета в маркете")
            return false
        }
        log("Кнопки страницы найдены ✓ проверяю окно запроса…")

        val order = grab.frame()?.let { Profile.orderTap(it) } ?: return false
        Profile.resetDialogCache()
        tap(order)
        var dialogOk = false
        val dialogEnd = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < dialogEnd) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (Profile.dialogPriceFieldTap(f) != null) { dialogOk = true; break }
            }
            delay(20)
        }
        // закрываем пробное окно — калибровка ничего не вводит и не отправляет
        svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        waitFor(1200) { Profile.isPage(it) }

        if (!dialogOk) {
            log("Не нашёл кнопку в окне запроса — проверь вручную и перезапусти")
            return false
        }
        log("Калибровка пройдена ✓ начинаю торговать")
        return true
    }

    suspend fun run() {
        val start = System.currentTimeMillis()
        val limitMs = cfg.maxMinutes * 60_000L
        var screen = Screen.UNKNOWN
        var lost = 0
        if (!calibrate()) return

        while (true) {
            yield()
            if (System.currentTimeMillis() - start >= limitMs) { log("Время работы вышло"); break }
            if (bids >= cfg.maxBids) { log("Лимит ставок: $bids"); break }

            val f = grab.frame()
            if (f != null) {
                track(f)
                screen = screenOf(f)
            }

            when (screen) {
                Screen.KEYBOARD -> {
                    lost = 0
                    if (inHold) holdTick(f) else { exitHold(); needRefresh = true }
                }
                Screen.PAGE -> {
                    lost = 0
                    pageTick()
                }
                Screen.DIALOG -> {
                    // неожиданное окно (не мы его открывали) — закрываем и пробуем снова с чистой страницы
                    lost = 0
                    inHold = false
                    svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                    delay(350)
                }
                Screen.UNKNOWN -> {
                    lost++
                    if (lost > 400) { log("Открой страницу предмета в маркете"); break }
                    delay(15)
                }
            }
            delay(4)
        }
    }
}
