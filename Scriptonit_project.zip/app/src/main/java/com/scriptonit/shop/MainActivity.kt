package com.scriptonit.shop

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private val bg = 0xFF060D09.toInt()
    private val card = 0xFF0C1811.toInt()
    private val line = 0xFF1A3626.toInt()
    private val green = 0xFF22C55E.toInt()
    private val textMain = 0xFFE6FFEE.toInt()
    private val textDim = 0xFF7FA38C.toInt()

    private lateinit var dotOverlay: TextView
    private lateinit var dotAccess: TextView
    private lateinit var dotKbOn: TextView
    private lateinit var dotKbDefault: TextView
    private lateinit var dotOcr: TextView
    private lateinit var ocrAction: Button
    private lateinit var modeView: TextView
    private lateinit var prepTitle: TextView
    private lateinit var modeDesc: TextView
    private lateinit var segAggr: Button
    private lateinit var segBal: Button
    private lateinit var screenView: TextView
    private lateinit var statBids: TextView
    private lateinit var statSnake: TextView
    private val fields = LinkedHashMap<String, EditText>()
    private val switches = LinkedHashMap<String, Switch>()
    private var ocrLoading = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.init(this)
        if (!License.DEV_SKIP_LICENSE && !License.isActivatedLocally(this)) {
            startActivity(Intent(this, ActivationActivity::class.java))
            finish()
            return
        }
        Store.ensureDemo(this)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        loadOcrData()
        if (!License.DEV_SKIP_LICENSE) recheckLicense()
    }

    /** Раз в сутки на старте приложения тихо сверяет ключ с сервером; при отзыве — на экран активации. */
    private fun recheckLicense() {
        val sp = getSharedPreferences("license_check", MODE_PRIVATE)
        val last = sp.getLong("at", 0)
        if (System.currentTimeMillis() - last < 24 * 60 * 60 * 1000L) return
        Thread {
            val ok = License.verifySaved(this)
            sp.edit().putLong("at", System.currentTimeMillis()).apply()
            if (!ok) runOnUiThread {
                License.clear(this)
                toast("Ключ больше не действителен")
                startActivity(Intent(this, ActivationActivity::class.java))
                finish()
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- интерфейс ----------

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun cardBg() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF122A1D.toInt(), 0xFF0A150F.toInt())
    ).apply {
        cornerRadius = dp(22).toFloat()
        setStroke(dp(1), 0xFF1F4A31.toInt())
    }

    private fun sectionTitle(s: String): TextView = label(s, 12f, 0xFF4ADE80.toInt(), true).apply {
        letterSpacing = 0.14f
        setPadding(0, 0, 0, dp(8))
    }

    private fun cardView(title: String?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(14), dp(16), dp(10))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) }
        if (title != null) addView(sectionTitle(title))
    }

    private fun smallBtn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 13f
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setTextColor(green)
        background = rounded(0xFF10241A.toInt(), 0xFF1F7A45.toInt(), 12)
        setOnClickListener { onClick() }
    }

    private fun wideBtn(text: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) 0xFF03130A.toInt() else textMain)
        background = if (primary) {
            GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF16A34A.toInt(), 0xFF34D399.toInt(), 0xFF22D3EE.toInt())
            ).apply { cornerRadius = dp(18).toFloat() }
        } else {
            rounded(0xFF10241A.toInt(), 0xFF1F7A45.toInt(), 16)
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    /** Строка шага: индикатор, название, кнопка действия. */
    private fun step(parent: LinearLayout, title: String, action: Button): TextView {
        val dot = label("○", 20f, textDim).apply { setPadding(0, 0, dp(12), 0) }
        val name = label(title, 15f, textMain).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        parent.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            addView(dot)
            addView(name)
            addView(action)
        })
        return dot
    }

    private fun field(key: String, hint: String, def: String): EditText = EditText(this).apply {
        setText(BotPrefs.raw(this@MainActivity, key, def))
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setTextColor(textMain)
        setHintTextColor(textDim)
        textSize = 15f
        background = rounded(0xFF08130C.toInt(), line, 12)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        fields[key] = this
    }

    private fun toggle(key: String, title: String, def: Boolean): Switch = Switch(this).apply {
        text = title
        textSize = 14f
        setTextColor(textMain)
        setPadding(dp(4), dp(8), dp(4), dp(4))
        isChecked = BotPrefs.raw(this@MainActivity, key, if (def) "1" else "0") == "1"
        switches[key] = this
    }

    private fun labeled(title: String, et: EditText): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        addView(label(title, 12f, textDim))
        addView(et)
    }

    private fun pair(a: LinearLayout, b: LinearLayout) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a)
        addView(b)
    }

    private fun statCard(title: String, value: TextView): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(12), dp(16), dp(12))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(4), dp(10), dp(4), 0)
        }
        addView(label(title, 12f, textDim))
        addView(value)
    }

    private fun segBtn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(8), dp(12), dp(8), dp(12))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(3), 0, dp(3), 0)
        }
        setOnClickListener { onClick() }
    }

    private fun styleSeg(b: Button, on: Boolean) {
        b.setTextColor(if (on) 0xFF03130A.toInt() else textMain)
        b.background = if (on) {
            GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF16A34A.toInt(), 0xFF34D399.toInt())
            ).apply { cornerRadius = dp(14).toFloat() }
        } else {
            rounded(0xFF0B1A12.toInt(), 0xFF1F4A31.toInt(), 14)
        }
    }

    private fun applyAggr(on: Boolean) {
        switches["aggr"]?.isChecked = on
        styleSeg(segAggr, on)
        styleSeg(segBal, !on)
        modeDesc.text = if (on) {
            "Как только запрос вырос — сразу ставит на копейку ниже первого лота."
        } else {
            "Перебивает новый запрос ровно на копейку. Если до лота не хватает места — ставит на копейку ниже первого лота."
        }
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(32))
        }

        // шапка
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_fg)
                layoutParams = LinearLayout.LayoutParams(dp(76), dp(76)).apply { rightMargin = dp(10) }
            })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(label("Scriptonit", 26f, textMain, true))
                addView(label("автоматический перебив запросов на рынке", 13f, 0xFF4ADE80.toInt()))
            })
        })

        statBids = label("0", 28f, green, true)
        statSnake = label("0", 28f, green, true)
        col.addView(pair(statCard("Ставок всего", statBids), statCard("Рекорд змейки", statSnake)))

        // подготовка
        val prep = cardView(null)
        prepTitle = sectionTitle("ПОДГОТОВКА")
        prep.addView(prepTitle)
        dotOverlay = step(prep, "Поверх других окон", smallBtn("Разрешить") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        dotAccess = step(prep, "Служба доступности", smallBtn("Включить") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Найди Scriptonit и включи")
        })
        dotKbOn = step(prep, "Клавиатура Scriptonit", smallBtn("Включить") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        dotKbDefault = step(prep, "Клавиатура по умолчанию", smallBtn("Выбрать") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        ocrAction = smallBtn("Скачать") { loadOcrData() }
        dotOcr = step(prep, "Распознавание цен и надписей", ocrAction)
        prep.addView(label("Запись экрана запросится при запуске.", 12f, textDim).apply { setPadding(0, dp(4), 0, dp(4)) })
        col.addView(prep)

        // стратегия
        val strat = cardView("СТРАТЕГИЯ")
        segAggr = segBtn("Агрессивный") { applyAggr(true) }
        segBal = segBtn("Сбалансированный") { applyAggr(false) }
        strat.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(segBal)
            addView(segAggr)
        })
        modeDesc = label("", 13f, textDim).apply { setPadding(dp(4), dp(10), dp(4), dp(6)) }
        strat.addView(modeDesc)
        toggle("aggr", "", false) // хранит выбор (не показывается), сохраняется вместе с остальными настройками
        applyAggr(switches["aggr"]?.isChecked == true)
        col.addView(strat)

        // рынок
        val market = cardView("РЫНОК")
        market.addView(pair(labeled("Цена от, G", field("min", "10", "10")), labeled("Цена до, G", field("max", "99999", "99999"))))
        market.addView(pair(labeled("Обновление, с", field("refresh", "5", "5")), labeled("Отмена через, с", field("cancel", "2", "2"))))
        market.addView(pair(labeled("Работать, мин", field("minutes", "119", "119")), labeled("Лимит ставок", field("bids", "300", "300"))))
        screenView = label("", 12f, textDim).apply { setPadding(dp(4), dp(8), 0, dp(4)) }
        market.addView(screenView)
        col.addView(market)

        // режим и скрипты
        val mode = cardView("ИСТОЧНИК")
        modeView = label("", 15f, textMain).apply { setPadding(0, 0, 0, dp(4)) }
        mode.addView(modeView)
        mode.addView(wideBtn("Маркет") { Store.setMarket(this@MainActivity); refresh() })
        mode.addView(wideBtn("Свой скрипт") { pickScript() })
        mode.addView(wideBtn("Импорт из файла") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }, 1
            )
        })
        mode.addView(wideBtn("Загрузить по ссылке") { askUrl() })
        col.addView(mode)

        val extras = cardView("ПЛЮШКИ")
        extras.addView(wideBtn("🐍  Змейка") { startActivity(Intent(this, SnakeActivity::class.java)) })
        col.addView(extras)

        val diag = cardView("ДИАГНОСТИКА")
        diag.addView(label("Если бот не находит кнопки: запусти его, потом открой журнал и нажми «Поделиться».", 12f, textDim))
        diag.addView(wideBtn("🧾  Журнал отладки") { showDebugLog() })
        col.addView(diag)

        col.addView(wideBtn("▶  Запустить", primary = true) { startPanel() }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(18)
            setPadding(0, dp(14), 0, dp(14))
        })

        col.addView(pair(
            LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                addView(wideBtn("Канал") { open("https://t.me/Scriptonit_Shop") }.apply {
                    (layoutParams as LinearLayout.LayoutParams).rightMargin = dp(4)
                })
            },
            LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                addView(wideBtn("Бот") { open("https://t.me/Scriptonit_Shop_bot") }.apply {
                    (layoutParams as LinearLayout.LayoutParams).leftMargin = dp(4)
                })
            }
        ))

        return ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF03110A.toInt(), 0xFF071A10.toInt(), 0xFF030907.toInt())
            )
            addView(col)
        }
    }

    // ---------- состояние ----------

    private fun setDot(d: TextView, ok: Boolean) {
        d.text = if (ok) "●" else "○"
        d.setTextColor(if (ok) green else textDim)
    }

    private fun refresh() {
        statBids.text = Stats.bids(this).toString()
        statSnake.text = Stats.snakeBest(this).toString()
        setDot(dotOverlay, Settings.canDrawOverlays(this))
        setDot(dotAccess, ClickService.instance != null)
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        setDot(dotKbOn, imm.enabledInputMethodList.any { it.packageName == packageName })
        val def = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        setDot(dotKbDefault, def.startsWith(packageName))
        val hasData = Ocr.hasData(this)
        setDot(dotOcr, hasData)
        ocrAction.text = when {
            ocrLoading -> "Загрузка…"
            hasData -> "Готово"
            else -> "Скачать"
        }

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        screenView.text = "Экран ${dm.widthPixels}×${dm.heightPixels}"
        val ready = listOf(
            Settings.canDrawOverlays(this), ClickService.instance != null,
            imm.enabledInputMethodList.any { it.packageName == packageName },
            def.startsWith(packageName), hasData
        ).count { it }
        prepTitle.text = "ПОДГОТОВКА · $ready/5"

        modeView.text = if (Store.mode(this) == "market") {
            "Сейчас: Маркет"
        } else {
            "Сейчас: " + (Store.selected(this)?.nameWithoutExtension ?: "нет скрипта")
        }
    }

    /**
     * Скачивает данные распознавания: цифры цен (обязательно для торговли) и
     * русские буквы для проверки надписей на кнопках (необязательно — без них бот
     * просто продолжает находить кнопки только по цвету, как раньше).
     */
    private fun loadOcrData() {
        if (Ocr.hasData(this) || ocrLoading) return
        ocrLoading = true
        refresh()
        Thread {
            val ok = Ocr.download(this)
            if (!LabelOcr.hasData(this)) LabelOcr.download(this) // необязательно, ошибку не показываем
            runOnUiThread {
                ocrLoading = false
                if (!ok) toast("Не удалось скачать данные цен. Проверь интернет и нажми «Скачать»")
                refresh()
            }
        }.start()
    }

    // ---------- скрипты ----------

    private fun pickScript() {
        val files = Store.list(this)
        AlertDialog.Builder(this)
            .setTitle("Скрипт")
            .setItems(files.map { it.nameWithoutExtension }.toTypedArray()) { _, i ->
                Store.select(this, files[i])
                refresh()
            }
            .show()
    }

    private fun askUrl() {
        val input = EditText(this).apply { hint = "https://…/script.txt" }
        AlertDialog.Builder(this)
            .setTitle("Ссылка на скрипт")
            .setView(input)
            .setPositiveButton("Загрузить") { _, _ -> download(input.text.toString().trim()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun download(url: String) {
        if (!url.startsWith("https://")) {
            toast("Нужна ссылка https://")
            return
        }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                val body = conn.inputStream.use { it.readBytes() }
                if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
                val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "script" }
                runOnUiThread {
                    try {
                        Store.save(this, name, String(body, Charsets.UTF_8))
                        toast("Скрипт загружен")
                        refresh()
                    } catch (e: Exception) {
                        toast(e.message ?: "Ошибка в скрипте")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Не удалось загрузить: ${e.message}") }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            1 -> importFile(data)
            2 -> {
                val svc = Intent(this, OverlayService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(svc)
                moveTaskToBack(true)
            }
        }
    }

    private fun importFile(data: Intent) {
        val uri = data.data ?: return
        try {
            var name = "script"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
            val body = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
            Store.save(this, name, String(body, Charsets.UTF_8))
            toast("Скрипт импортирован")
            refresh()
        } catch (e: Exception) {
            toast(e.message ?: "Не удалось прочитать файл")
        }
    }

    // ---------- запуск ----------

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) { toast("Разреши показ поверх окон"); return }
        if (ClickService.instance == null) { toast("Включи службу доступности"); return }
        if (Store.mode(this) == "market" && !Ocr.hasData(this)) {
            toast("Данные распознавания ещё не загружены")
            loadOcrData()
            return
        }
        BotPrefs.save(
            this,
            fields.mapValues { it.value.text.toString().trim() } +
                switches.mapValues { if (it.value.isChecked) "1" else "0" }
        )
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    // ---------- журнал отладки ----------

    private fun showDebugLog() {
        val full = DebugLog.read()
        val shown = if (full.isEmpty()) "Журнал пуст. Запусти бота (▶ на панели) — сюда попадёт всё, что он делает." else full.takeLast(30_000)
        val tv = TextView(this).apply {
            text = shown
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(textMain)
            setTextIsSelectable(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val sv = ScrollView(this).apply {
            addView(tv)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.5).toInt()
            )
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(sv)
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(8), dp(6), dp(8), 0)
                addView(smallBtn("Как текст") { shareText(full) })
                if (DebugLog.hasFrame()) addView(smallBtn("Кадры (PNG)") { shareFrames() })
            })
        }
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
        AlertDialog.Builder(this)
            .setTitle("Журнал отладки")
            .setView(col)
            .setPositiveButton("Поделиться файлом") { _, _ -> DebugLog.logFile()?.let { shareFile(it, "text/plain") } }
            .setNeutralButton("Очистить") { _, _ -> DebugLog.clear(); toast("Журнал очищен") }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun shareText(full: String) {
        val text = if (full.isEmpty()) "(журнал пуст)" else full.takeLast(60_000)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Scriptonit — журнал отладки")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(i, "Отправить журнал"))
    }

    private fun shareFrames() {
        val files = DebugLog.frameFiles()
        if (files.isEmpty()) { toast("Кадров нет"); return }
        try {
            val uris = ArrayList<Uri>()
            for (f in files) uris.add(FileProvider.getUriForFile(this, "$packageName.fileprovider", f))
            val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                clipData = android.content.ClipData.newRawUri("", uris[0]).also { cd ->
                    for (k in 1 until uris.size) cd.addItem(android.content.ClipData.Item(uris[k]))
                }
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Отправить кадры"))
        } catch (e: Exception) {
            toast("Не удалось поделиться: ${e.message}")
        }
    }

    private fun shareFile(f: File, mime: String) {
        if (!f.exists() || f.length() == 0L) { toast("Файл пуст"); return }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = android.content.ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Отправить"))
        } catch (e: Exception) {
            toast("Не удалось поделиться: ${e.message}")
        }
    }

    private fun open(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
