package com.scriptonit.shop

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Rect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.util.Locale
import kotlin.math.abs

data class BotConfig(
    val min: Double,
    val max: Double,
    val step: Double,
    val gap: Double,
    val cancelDelayMs: Long,
    val refreshMs: Long,
    val maxMinutes: Int,
    val maxBids: Int,
    val perMinute: Int,
    val aggressive: Boolean,
    val matchEqual: Boolean
)

object BotPrefs {
    private const val P = "bot"

    fun raw(c: Context, key: String, def: String): String =
        c.getSharedPreferences(P, Context.MODE_PRIVATE).getString(key, null) ?: def

    fun save(c: Context, values: Map<String, String>) {
        val e = c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }

    fun flag(c: Context, key: String, def: Boolean): Boolean = raw(c, key, if (def) "1" else "0") == "1"

    fun load(c: Context): BotConfig {
        fun d(k: String, def: String) = raw(c, k, def).replace(',', '.').toDoubleOrNull() ?: def.toDouble()
        return BotConfig(
            min = d("min", "10"),
            max = d("max", "99999"),
            step = 0.01,
            gap = 0.01,
            cancelDelayMs = (d("cancel", "2") * 1000).toLong().coerceAtLeast(0),
            refreshMs = (d("refresh", "1") * 1000).toLong().coerceAtLeast(300),
            maxMinutes = d("minutes", "119").toInt().coerceAtLeast(1),
            maxBids = d("bids", "300").toInt().coerceAtLeast(1),
            perMinute = d("perminute", "0").toInt().coerceAtLeast(0),
            aggressive = raw(c, "aggr", "0") == "1",
            matchEqual = true
        )
    }
}

/**
 * Ловля запросов v5. Работает со страницей предмета, на которой включена галочка «Только мои запросы»
 * (бот её не трогает — список лотов скрыт, единственная синяя кнопка под «Заказать» может быть только «Отмена»).
 *
 * Цикл: открываем окно «Запрос на покупку» → читаем в нём цену первого лота (при открытии она стоит в поле) →
 * остаёмся в окне БЕЗ клавиатуры и следим за ценой верхнего запроса на затемнённой странице. Как только
 * запрос вырос — вводим ставку (сбалансированный: запрос + 0.01, но не выше «лот − 0.01»; агрессивный: «лот − 0.01»),
 * подтверждаем и через «Отмена через» отменяем свой запрос. Раз в «Обновление» окно закрывается и открывается заново,
 * чтобы цена лота в нём была свежей.
 */
private const val TAP_MS = 15L

class MarketBot(
    private val svc: ClickService,
    private val grab: ScreenGrabber,
    private val ocr: Ocr,
    private val cfg: BotConfig,
    private val onBid: () -> Unit,
    private val log: (String) -> Unit,
    private val labelOcr: LabelOcr? = null
) {
    private var fw = 1
    private var fh = 1

    private var lot: Double? = null
    private var lastLotShown: Double? = null
    private var pageReq: Double? = null
    private var inDialog = false
    private var dialogAt = 0L
    private var closingUntil = 0L
    private var holdBase: Double? = null
    /** Последняя цена верхнего запроса, виденная в ЛЮБОМ из прошлых заходов в окно: рост за время перезахода тоже ловится. */
    private var knownReq: Double? = null
    private var holdPending: Double? = null
    private var downVal: Double? = null
    private var downCount = 0
    private var lastHash = 0
    private var lastOcrAt = 0L
    private var lastOwnBid: Double? = null
    private var bids = 0
    private val bidTimes = ArrayDeque<Long>()
    private var openFails = 0
    private var unexpectedScreens = 0
    private var skipNote: String? = null
    private var stopReason: String? = null

    private var crossTapped = false
    private var crossPt: Pt? = null
    private var lastCrossTapAt = 0L
    private var unknownBacks = 0
    private var lastBackAt = 0L
    private var unknownSaved = false
    private var diagSaved = false

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun round2(v: Double) = Math.round(v * 100.0) / 100.0

    private fun track(f: Frame) { fw = f.w; fh = f.h }

    private fun isOwn(r: Double): Boolean {
        val o = lastOwnBid ?: return false
        if (abs(o - r) < 0.005) return true
        lastOwnBid = null
        return false
    }

    // ---------- нажатия и ожидания ----------

    /** Зоны, куда бот не нажимает НИКОГДА: верхняя панель со стрелкой «назад» и левая колонка (осмотр, продать, выход из предмета). */
    private fun forbiddenZone(p: Pt): Boolean {
        if (p.x < 0 || p.y < 0 || (fw > 0 && p.x >= fw) || (fh > 0 && p.y >= fh)) return true
        if (fh > 0 && p.y < fh * 0.10f) return true
        if (fw > 0 && p.x < fw * 0.27f) return true
        return false
    }

    private fun tapAllowed(p: Pt, allowLeft: Boolean = false): Boolean {
        val cp = crossPt
        if (crossTapped && cp != null) {
            val zone = (Profile.dialogLayout?.band?.w ?: 300) * 0.5f
            val dx = (p.x - cp.x).toFloat()
            val dy = (p.y - cp.y).toFloat()
            if (dx * dx + dy * dy < zone * zone) {
                DebugLog.add("Тап (${p.x},${p.y}) в зоне крестика отклонён: по крестику для этого окна уже нажимали")
                return false
            }
        }
        if (forbiddenZone(p)) {
            DebugLog.add("Тап (${p.x},${p.y}) в запретной зоне (верхняя панель / левая колонка) — пропущен")
            return false
        }
        return true
    }

    /** Нажатие по планируемой точке (закрытие окна) — тоже только через проверку запретных зон. */
    private suspend fun safeGesture(p: Pt): Boolean {
        if (forbiddenZone(p)) {
            DebugLog.add("Тап (${p.x},${p.y}) в запретной зоне — пропущен")
            return false
        }
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), TAP_MS)
        return true
    }

    private suspend fun quickTap(p: Pt) {
        if (!tapAllowed(p)) return
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), TAP_MS)
    }

    private suspend fun tap(p: Pt, allowLeft: Boolean = false) {
        if (!tapAllowed(p, allowLeft)) return
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), TAP_MS)
        delay(4)
    }

    private suspend fun waitFor(timeoutMs: Long, cond: (Frame) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (cond(f)) return true
            }
            delay(8)
        }
        return false
    }

    private fun settleHash(f: Frame): Int {
        var h = 17
        val x0 = (f.w * 0.62f).toInt()
        val y1 = (f.h * 0.32f).toInt()
        var y = 0
        while (y < y1) {
            var x = x0
            while (x < f.w) {
                val c = f.bmp.getPixel(x, y)
                h = h * 31 + (((android.graphics.Color.red(c) + android.graphics.Color.green(c) + android.graphics.Color.blue(c)) / 3) shr 3)
                x += 12
            }
            y += 12
        }
        return h
    }

    /** Ждёт, пока правая верхняя часть экрана перестанет меняться (страница проявилась после закрытия окна). */
    private suspend fun waitSettled(maxMs: Long = 80) {
        val end = System.currentTimeMillis() + maxMs
        var last = 0
        var haveLast = false
        var same = 0
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                val h = settleHash(f)
                if (haveLast && h == last) { same++; if (same >= 2) return } else same = 0
                last = h
                haveLast = true
            }
            delay(8)
        }
    }

    // ---------- ввод ----------

    private suspend fun typeText(text: String): Boolean {
        val viaIme = withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.replaceText(text) == true }
        if (viaIme) return true
        // клавиатура Scriptonit не выбрана — пробуем вставить через спец. возможности
        val viaA11y = withContext(Dispatchers.Main) { svc.setFocusedText(text) }
        if (viaA11y) DebugLog.add("Ввод цены: вставка через спец. возможности")
        return viaA11y
    }

    /** «Готово» в нашей клавиатуре. Системное «Назад» НЕ используется нигде: на странице предмета оно выкидывает в меню маркета. */
    private suspend fun imeDone() {
        withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.done() }
    }

    private suspend fun closeKeyboard(): Boolean {
        imeDone()
        if (waitFor(500) { !Profile.isKeyboard(it) }) return true
        val f = grab.frame() ?: return false
        track(f)
        // запасной путь — тап по галочке белой панели игры, и только когда окно запроса точно на экране
        if (!Profile.dialogOpenStrict(f)) return false
        val bar = Profile.inputBar(f) ?: return false
        val (rowY, _, right) = bar
        tap(Pt((right - (right - bar.second) * 0.06f).toInt(), rowY))
        return waitFor(600) { !Profile.isKeyboard(it) }
    }

    // ---------- закрытие окна / восстановление ----------

    /** Закрывает окно крестиком: РОВНО одно нажатие на окно (на месте крестика на странице лежит строка лота). */
    private suspend fun crossClose(maxMs: Long = 3500): Boolean {
        val t0 = System.currentTimeMillis()
        var tapped = false
        while (System.currentTimeMillis() - t0 < maxMs) {
            yield()
            val f = grab.frame()
            if (f == null) { delay(20); continue }
            track(f)
            if (Profile.pageVisibleFast(f) || Profile.isPage(f, labelOcr)) {
                DebugLog.add("Закрытие окна запроса: ${System.currentTimeMillis() - t0} мс (${if (tapped) 1 else 0} нажатий)")
                return true
            }
            if (tapped) { delay(40); continue }
            if (crossTapped) {
                if (System.currentTimeMillis() - lastCrossTapAt < 10_000) { delay(60); continue }
                if (Profile.liveClose(f) == null) { delay(60); continue }
                crossTapped = false
            }
            val close = Profile.liveClose(f) ?: if (Profile.dialogOpenStrict(f)) Profile.dialogCloseTap(f) else null
            if (close == null) { delay(60); continue }
            quickTap(close)
            tapped = true
            crossTapped = true
            crossPt = close
            lastCrossTapAt = System.currentTimeMillis()
            DebugLog.add("Крестик: ОДНО нажатие в (${close.x},${close.y})")
        }
        DebugLog.add("Закрытие окна запроса: страница не появилась за ${System.currentTimeMillis() - t0} мс")
        return false
    }

    private suspend fun closeDialog() {
        inDialog = false
        if (grab.frame()?.let { Profile.isKeyboard(it) && !Profile.pageVisibleFast(it) } == true) closeKeyboard()
        crossClose()
    }

    /** Плановый выход из окна (обновление лота): один тап по крестику, без ожиданий. */
    private suspend fun leaveDialog() {
        val f = grab.frame()
        if (f != null) {
            track(f)
            val close = Profile.liveClose(f) ?: if (Profile.dialogOpenStrict(f)) Profile.dialogCloseTap(f, labelOcr) else null
            if (close != null) {
                if (safeGesture(close)) DebugLog.add("Крестик: один тап в (${close.x},${close.y})")
            } else {
                DebugLog.add("Крестик: позиция не найдена — тап пропущен")
            }
        }
        inDialog = false
        closingUntil = System.currentTimeMillis() + 1200
    }

    /**
     * Неизвестный экран. Бот НИЧЕГО не нажимает по краям экрана (раньше тут жались «Назад» и стрелка выхода из предмета —
     * это выкидывало со страницы). Только ждёт: окно закрываем крестиком, а страница, что ещё проявляется, подтянется сама.
     */
    private suspend fun recoverScreen() {
        val f = grab.frame() ?: return
        if (Profile.dialogOpenStrict(f)) { closeDialog(); return }
        if (waitFor(1500) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) return
        if (!unknownSaved) {
            unknownSaved = true
            grab.frame()?.let { DebugLog.saveFrame(it, "unknown") }
        }
        delay(300)
    }

    // ---------- окно запроса: цена лота ----------

    /** Читает цену из поля окна (при открытии там стоит цена первого лота): нужны два одинаковых чтения подряд. */
    private suspend fun readDialogLot(timeoutMs: Long, hint: Double? = null): Double? {
        var prev: Double? = null
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f == null) { delay(15); continue }
            track(f)
            val reg = Profile.dialogLotRegion(f)
            if (reg == null) { delay(15); continue }
            val v = ocr.readPrice(f, reg)
            if (v != null) {
                // то же число, что в прошлый раз — хватает одного чтения (быстрый перезаход)
                if (hint != null && abs(hint - v) < 0.001) return v
                if (prev != null && abs(prev - v) < 0.001) return v
                prev = v
            } else prev = null
            delay(8)
        }
        return null
    }

    private fun resetHold() {
        holdBase = null; holdPending = null; downVal = null; downCount = 0
        lastHash = 0; lastOcrAt = 0
    }

    /** Открывает окно запроса и читает в нём цену лота. Остаётся в окне (без клавиатуры). */
    private suspend fun enterDialog(): Boolean {
        val f0 = grab.frame() ?: return false
        track(f0)
        val order = Profile.orderTap(f0) ?: return false
        quickTap(order)
        pageReq = Profile.requestPriceRegion(f0)?.let { ocr.readPrice(f0, it) } // пока окно открывается
        if (!waitFor(1500) { Profile.dialogShown(it) }) {
            DebugLog.add("Окно запроса не открылось за 1.5 с после «Заказать»")
            grab.frame()?.let { DebugLog.saveFrame(it, "enter", Profile.dialogMarks()) }
            return false
        }
        crossTapped = false
        val l = readDialogLot(1500, lastLotShown)
        if (l == null) {
            DebugLog.add("Цена лота в окне не прочиталась")
            grab.frame()?.let { f -> DebugLog.saveFrame(f, "lot", Profile.dialogMarks()) }
            lot = null
            resetHold()
            inDialog = true
            dialogAt = System.currentTimeMillis()
            return true
        }
        lot = l
        if (lastLotShown == null || abs(lastLotShown!! - l) > 0.001) {
            log("ЦЕНА ЛОТА: ${fmt(l)}")
            lastLotShown = l
        }
        resetHold()
        inDialog = true
        dialogAt = System.currentTimeMillis()
        return true
    }

    // ---------- решение о ставке ----------

    private fun chooseBid(r: Double): Double? {
        val l = lot ?: return null
        if (l < cfg.min || l > cfg.max) return null
        val ceiling = round2(l - cfg.gap)
        val outbid = round2(r + cfg.step)
        val bid = when {
            cfg.aggressive -> if (round2(r) <= ceiling) ceiling else return null
            outbid <= ceiling -> outbid
            round2(r) <= ceiling -> ceiling
            else -> return null
        }
        return if (bid > cfg.max || bid < 0.01) null else bid
    }

    private fun skipReason(r: Double): String {
        val l = lot ?: return "цена лота в окне не прочитана"
        return when {
            l < cfg.min -> "лот ${fmt(l)} ниже «Цена от» (${fmt(cfg.min)})"
            l > cfg.max -> "лот ${fmt(l)} выше «Цена до» (${fmt(cfg.max)})"
            else -> "запрос ${fmt(r)} уже выше потолка ${fmt(round2(l - cfg.gap))} (лот ${fmt(l)} минус 0.01)"
        }
    }

    /** Лимит «ставок в минуту»: считаем реальные ставки за последние 60 с. 0 — без лимита. */
    private fun rateBlocked(): Boolean {
        if (cfg.perMinute <= 0) return false
        val now = System.currentTimeMillis()
        while (bidTimes.isNotEmpty() && now - bidTimes.first() >= 60_000) bidTimes.removeFirst()
        return bidTimes.size >= cfg.perMinute
    }

    /** true — ставка пропущена именно из-за лимита «в минуту»: перебитие нельзя считать обработанным, его надо повторить. */
    private suspend fun tryBid(from: Double, r: Double): Boolean {
        val bid = chooseBid(r)
        if (bid == null) { noteSkip(skipReason(r)); return false }
        if (rateBlocked()) { noteSkip("лимит ${cfg.perMinute} ставок в минуту — пропускаю, жду"); return true }
        placeBid(bid, from, r)
        return false
    }

    private fun noteSkip(text: String) {
        if (skipNote == text) return
        skipNote = text
        log("Пропуск: $text")
    }

    // ---------- наблюдение внутри окна ----------

    private suspend fun holdTick(f: Frame) {
        val now = System.currentTimeMillis()
        if (now - dialogAt >= cfg.refreshMs) { leaveDialog(); return }
        val region = Profile.requestRegionMemo() ?: return
        val hash = Profile.regionHash(f, region)
        if (hash == lastHash && now - lastOcrAt < 600) return
        lastHash = hash
        lastOcrAt = now
        val r = ocr.readPrice(f, region) ?: return
        val base = holdBase
        if (base == null) {
            val pr = pageReq
            val pend = holdPending
            var stable = false
            if (pr != null && abs(pr - r) < 0.001) stable = true
            else if (pend != null && abs(pend - r) < 0.001) stable = true
            else holdPending = r
            if (!stable) return
            holdPending = null
            val old = knownReq
            holdBase = r
            knownReq = r
            if (lastReqShown == null || abs(lastReqShown!! - r) > 0.001) {
                lastReqShown = r
                log("ЦЕНА ЗАПРОСА: ${fmt(r)}")
            }
            // пока окно было закрыто, запрос вырос — ставим сразу, как при обычном росте
            if (old != null && r > old + 0.001 && !isOwn(r)) {
                if (tryBid(old, r)) { holdBase = old; knownReq = old }
            }
            return
        }
        if (r > base + 0.001) {
            if (!confirmRead(r)) return
            holdBase = r
            knownReq = r
            downVal = null; downCount = 0
            if (isOwn(r)) return
            if (tryBid(base, r)) { holdBase = base; knownReq = base }
        } else if (r < base - 0.001) {
            if (downVal != null && abs(downVal!! - r) < 0.001) downCount++ else { downVal = r; downCount = 1 }
            if (downCount >= 2) { holdBase = r; knownReq = r; downVal = null; downCount = 0 }
        } else {
            downVal = null; downCount = 0
        }
    }

    private var lastReqShown: Double? = null

    private suspend fun confirmRead(r: Double): Boolean {
        delay(10)
        val f2 = grab.frame() ?: return false
        track(f2)
        val reg = Profile.requestRegionMemo() ?: return false
        val r2 = ocr.readPrice(f2, reg) ?: return false
        val ok = abs(r2 - r) < 0.001
        if (!ok) DebugLog.add("Рост запроса не подтвердился (${fmt(r)} → ${fmt(r2)}) — ставку не делаю")
        return ok
    }

    // ---------- ставка ----------

    private suspend fun placeBid(bid: Double, from: Double, to: Double) {
        log("Запрос ${fmt(from)} → ${fmt(to)}, ставлю ${fmt(bid)}")
        skipNote = null
        val lay = Profile.dialogLayout ?: return
        inDialog = false
        holdBase = null
        lastOwnBid = bid
        val fr = grab.frame()
        if (fr == null || !Profile.dialogOpenStrict(fr)) { log("Окно запроса не открыто — ставка отменена"); return }
        quickTap(lay.priceTap)
        if (!waitFor(1500) { Profile.isKeyboard(it) }) {
            log("Поле цены не открылось")
            grab.frame()?.let { DebugLog.saveFrame(it, "enter", Profile.dialogMarks()) }
            closeDialog()
            return
        }
        delay(8)
        if (!typeText(fmt(bid))) {
            log("Выбери клавиатуру Scriptonit по умолчанию (Клавиатура → шаг 2)")
            closeDialog()
            return
        }
        if (!closeKeyboard()) { log("Клавиатура не закрылась"); closeDialog(); return }
        if (!waitFor(900) { Profile.dialogOpenStrict(it) }) { log("Окно запроса пропало — подтверждение отменено"); return }
        val confirm = grab.frame()?.let { Profile.dialogConfirmTap(it, labelOcr) }
        if (confirm == null) { log("Не нашёл кнопку «Заказать» в окне"); closeDialog(); return }
        tap(confirm)
        val placedAt = System.currentTimeMillis()
        bidTimes.addLast(placedAt)
        bids++
        onBid()
        log("#$bids: ${fmt(bid)} G · лот ${fmt(lot ?: 0.0)}")
        // отмена — только для запроса, который бот сам поставил после перебития, и ровно через «Отмена через» от этого момента
        if (cfg.cancelDelayMs > 0) cancelOwnRequest(bid, placedAt)
        waitFor(1500) { Profile.isPage(it, labelOcr) }
    }

    /** Мягкая проверка: поле показывает то, что мы ввели. При явном расхождении вводим ещё раз. */
    private suspend fun verifyTyped(bid: Double) {
        delay(40)
        val f = grab.frame() ?: return
        track(f)
        val reg = Profile.dialogLotRegion(f) ?: return
        val r = ocr.readPrice(f, reg) ?: return
        if (abs(r - bid) > 0.001) {
            DebugLog.add("В поле ${fmt(r)} вместо ${fmt(bid)} — ввожу ещё раз")
            typeText(fmt(bid))
            delay(40)
        }
    }

    // ---------- отмена своего запроса ----------

    private suspend fun waitCancel(ms: Long): AnchorScan.Band? {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (Profile.isPage(f, labelOcr)) {
                    Profile.scanBlue(f, labelOcr)
                    val c = Profile.cancelBand
                    if (c != null) return c
                }
            }
            delay(15)
        }
        return null
    }

    /**
     * «Отмена» — синяя кнопка вплотную под «Заказать» (<0.7 её ширины). «Купить» лота стоит дальше и не нажимается никогда.
     * С галочкой «Только мои запросы» других синих кнопок на странице нет.
     */
    private suspend fun cancelOwnRequest(bid: Double, placedAt: Long) {
        if (waitCancel(4000) == null) {
            log("«Отмена» не появилась — запрос ${fmt(bid)} не создан; ничего не нажимаю")
            grab.frame()?.let { DebugLog.saveFrame(it, "cancel") }
            return
        }
        val left = cfg.cancelDelayMs - (System.currentTimeMillis() - placedAt)
        if (left > 0) delay(left)
        for (attempt in 1..3) {
            val cb = waitCancel(1500) ?: return
            tap(Pt(cb.cx, cb.cy))
            val gone = waitFor(1600) {
                Profile.isPage(it, labelOcr) && run { Profile.scanBlue(it, labelOcr); Profile.cancelBand == null }
            }
            if (gone) { log("Отменил свой запрос ${fmt(bid)}"); return }
        }
        log("Не удалось отменить запрос ${fmt(bid)} за 3 попытки — проверь вручную")
    }

    // ---------- автонастройка ----------

    private suspend fun calibrate(): Boolean {
        log("Автонастройка: ищу кнопки на странице…")
        val pageStart = System.currentTimeMillis()
        var pageOk = false
        var lastFrame: Frame? = null
        var framesSeen = 0
        var leftoverTaps = 0
        while (System.currentTimeMillis() - pageStart < 10_000) {
            yield()
            val f = grab.frame()
            if (f != null) {
                framesSeen++
                lastFrame = f
                track(f)
                if (framesSeen == 1) DebugLog.add("Автонастройка: первый кадр ${f.w}x${f.h}")
                if (Profile.isPage(f, labelOcr)) { pageOk = true; break }
                // окно запроса осталось открытым после прошлой остановки — закрываем крестиком (не более 3 раз)
                if (leftoverTaps < 3) {
                    val band = Profile.scanDialogBand(f)
                    if (band != null) {
                        Profile.setDialogLayout(f, band)
                        Profile.dialogLayout?.takeIf { it.info.contains("(по картинке)") && it.info.contains("по цифрам") }?.let {
                            log("Закрываю окно запроса, оставшееся с прошлого раза")
                            quickTap(it.closeTap)
                            leftoverTaps++
                            delay(700)
                        }
                    }
                }
            }
            delay(60)
        }
        if (!pageOk) {
            log("Не нашёл кнопку «Заказать» — открой страницу предмета в маркете")
            val ff = lastFrame
            if (ff == null) DebugLog.add("ДИАГНОСТИКА: за 10 секунд не пришло ни одного кадра экрана")
            else {
                DebugLog.add("=== ДИАГНОСТИКА: не найдена «Заказать» (кадров: $framesSeen) ===\n" + Profile.diagnose(ff, labelOcr))
                DebugLog.saveFrame(ff)
            }
            return false
        }
        grab.frame()?.let { Profile.scanBlue(it, labelOcr) }
        if (Profile.cancelBand != null) {
            log("На странице уже стоит твой запрос («Отмена»). Отмени его вручную и запусти снова")
            return false
        }
        grab.frame()?.let { f ->
            val marks = ArrayList<Pair<String, Pt>>()
            Profile.orderTap(f)?.let { marks.add("order" to it) }
            Profile.balanceRegion(f)?.let { marks.add("balance" to Pt(it.centerX(), it.centerY())) }
            Profile.requestPriceRegion(f)?.let { marks.add("request" to Pt(it.centerX(), it.centerY())) }
            DebugLog.saveFrame(f, "page", marks)
        }

        // цена верхнего запроса на странице должна читаться
        var reqPrice: Double? = null
        var lastRr: Rect? = null
        var noteR = ""
        var priceFrame: Frame? = null
        val priceEnd = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < priceEnd && reqPrice == null) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                val rr = Profile.requestPriceRegion(f)
                if (rr != null) {
                    reqPrice = ocr.readPrice(f, rr)
                    noteR = ocr.lastNote
                    lastRr = rr
                    priceFrame = f
                }
            }
            delay(60)
        }
        if (reqPrice == null) {
            log("Цена запроса на странице не читается — проверь «Распознавание цен». Подробности: журнал отладки")
            DebugLog.add("=== ДИАГНОСТИКА: цена запроса не читается ===\nOCR готов=${ocr.ready}\nобласть $lastRr → $noteR")
            priceFrame?.let { DebugLog.saveFrame(it) }
            return false
        }
        log("ЦЕНА ЗАПРОСА: ${fmt(reqPrice)}")
        pageReq = reqPrice
        lastReqShown = reqPrice

        // открываем окно один раз: снимаем раскладку (поле цены, крестик, «Заказать») и читаем цену лота
        val order = grab.frame()?.let { Profile.orderTap(it) }
        if (order == null) { log("Автонастройка: нет кнопки «Заказать»"); return false }
        Profile.resetDialogCache()
        tap(order)
        var dialogOk = false
        var bestArea = 0
        var lastGrowthAt = 0L
        val dialogEnd = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < dialogEnd) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                val band = Profile.scanDialogBand(f)
                if (band != null) {
                    val area = band.w * band.h
                    if (area > bestArea * 1.03) {
                        bestArea = area
                        lastGrowthAt = System.currentTimeMillis()
                        Profile.setDialogLayout(f, band)
                    }
                }
                if (bestArea > 0 && (System.currentTimeMillis() - lastGrowthAt > 250 || Profile.isKeyboard(f))) { dialogOk = true; break }
            }
            delay(15)
        }
        if (!dialogOk) {
            grab.frame()?.let { f ->
                DebugLog.add("=== ДИАГНОСТИКА: в окне запроса не найдена «Заказать» ===\n" + Profile.diagnoseDialog(f, labelOcr))
                DebugLog.saveFrame(f)
            }
            closeDialog()
            log("Не нашёл кнопку в окне запроса — подробности в журнале отладки")
            return false
        }
        DebugLog.add("Окно запроса: ${Profile.dialogLayout?.info}")
        crossTapped = false
        val l = readDialogLot(2500)
        grab.frame()?.let { f ->
            val marks = ArrayList(Profile.dialogMarks())
            Profile.dialogLotRegion(f)?.let { marks.add("lot" to Pt(it.centerX(), it.centerY())) }
            DebugLog.saveFrame(f, "dialog", marks)
        }
        if (l == null) {
            log("Цена лота в окне не читается — подробности в журнале отладки")
            grab.frame()?.let { DebugLog.saveFrame(it) }
            closeDialog()
            return false
        }
        lot = l
        lastLotShown = l
        log("ЦЕНА ЛОТА: ${fmt(l)}")
        grab.frame()?.let { f ->
            // баланс — только строка в журнале, в решениях не участвует
            val br = Profile.balanceRegion(f)
            val b = if (br != null) ocr.readPrice(f, br) else null
            if (b != null) log("ТЕКУЩИЙ БАЛАНС: ${fmt(b)}")
        }
        log("Автонастройка пройдена ✓ режим: ${if (cfg.aggressive) "агрессивный" else "сбалансированный"}" + if (cfg.perMinute > 0) ", лимит ${cfg.perMinute}/мин" else "")
        resetHold()
        inDialog = true
        dialogAt = System.currentTimeMillis()
        return true
    }

    // ---------- главный цикл ----------

    suspend fun run() {
        try {
            runLoop()
        } finally {
            // остановили кнопкой ■ в открытом окне запроса — аккуратно закрываем его, чтобы оно не мешало следующему запуску
            if (inDialog) {
                withContext(NonCancellable) {
                    try { leaveDialog(); delay(400) } catch (e: Exception) { }
                }
            }
        }
    }

    private suspend fun runLoop() {
        Profile.reset()
        DebugLog.add("=== Запуск бота v5: $cfg ===")
        val start = System.currentTimeMillis()
        val limitMs = cfg.maxMinutes * 60_000L
        var lost = 0
        var unrecSince = 0L
        if (!calibrate()) return

        while (true) {
            yield()
            if (System.currentTimeMillis() - start >= limitMs) { log("Время работы вышло"); break }
            if (bids >= cfg.maxBids) { log("Лимит ставок: $bids"); break }
            val sr = stopReason
            if (sr != null) { log(sr); break }

            val f = grab.frame()
            if (f == null) {
                lost++
                if (lost > 400) { log("Кадры экрана не приходят — перезапусти панель"); break }
                delay(15)
                continue
            }
            lost = 0
            track(f)
            val now = System.currentTimeMillis()

            if (Profile.dialogShown(f)) {
                unrecSince = 0L; unknownBacks = 0
                if (inDialog) holdTick(f)
                else if (now < closingUntil) delay(25)
                else closeDialog() // окно открыто не нами или не закрылось
            } else if (ScriptoKeyboardService.instance?.isInputViewShown == true && !Profile.pageVisibleFast(f) && !Profile.isPage(f, labelOcr)) {
                // наша клавиатура осталась без окна — прячем командой, по экрану не жмём
                imeDone()
                delay(60)
            } else if (Profile.isPage(f, labelOcr)) {
                unrecSince = 0L; unknownBacks = 0
                inDialog = false
                waitSettled(80)
                if (enterDialog()) openFails = 0
                else {
                    openFails++
                    if (openFails >= 8) stopReason = "Не удаётся открыть окно запроса — смотри журнал отладки"
                    delay(200)
                }
            } else {
                unexpectedScreens++
                if (unrecSince == 0L) unrecSince = now
                // кадры проявления страницы после закрытия окна — не повод для диагностики; сохраняем только затянувшийся случай
                if (now - unrecSince > 2000 && unexpectedScreens > 0 && !diagSaved) {
                    diagSaved = true
                    DebugLog.add("=== Экран не распознан более 2 с ===\n" + Profile.diagnose(f, labelOcr))
                    DebugLog.saveFrame(f)
                }
                if (now - unrecSince > 10_000) { log("Не узнаю экран 10 секунд — остановился. Открой страницу предмета и запусти заново"); break }
                recoverScreen()
            }
            delay(2)
        }
    }
}
