package com.scriptonit.shop

import android.content.Context

/** Цветовая схема приложения и панели. */
class Palette(
    val id: String,
    val name: String,
    val dot: Int,        // цвет кружка в выборе темы
    val bg0: Int,        // фон экрана (верх)
    val bg1: Int,        // фон экрана (низ)
    val card0: Int,      // карточка (верх)
    val card1: Int,      // карточка (низ)
    val stroke: Int,     // рамка карточек
    val accent: Int,     // основной акцент
    val accent2: Int,    // второй цвет градиента кнопок
    val onAccent: Int,   // текст на акценте
    val text: Int,
    val dim: Int,
    val field: Int,      // фон полей ввода
    val warn: Int,
    val ok: Int
)

object Themes {
    private const val P = "scriptonit"
    private fun c(v: Long) = v.toInt()

    val emerald = Palette(
        "emerald", "Изумруд", c(0xFF10B981),
        c(0xFF020E09), c(0xFF05231A), c(0xFF0B3A2A), c(0xFF072A1E), c(0xFF13694B),
        c(0xFF10B981), c(0xFF34D399), c(0xFF01130B), c(0xFFE8FFF4), c(0xFF7FB9A0), c(0xFF030F0A),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val night = Palette(
        "night", "Ночь", c(0xFF5B6CFF),
        c(0xFF050A18), c(0xFF0B1431), c(0xFF15234A), c(0xFF0E1832), c(0xFF25366E),
        c(0xFF4D7CFF), c(0xFF7A5CFF), c(0xFFFFFFFF), c(0xFFEAF0FF), c(0xFF8795C4), c(0xFF060C1E),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val ice = Palette(
        "ice", "Лёд", c(0xFF22B8F0),
        c(0xFF04121A), c(0xFF08202E), c(0xFF0F3144), c(0xFF0A2130), c(0xFF1C5470),
        c(0xFF1FB6FF), c(0xFF2D7BFF), c(0xFF031018), c(0xFFE6F8FF), c(0xFF7FAFC6), c(0xFF051722),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val violet = Palette(
        "violet", "Фиолет", c(0xFFB25CFF),
        c(0xFF0A0612), c(0xFF130B24), c(0xFF231742), c(0xFF170F2D), c(0xFF3F2D7A),
        c(0xFFA24BFF), c(0xFFEC4DFF), c(0xFFFFFFFF), c(0xFFF3EBFF), c(0xFF9C8BC9), c(0xFF0B0716),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val blood = Palette(
        "blood", "Кровь", c(0xFFFF7A18),
        c(0xFF100605), c(0xFF1E0B08), c(0xFF321512), c(0xFF210E0B), c(0xFF5C2A1D),
        c(0xFFFF7A18), c(0xFFFF3D2E), c(0xFF1A0A02), c(0xFFFFEDE6), c(0xFFC99A8B), c(0xFF120807),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )
    val neon = Palette(
        "neon", "Неон", c(0xFF00F5A0),
        c(0xFF030D0B), c(0xFF07201A), c(0xFF0D3328), c(0xFF08221B), c(0xFF146B52),
        c(0xFF00F5A0), c(0xFF00D4FF), c(0xFF02140F), c(0xFFE4FFF6), c(0xFF78B8A4), c(0xFF041410),
        c(0xFFFF6B8A), c(0xFF4ADE80)
    )


    val sunset = Palette("sunset", "Закат", c(0xFFFF5A5F),
        c(0xFF120609), c(0xFF240B16), c(0xFF3A1424), c(0xFF280E19), c(0xFF6B2640),
        c(0xFFFF6A3D), c(0xFFFF2E93), c(0xFFFFFFFF), c(0xFFFFEEF2), c(0xFFCC9AA8), c(0xFF14070C), c(0xFFFF6B8A), c(0xFF4ADE80))
    val ocean = Palette("ocean", "Океан", c(0xFF0EA5E9),
        c(0xFF020D14), c(0xFF06202E), c(0xFF0C3447), c(0xFF08263A), c(0xFF156285),
        c(0xFF0EA5E9), c(0xFF14B8A6), c(0xFF01121C), c(0xFFE5F6FF), c(0xFF78AFC9), c(0xFF030F18), c(0xFFFF6B8A), c(0xFF4ADE80))
    val gold = Palette("gold", "Золото", c(0xFFF5B301),
        c(0xFF0E0A02), c(0xFF1D1505), c(0xFF33260A), c(0xFF241A07), c(0xFF6B5014),
        c(0xFFF5B301), c(0xFFFF8A00), c(0xFF1A1000), c(0xFFFFF5DC), c(0xFFC4AD73), c(0xFF100B03), c(0xFFFF6B8A), c(0xFF4ADE80))
    val rose = Palette("rose", "Роза", c(0xFFFF4D8D),
        c(0xFF14050D), c(0xFF260A18), c(0xFF3D1228), c(0xFF2B0C1C), c(0xFF73224A),
        c(0xFFFF4D8D), c(0xFFFF8FB8), c(0xFF22000F), c(0xFFFFEAF3), c(0xFFD197B0), c(0xFF15060E), c(0xFFFF6B8A), c(0xFF4ADE80))
    val cyber = Palette("cyber", "Кибер", c(0xFFFFE600),
        c(0xFF07070F), c(0xFF10102A), c(0xFF1B1B45), c(0xFF121233), c(0xFF38388A),
        c(0xFFFFE600), c(0xFF00E5FF), c(0xFF0A0A00), c(0xFFF4F4FF), c(0xFF9A9AD0), c(0xFF080818), c(0xFFFF6B8A), c(0xFF4ADE80))
    val graphite = Palette("graphite", "Графит", c(0xFFD1D5DB),
        c(0xFF08090B), c(0xFF14161A), c(0xFF22252B), c(0xFF181A1F), c(0xFF3A3E47),
        c(0xFFE5E7EB), c(0xFF9CA3AF), c(0xFF0B0C0F), c(0xFFF3F4F6), c(0xFF9CA3AF), c(0xFF0B0C0F), c(0xFFFF6B8A), c(0xFF4ADE80))
    val lime = Palette("lime", "Лайм", c(0xFFA3E635),
        c(0xFF070D02), c(0xFF101E05), c(0xFF1E3509), c(0xFF152607), c(0xFF3F6B12),
        c(0xFFA3E635), c(0xFF4ADE80), c(0xFF0B1500), c(0xFFF3FFE0), c(0xFFA6C474), c(0xFF081003), c(0xFFFF6B8A), c(0xFF4ADE80))
    val mint = Palette("mint", "Мята", c(0xFF5EEAD4),
        c(0xFF03100F), c(0xFF072422), c(0xFF0E3B38), c(0xFF092B29), c(0xFF1C6B66),
        c(0xFF5EEAD4), c(0xFF67E8F9), c(0xFF021412), c(0xFFE6FFFB), c(0xFF7CC2BA), c(0xFF041412), c(0xFFFF6B8A), c(0xFF4ADE80))

    val all = listOf(neon, emerald, night, ice, violet, blood, sunset, ocean, gold, rose, cyber, graphite, lime, mint)

    fun current(ctx: Context): Palette {
        val id = ctx.getSharedPreferences(P, Context.MODE_PRIVATE).getString("theme", "neon")
        return all.firstOrNull { it.id == id } ?: neon
    }

    fun set(ctx: Context, id: String) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("theme", id).apply()
    }

    fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
}
