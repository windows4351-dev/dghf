package com.scriptonit.shop

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Небольшой набор готовых элементов интерфейса в цветах выбранной темы. */
class Ui(val ctx: Context, val p: Palette) {

    fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(fill: Int, stroke: Int, radius: Int, strokeDp: Int = 1) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
    }

    fun gradient(a: Int, b: Int, radius: Int, horizontal: Boolean = true) = GradientDrawable(
        if (horizontal) GradientDrawable.Orientation.LEFT_RIGHT else GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(a, b)
    ).apply { cornerRadius = dp(radius).toFloat() }

    fun cardBg() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.card0, p.card1)).apply {
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), p.stroke)
    }

    fun screenBg() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(p.bg0, p.bg1))

    fun label(s: String, size: Float, color: Int = p.text, bold: Boolean = false) = TextView(ctx).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun section(s: String) = label(s, 12f, p.accent, true).apply {
        letterSpacing = 0.12f
        setPadding(dp(4), dp(14), 0, dp(6))
    }

    fun card(vertical: Boolean = true): LinearLayout = LinearLayout(ctx).apply {
        orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        background = cardBg()
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
    }

    /** Большая кнопка с градиентом темы. */
    fun primary(text: String, onClick: () -> Unit) = Button(ctx).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(p.onAccent)
        background = gradient(p.accent, p.accent2, 12)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(46)
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    /** Тёмная кнопка с рамкой. */
    fun ghost(text: String, onClick: () -> Unit) = Button(ctx).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(p.text)
        background = rounded(p.field, p.stroke, 12)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(44)
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    fun small(text: String, onClick: () -> Unit) = Button(ctx).apply {
        this.text = text
        isAllCaps = false
        textSize = 12f
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setTextColor(p.accent)
        background = rounded(p.field, p.stroke, 10)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    /** Плитка главного экрана: значок в круглом бейдже и подпись. */
    fun tile(icon: String, title: String, danger: Boolean, weight: Float, onClick: () -> Unit): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val tone = if (danger) p.warn else p.accent
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(if (danger) Themes.withAlpha(p.warn, 0x26) else p.card0, p.card1)
            ).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), if (danger) p.warn else p.stroke) }
            setPadding(dp(8), dp(16), dp(8), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            val badge = TextView(ctx).apply {
                text = icon
                textSize = 20f
                setTextColor(tone)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Themes.withAlpha(tone, 0x22))
                    setStroke(dp(1), Themes.withAlpha(tone, 0x88))
                }
                layoutParams = LinearLayout.LayoutParams(dp(50), dp(50))
            }
            addView(badge)
            addView(label(title, 13f, p.text, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
            setOnClickListener { onClick() }
        }

    fun numField(value: String, hint: String): EditText = EditText(ctx).apply {
        setText(value)
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setTextColor(p.text)
        setHintTextColor(p.dim)
        textSize = 15f
        gravity = Gravity.CENTER
        background = rounded(p.field, p.stroke, 10)
        setPadding(dp(10), dp(8), dp(10), dp(8))
    }

    fun switch(title: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(ctx).apply {
        text = title
        textSize = 14f
        setTextColor(p.text)
        setPadding(dp(2), dp(8), dp(2), dp(8))
        isChecked = checked
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(states, intArrayOf(p.accent, p.dim))
        trackTintList = ColorStateList(states, intArrayOf(Themes.withAlpha(p.accent, 0x77), Themes.withAlpha(p.dim, 0x44)))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    /** Подписанное поле для пары «название — значение» в одной колонке. */
    fun labeled(title: String, et: EditText): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        addView(label(title, 12f, p.dim))
        addView(et)
    }

    fun row(vararg v: View): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    fun space(h: Int) = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
}
