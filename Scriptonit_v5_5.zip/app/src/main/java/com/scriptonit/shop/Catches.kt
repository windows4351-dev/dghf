package com.scriptonit.shop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.SystemClock
import android.view.Surface
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * «Уловы»: пока бот работает, экран копится в маленьком кольцевом буфере (≈10 кадров/с, JPEG, последние ~19 с).
 * Когда бот видит, что его запрос исполнен (исчез сам до отмены), из буфера берётся ~12 с ДО и ~3 с ПОСЛЕ улова
 * и кодируется в MP4 в фоне. Видео лежат в filesDir/catches/ и показываются в Настройки → Отладка → Уловы.
 *
 * Нагрузка на бота: раз в 100 мс один быстрый кадр уменьшается в заранее выделенный битмап (без аллокаций),
 * а сжатие JPEG и кодирование MP4 идут в отдельных потоках с низким приоритетом. Любая ошибка здесь гасится
 * и на ловлю не влияет. Размер кадра считается от реального разрешения экрана, никаких координат.
 */
object CatchRecorder {
    private const val PRE_MS = 12_000L
    private const val POST_MS = 3_000L
    private const val KEEP_MS = PRE_MS + POST_MS + 4_000L
    private const val EVERY_MS = 100L
    private const val LONG_SIDE = 960
    private const val MAX_BYTES = 40L * 1024L * 1024L
    private const val MAX_CLIPS = 30

    private class Shot(val t: Long, val jpg: ByteArray, val w: Int, val h: Int)

    class Clip(val file: File, val whenMs: Long, val price: Double)

    @Volatile private var enabled = false
    private val lock = Any()
    private val shots = ArrayDeque<Shot>()
    private var bytes = 0L
    private var lastAt = 0L
    private var pool: ArrayBlockingQueue<Bitmap>? = null
    private var srcW = 0
    private var srcH = 0
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRect = Rect()
    private val pending = AtomicInteger(0)

    private val worker = Executors.newSingleThreadExecutor { r ->
        Thread(r, "catch-jpeg").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }
    }
    private val encoder = Executors.newSingleThreadExecutor { r ->
        Thread(r, "catch-encode").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }
    }

    /** Вызывается при старте бота: читает переключатель «Записывать видео уловов» (по умолчанию включён). */
    fun start(ctx: Context) {
        synchronized(lock) { shots.clear(); bytes = 0L }
        lastAt = 0L
        enabled = BotPrefs.flag(ctx, "catch_video", true)
    }

    fun stop() {
        enabled = false
        if (pending.get() == 0) synchronized(lock) { shots.clear(); bytes = 0L }
    }

    /** Из ScreenGrabber.frame(): src — общий битмап кадра (его нельзя хранить), w×h — реальный размер экрана. */
    fun offer(src: Bitmap, w: Int, h: Int) {
        if (!enabled) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastAt < EVERY_MS) return
        try {
            val p = poolFor(w, h)
            val dst = p.poll() ?: return // фоновый поток не успел — этот кадр пропускаем
            lastAt = now
            srcRect.set(0, 0, w, h)
            dstRect.set(0, 0, dst.width, dst.height)
            Canvas(dst).drawBitmap(src, srcRect, dstRect, paint)
            worker.execute { pack(dst, now, p) }
        } catch (e: Throwable) {
        }
    }

    private fun poolFor(w: Int, h: Int): ArrayBlockingQueue<Bitmap> {
        val cur = pool
        if (cur != null && srcW == w && srcH == h) return cur
        val scale = minOf(1f, LONG_SIDE.toFloat() / max(w, h).toFloat())
        // стороны кратны 16 — так кодировщики H.264 работают на любом телефоне
        val ow = max(16, ((w * scale) / 16f).roundToInt() * 16)
        val oh = max(16, ((h * scale) / 16f).roundToInt() * 16)
        val np = ArrayBlockingQueue<Bitmap>(3)
        repeat(3) { np.add(Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)) }
        synchronized(lock) { shots.clear(); bytes = 0L }
        srcW = w
        srcH = h
        pool = np
        return np
    }

    private fun pack(bmp: Bitmap, t: Long, p: ArrayBlockingQueue<Bitmap>) {
        try {
            val bos = ByteArrayOutputStream(48 * 1024)
            bmp.compress(Bitmap.CompressFormat.JPEG, 60, bos)
            val arr = bos.toByteArray()
            synchronized(lock) {
                shots.addLast(Shot(t, arr, bmp.width, bmp.height))
                bytes += arr.size
                while (shots.isNotEmpty() && (t - shots.first().t > KEEP_MS || bytes > MAX_BYTES)) {
                    bytes -= shots.removeFirst().jpg.size
                }
            }
        } catch (e: Throwable) {
        } finally {
            p.offer(bmp)
        }
    }

    /** Улов: ждём ещё POST_MS, берём кадры вокруг этого момента и кодируем MP4 в фоне. */
    fun trigger(ctx: Context, price: Double, say: (String) -> Unit) {
        if (!enabled) return
        val at = SystemClock.elapsedRealtime()
        val wall = System.currentTimeMillis()
        val app = ctx.applicationContext
        pending.incrementAndGet()
        encoder.execute {
            try {
                val left = at + POST_MS - SystemClock.elapsedRealtime()
                if (left > 0) Thread.sleep(left)
                val clip = synchronized(lock) { shots.filter { it.t >= at - PRE_MS && it.t <= at + POST_MS } }
                if (clip.size < 5) {
                    say("Улов: видео не записалось — слишком мало кадров")
                    return@execute
                }
                val dir = File(app.filesDir, "catches")
                dir.mkdirs()
                val f = File(dir, "c_${wall}_${(price * 100).roundToInt()}.mp4")
                try {
                    writeMp4(clip, f)
                } catch (e: Throwable) {
                    f.delete()
                    throw e
                }
                val all = dir.listFiles { x -> x.name.endsWith(".mp4") }?.sortedBy { it.name } ?: emptyList()
                if (all.size > MAX_CLIPS) all.take(all.size - MAX_CLIPS).forEach { it.delete() }
                say("🎣 Видео улова сохранено: Настройки → Отладка → Уловы")
            } catch (e: Throwable) {
                say("Улов: видео не сохранилось — ${e.message}")
                DebugLog.add("Улов: ошибка записи видео: " + e.stackTraceToString().take(1200))
            } finally {
                if (pending.decrementAndGet() == 0 && !enabled) synchronized(lock) { shots.clear(); bytes = 0L }
            }
        }
    }

    fun list(ctx: Context): List<Clip> {
        val dir = File(ctx.filesDir, "catches")
        val files = dir.listFiles { x -> x.name.startsWith("c_") && x.name.endsWith(".mp4") && x.length() > 0L } ?: return emptyList()
        return files.sortedByDescending { it.name }.map { f ->
            val parts = f.nameWithoutExtension.split('_')
            Clip(
                f,
                parts.getOrNull(1)?.toLongOrNull() ?: f.lastModified(),
                (parts.getOrNull(2)?.toIntOrNull() ?: 0) / 100.0
            )
        }
    }

    /** JPEG-кадры → H.264 через Surface кодировщика → MP4. Время кадров берётся из записанных меток. */
    private fun writeMp4(clip: List<Shot>, out: File) {
        val w0 = clip.last().w
        val h0 = clip.last().h
        val frames = clip.filter { it.w == w0 && it.h == h0 }
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w0, h0).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 3_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 10)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var sf: Surface? = null
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surf = codec.createInputSurface()
            sf = surf
            codec.start()

            val info = MediaCodec.BufferInfo()
            val datas = ArrayList<ByteArray>()
            val flags = ArrayList<Int>()
            var outFmt: MediaFormat? = null
            var eos = false

            fun drain(untilEnd: Boolean) {
                var idle = 0
                while (!eos) {
                    val i = codec.dequeueOutputBuffer(info, if (untilEnd) 20_000L else 0L)
                    if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!untilEnd) return
                        idle++
                        if (idle > 250) throw IllegalStateException("кодировщик завис")
                    } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        outFmt = codec.outputFormat
                    } else if (i >= 0) {
                        idle = 0
                        val buf = codec.getOutputBuffer(i)
                        if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            val b = ByteArray(info.size)
                            buf.get(b)
                            datas.add(b)
                            flags.add(info.flags)
                        }
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) eos = true
                        codec.releaseOutputBuffer(i, false)
                    }
                }
            }

            for (s in frames) {
                val bmp = BitmapFactory.decodeByteArray(s.jpg, 0, s.jpg.size) ?: continue
                val cv = surf.lockCanvas(null)
                cv.drawBitmap(bmp, 0f, 0f, null)
                surf.unlockCanvasAndPost(cv)
                bmp.recycle()
                drain(false)
            }
            codec.signalEndOfInputStream()
            drain(true)

            val of = outFmt ?: throw IllegalStateException("кодировщик не вернул формат")
            val n = datas.size
            if (n == 0) throw IllegalStateException("кодировщик не выдал кадров")
            val t0 = frames.first().t
            val spanUs = (frames.last().t - t0) * 1000L
            val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val track = muxer.addTrack(of)
                muxer.start()
                val bi = MediaCodec.BufferInfo()
                for (k in 0 until n) {
                    // метки времени — реальные; если кодировщик выкинул кадры, растягиваем равномерно
                    val pts = if (n == frames.size) (frames[k].t - t0) * 1000L
                    else if (n > 1) spanUs * k / (n - 1) else 0L
                    bi.set(0, datas[k].size, pts, flags[k])
                    muxer.writeSampleData(track, ByteBuffer.wrap(datas[k]), bi)
                }
                muxer.stop()
            } finally {
                muxer.release()
            }
        } finally {
            try { codec.stop() } catch (e: Throwable) { }
            try { codec.release() } catch (e: Throwable) { }
            try { sf?.release() } catch (e: Throwable) { }
        }
    }
}
