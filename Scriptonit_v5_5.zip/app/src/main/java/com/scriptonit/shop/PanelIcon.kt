package com.scriptonit.shop

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Значок кнопки панели, нарисованный кодом: не зависит от шрифтов телефона (⏻ раньше рисовался пустым). */
class PanelIcon(ctx: Context, private val kind: Kind, private val fg: Int) : View(ctx) {
    enum class Kind { PLAY, STOP, LOG, GEAR, POWER, MOVE }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val r = m * 0.27f
        paint.color = fg
        paint.strokeWidth = m * 0.095f
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.style = Paint.Style.FILL
        when (kind) {
            Kind.PLAY -> {
                val p = Path().apply {
                    moveTo(cx - r * 0.6f, cy - r * 1.05f)
                    lineTo(cx - r * 0.6f, cy + r * 1.05f)
                    lineTo(cx + r * 1.05f, cy)
                    close()
                }
                c.drawPath(p, paint)
            }
            Kind.STOP -> c.drawRoundRect(RectF(cx - r, cy - r, cx + r, cy + r), m * 0.05f, m * 0.05f, paint)
            Kind.LOG -> {
                paint.style = Paint.Style.STROKE
                for (i in -1..1) c.drawLine(cx - r, cy + i * r * 0.8f, cx + r, cy + i * r * 0.8f, paint)
            }
            Kind.GEAR -> {
                paint.style = Paint.Style.STROKE
                c.drawCircle(cx, cy, r * 0.6f, paint)
                for (i in 0 until 8) {
                    val a = Math.PI * 2 * i / 8
                    c.drawLine(
                        cx + (cos(a) * r * 0.95f).toFloat(), cy + (sin(a) * r * 0.95f).toFloat(),
                        cx + (cos(a) * r * 1.3f).toFloat(), cy + (sin(a) * r * 1.3f).toFloat(), paint
                    )
                }
            }
            Kind.POWER -> {
                paint.style = Paint.Style.STROKE
                c.drawArc(RectF(cx - r, cy - r * 0.9f, cx + r, cy + r * 1.1f), -55f, 290f, false, paint)
                c.drawLine(cx, cy - r * 1.25f, cx, cy - r * 0.1f, paint)
            }
            Kind.MOVE -> {
                paint.style = Paint.Style.STROKE
                c.drawLine(cx - r * 1.2f, cy, cx + r * 1.2f, cy, paint)
                c.drawLine(cx, cy - r * 1.2f, cx, cy + r * 1.2f, paint)
                paint.style = Paint.Style.FILL
                val t = r * 0.55f
                fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
                    c.drawPath(Path().apply { moveTo(x1, y1); lineTo(x2, y2); lineTo(x3, y3); close() }, paint)
                }
                tri(cx - r * 1.5f, cy, cx - r * 1.05f, cy - t, cx - r * 1.05f, cy + t)
                tri(cx + r * 1.5f, cy, cx + r * 1.05f, cy - t, cx + r * 1.05f, cy + t)
                tri(cx, cy - r * 1.5f, cx - t, cy - r * 1.05f, cx + t, cy - r * 1.05f)
                tri(cx, cy + r * 1.5f, cx - t, cy + r * 1.05f, cx + t, cy + r * 1.05f)
            }
        }
    }
}
