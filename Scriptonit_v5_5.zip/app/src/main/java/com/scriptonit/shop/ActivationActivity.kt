package com.scriptonit.shop

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

/** Экран ввода ключа активации. Показывается, пока на устройстве нет подтверждённого ключа. */
class ActivationActivity : Activity() {

    private val pal by lazy { Themes.current(this) }
    private val bg get() = pal.bg0
    private val green get() = pal.accent
    private val textMain get() = pal.text
    private val textDim get() = pal.dim

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // тестовый режим: ключ не нужен, сразу в главный экран
        if (License.DEV_SKIP_LICENSE) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        // ключ уже активирован на этом устройстве — сразу в приложение (повторная проверка идёт в MainActivity)
        if (License.isActivatedLocally(this)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        val input = EditText(this).apply {
            hint = "SCRPT-XXXX-XXXX-XXXX"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setTextColor(textMain)
            setHintTextColor(textDim)
            textSize = 16f
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(pal.field)
                setStroke(dp(1), pal.stroke)
            }
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val progress = ProgressBar(this).apply { visibility = android.view.View.GONE }
        val button = Button(this).apply {
            text = "Активировать"
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(pal.onAccent)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.accent, pal.accent2)
            ).apply { cornerRadius = dp(14).toFloat() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(14) }
        }

        button.setOnClickListener {
            val key = input.text.toString().trim()
            if (key.isEmpty()) { toast("Введи ключ из бота"); return@setOnClickListener }
            button.isEnabled = false
            progress.visibility = android.view.View.VISIBLE
            Thread {
                val ok = License.activate(this, key)
                runOnUiThread {
                    progress.visibility = android.view.View.GONE
                    button.isEnabled = true
                    if (ok) {
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    } else {
                        toast("Ключ не подошёл: уже использован, неверен или нет связи с сервером")
                    }
                }
            }.start()
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(bg)
            addView(TextView(this@ActivationActivity).apply {
                text = "⚡ Scriptonit"
                textSize = 26f
                setTextColor(green)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
            addView(TextView(this@ActivationActivity).apply {
                text = "Введи ключ активации, который прислал бот @Scriptonit_Shop_bot после оплаты"
                textSize = 13f
                setTextColor(textDim)
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(20))
            })
            addView(input)
            addView(button)
            addView(progress.apply { (layoutParams as? LinearLayout.LayoutParams)?.topMargin = dp(14) })
        }
        setContentView(col)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
