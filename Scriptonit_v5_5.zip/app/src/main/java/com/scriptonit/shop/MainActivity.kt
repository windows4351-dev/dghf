package com.scriptonit.shop

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private enum class Screen { HOME, SCRIPTS, KEYBOARD, CREATOR, SETTINGS, CATCHES }

    private var screen = Screen.HOME
    private lateinit var ui: Ui
    private lateinit var p: Palette

    private val fields = LinkedHashMap<String, EditText>()
    private var ocrLoading = false
    private var editing: File? = null
    private var draftName = ""
    private var draftBody = ""

    // элементы главного экрана
    private var stA11y: TextView? = null
    private var stOverlay: TextView? = null
    private var stKb: TextView? = null
    private var stOcr: TextView? = null
    private var stPanel: TextView? = null
    private var etName: EditText? = null
    private var etBody: EditText? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.init(this)
        if (!License.DEV_SKIP_LICENSE && !License.isActivatedLocally(this)) {
            startActivity(Intent(this, ActivationActivity::class.java))
            finish()
            return
        }
        Store.ensureDemo(this)
        // 5.2: прежнее обновление раз в 5 с заменено на быстрый перезаход (1 с); дальше значение не трогаем
        if (BotPrefs.raw(this, "mig52", "") != "1") BotPrefs.save(this, mapOf("refresh" to "1", "mig52" to "1"))
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        if (intent?.getStringExtra("open") == "settings") screen = Screen.SETTINGS
        render()
        loadOcrData()
        if (!License.DEV_SKIP_LICENSE) recheckLicense()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.getStringExtra("open") == "settings") go(Screen.SETTINGS)
    }

    private fun recheckLicense() {
        val sp = getSharedPreferences("license_check", MODE_PRIVATE)
        val last = sp.getLong("at", 0)
        if (System.currentTimeMillis() - last < 24 * 60 * 60 * 1000L) return
        Thread {
            val ok = License.verifySaved(this)
            sp.edit().putLong("at", System.currentTimeMillis()).apply()
            if (!ok) runOnUiThread {
                License.clear(this)
                toast("Ключ больше не действителен")
                startActivity(Intent(this, ActivationActivity::class.java))
                finish()
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen == Screen.CATCHES) go(Screen.SETTINGS) else if (screen != Screen.HOME) go(Screen.HOME) else super.onBackPressed()
    }

    // ---------- навигация ----------

    private fun go(s: Screen) {
        saveSettings()
        screen = s
        render()
    }

    private fun render() {
        p = Themes.current(this)
        ui = Ui(this, p)
        fields.clear()
        stA11y = null; stOverlay = null; stKb = null; stOcr = null; stPanel = null
        etName = null; etBody = null
        window.statusBarColor = p.bg0
        window.navigationBarColor = p.bg0
        val body = when (screen) {
            Screen.HOME -> buildHome()
            Screen.SCRIPTS -> buildScripts()
            Screen.KEYBOARD -> buildKeyboard()
            Screen.CREATOR -> buildCreator()
            Screen.SETTINGS -> buildSettings()
            Screen.CATCHES -> buildCatches()
        }
        val title = when (screen) {
            Screen.HOME -> "SCRIPTONIT"
            Screen.SCRIPTS -> "СКРИПТЫ"
            Screen.KEYBOARD -> "КЛАВИАТУРА"
            Screen.CREATOR -> "ДОБАВИТЬ СКРИПТ"
            Screen.SETTINGS -> "НАСТРОЙКИ"
            Screen.CATCHES -> "УЛОВЫ"
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(34), dp(14), dp(10))
            val left = ui.label(if (screen == Screen.HOME) "☰" else "←", 22f, p.text, true).apply {
                setPadding(dp(6), dp(4), dp(14), dp(4))
                setOnClickListener { if (screen == Screen.HOME) showMenu() else go(if (screen == Screen.CATCHES) Screen.SETTINGS else Screen.HOME) }
            }
            addView(left)
            addView(ui.label(title, 16f, p.text, true).apply {
                gravity = Gravity.CENTER
                letterSpacing = 0.1f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(View(this@MainActivity).apply { layoutParams = LinearLayout.LayoutParams(dp(40), 1) })
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(body)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ui.screenBg()
            addView(bar)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        refresh()
    }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(2), dp(14), dp(24))
    }

    private fun showMenu() {
        val items = arrayOf("Журнал отладки", "Змейка")
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> showDebugLog()
                    1 -> startActivity(Intent(this, SnakeActivity::class.java))
                }
            }
            .show()
    }

    // ---------- главный экран ----------

    private fun statusLine(onClick: () -> Unit): TextView = ui.label("", 12f, p.dim).apply {
        setPadding(dp(2), dp(3), dp(2), dp(3))
        setOnClickListener { onClick() }
    }

    private fun buildHome(): View {
        val col = column()
        col.addView(ui.label("Маркет · ловля запросов", 12f, p.dim).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(6))
        })
        col.addView(ui.tile("☰", "Скрипты", false, 1f) { go(Screen.SCRIPTS) }.apply {
            (layoutParams as LinearLayout.LayoutParams).width = ViewGroup.LayoutParams.MATCH_PARENT
            (layoutParams as LinearLayout.LayoutParams).weight = 0f
        })
        col.addView(ui.row(
            ui.tile("⌨", "Клавиатура", false, 1f) { go(Screen.KEYBOARD) },
            ui.tile("＋", "Добавить скрипт", false, 1f) { editing = null; draftName = ""; draftBody = ""; go(Screen.CREATOR) }
        ))
        col.addView(ui.row(
            ui.tile("⚙", "Настройки", false, 1f) { go(Screen.SETTINGS) },
            ui.tile("⏻", "Остановить", true, 1f) {
                stopService(Intent(this, OverlayService::class.java))
                OverlayService.up = false
                toast("Панель остановлена")
                refresh()
            }
        ))

        val st = ui.card()
        stA11y = statusLine { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); toast("Найди Scriptonit и включи") }
        stOverlay = statusLine { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        stKb = statusLine { go(Screen.KEYBOARD) }
        stOcr = statusLine { loadOcrData(force = true) }
        stPanel = statusLine { }
        listOf(stA11y, stOverlay, stKb, stOcr, stPanel).forEach { st.addView(it) }
        col.addView(st)

        col.addView(ui.space(10))
        col.addView(ui.ghost("Telegram-канал") { open("https://t.me/Scriptoniit") })
        col.addView(ui.ghost("Telegram-бот") { open("https://t.me/Scriptonit_Shop_bot") })
        return col
    }

    private fun mark(ok: Boolean, text: String) = (if (ok) "✔️ " else "❌ ") + text

    private fun dot(tv: TextView?, ok: Boolean?, text: String) {
        if (tv == null) return
        val sb = android.text.SpannableStringBuilder("●  $text")
        val col = when (ok) { true -> p.ok; false -> p.warn; null -> p.dim }
        sb.setSpan(android.text.style.ForegroundColorSpan(col), 0, 1, 0)
        tv.text = sb
    }

    private fun refresh() {
        if (screen != Screen.HOME) return
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val def = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        dot(stA11y, ClickService.instance != null, "Спец. возможности")
        dot(stOverlay, Settings.canDrawOverlays(this), "Поверх других окон")
        val kbOn = imm.enabledInputMethodList.any { it.packageName == packageName }
        dot(stKb, kbOn && def.startsWith(packageName), "Клавиатура Scriptonit выбрана (обязательно)")
        when {
            ocrLoading -> dot(stOcr, null, "Распознавание цен: загрузка…")
            Ocr.hasData(this) -> dot(stOcr, true, "Распознавание цен")
            else -> dot(stOcr, false, "Распознавание цен — нажми, чтобы скачать")
        }
        dot(stPanel, if (OverlayService.up) true else null, if (OverlayService.up) "Панель запущена" else "Панель не запущена")
    }

    // ---------- скрипты ----------

    private fun buildScripts(): View {
        val col = column()
        val cfg = BotPrefs.load(this)
        val c = ui.card()
        c.addView(ui.label("Ловля запросов (Маркет)", 16f, p.text, true))
        c.addView(ui.label(
            "Режим: " + cfg.modeTitle() +
                " · цена ${cfg.min.toInt()}–${cfg.max.toInt()} G\nПеред запуском открой страницу предмета и включи галочку «Только мои запросы».",
            12f, p.dim
        ).apply { setPadding(0, dp(4), 0, dp(2)) })
        c.addView(ui.primary("▶  Запустить скрипт") { Store.setMarket(this); startPanel() })
        c.addView(ui.ghost("Настройка скрипта") { go(Screen.SETTINGS) })
        col.addView(c)

        val files = Store.list(this)
        if (files.isNotEmpty()) col.addView(ui.section("МОИ СКРИПТЫ (ТАПЫ И СВАЙПЫ)"))
        for (f in files) {
            val card = ui.card()
            card.addView(ui.label(f.nameWithoutExtension, 15f, p.text, true))
            card.addView(ui.primary("▶  Запустить") { Store.select(this, f); startPanel() })
            card.addView(ui.row(
                ui.ghost("Изменить") { editing = f; draftName = f.nameWithoutExtension; draftBody = f.readText(); go(Screen.CREATOR) }
                    .apply { layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { topMargin = dp(8); rightMargin = dp(4) } },
                ui.ghost("Удалить") { Store.delete(this, f); toast("Удалено"); render() }
                    .apply { layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { topMargin = dp(8); leftMargin = dp(4) } }
            ))
            col.addView(card)
        }
        return col
    }

    // ---------- клавиатура ----------

    private fun buildKeyboard(): View {
        val col = column()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val def = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val kbOn = imm.enabledInputMethodList.any { it.packageName == packageName }
        val c = ui.card()
        c.addView(ui.label("Scriptonit Keyboard", 16f, p.text, true))
        c.addView(ui.label(
            "Цена вводится командой из бота, без нажатий по клавишам. Если клавиатура не выбрана, бот пробует вставить текст через спец. возможности.",
            12f, p.dim
        ).apply { setPadding(0, dp(4), 0, dp(6)) })
        c.addView(ui.label(mark(kbOn, "Включена") + "   " + mark(def.startsWith(packageName), "Выбрана"), 12f, p.text))
        c.addView(ui.primary("1. Включить клавиатуру") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        c.addView(ui.primary("2. Выбрать Scriptonit") { imm.showInputMethodPicker() })
        c.addView(ui.ghost("Вернуть обычную клавиатуру") { imm.showInputMethodPicker() })
        c.addView(ui.switch("Невидимая клавиатура (быстрее: ставка без анимации клавиш)", BotPrefs.flag(this, "kb_hidden", true)) {
            BotPrefs.save(this, mapOf("kb_hidden" to if (it) "1" else "0"))
        })
        col.addView(c)

        col.addView(ui.section("ПРОВЕРКА"))
        val t = ui.card()
        val test = EditText(this).apply {
            hint = "Тестовое поле"
            setTextColor(p.text)
            setHintTextColor(p.dim)
            gravity = Gravity.CENTER
            background = ui.rounded(p.field, p.stroke, 10)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        t.addView(test)
        t.addView(ui.ghost("Вставить «24.00» командой") {
            val ok = ScriptoKeyboardService.instance?.replaceText("24.00") == true
            if (!ok) toast("Нажми в поле и выбери клавиатуру Scriptonit")
        })
        col.addView(t)
        return col
    }

    // ---------- создатель ----------

    private fun buildCreator(): View {
        val col = column()
        val c = ui.card()
        etName = EditText(this).apply {
            hint = "Название скрипта"
            setText(draftName)
            setTextColor(p.text); setHintTextColor(p.dim)
            background = ui.rounded(p.field, p.stroke, 10)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        etBody = EditText(this).apply {
            hint = "ref 2400 1080\ntap 1200 540\nwait 300"
            setText(draftBody)
            setTextColor(p.text); setHintTextColor(p.dim)
            typeface = Typeface.MONOSPACE
            textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            gravity = Gravity.TOP
            minLines = 12
            background = ui.rounded(p.field, p.stroke, 10)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        c.addView(etName)
        c.addView(ui.space(8))
        c.addView(etBody)
        c.addView(ui.primary("Сохранить") {
            try {
                val f = Store.save(this, etName?.text.toString().ifBlank { "script" }, etBody?.text.toString())
                toast("Сохранено: ${f.nameWithoutExtension}")
                go(Screen.SCRIPTS)
            } catch (e: Exception) {
                toast(e.message ?: "Ошибка в скрипте")
            }
        })
        c.addView(ui.ghost("Вставить пример") { etBody?.setText(Store.DEMO) })
        c.addView(ui.ghost("Импорт из файла") {
            draftName = etName?.text.toString(); draftBody = etBody?.text.toString()
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1
            )
        })
        c.addView(ui.ghost("Загрузить по ссылке") { askUrl() })
        col.addView(c)
        col.addView(ui.label(
            "Команды: ref W H · tap X Y · swipe X1 Y1 X2 Y2 [мс] · wait МС · repeat N … end · loop … end. Координаты пересчитываются под экран автоматически.",
            11f, p.dim
        ).apply { setPadding(dp(4), dp(10), dp(4), 0) })
        return col
    }

    // ---------- настройки ----------

    private fun addField(key: String, hint: String, def: String): EditText =
        ui.numField(BotPrefs.raw(this, key, def), hint).also { fields[key] = it }

    private fun buildSettings(): View {
        val col = column()

        col.addView(ui.section("ТЕМА"))
        val perRow = 4
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (chunk in Themes.all.chunked(perRow)) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(6) }
            }
            for (t in chunk) {
                val sel = t.id == p.id
                rowLayout.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = ui.rounded(
                        Themes.withAlpha(t.dot, 0x22), if (sel) t.dot else Themes.withAlpha(t.dot, 0x55), 14, if (sel) 2 else 1
                    )
                    setPadding(dp(4), dp(10), dp(4), dp(8))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
                    addView(View(this@MainActivity).apply {
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(t.dot) }
                        layoutParams = LinearLayout.LayoutParams(dp(26), dp(26))
                    })
                    addView(ui.label(t.name, 11f, p.text, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
                    setOnClickListener { saveSettings(); Themes.set(this@MainActivity, t.id); render() }
                })
            }
            // добиваем последнюю строку пустыми ячейками, чтобы плитки были одной ширины
            repeat(perRow - chunk.size) {
                rowLayout.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f).apply { setMargins(dp(3), 0, dp(3), 0) } })
            }
            grid.addView(rowLayout)
        }
        col.addView(grid)

        col.addView(ui.section("РЕЖИМ ЛОВЛИ"))
        val mode = ui.card()
        val modeNow = (BotPrefs.raw(this, "aggr", "0").toIntOrNull() ?: 0).coerceIn(0, 2)
        val desc = ui.label("", 12f, p.dim).apply { setPadding(dp(2), dp(8), dp(2), 0) }
        val bal = ui.ghost("Сбалансированный") { }
        val ag = ui.ghost("Агрессивный") { }
        val cu = ui.ghost("Кастомный") { }
        val cuBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cuBox.addView(ui.row(ui.labeled("Перебивать на, G (например 0.03)", addField("cstep", "0.03", "0.03"))))
        fun paint(b: android.widget.Button, on: Boolean) {
            b.background = if (on) ui.gradient(p.accent, p.accent2, 12) else ui.rounded(p.field, p.stroke, 12)
            b.setTextColor(if (on) p.onAccent else p.text)
        }
        fun style(m: Int) {
            paint(bal, m == 0)
            paint(ag, m == 1)
            paint(cu, m == 2)
            cuBox.visibility = if (m == 2) View.VISIBLE else View.GONE
            desc.text = when (m) {
                1 -> "Как только запрос вырос — сразу ставит на копейку ниже первого лота (цена лота читается в окне запроса)."
                2 -> "Новый запрос + твоя сумма (например 0.03), но не выше «лот − 0.01». Если на твою сумму места до лота нет — ставит «лот − 0.01»: на полную цену лота бот не заходит."
                else -> "Новый запрос + 0.01, но не выше «лот − 0.01». Если места до лота нет — ставит «лот − 0.01»."
            }
        }
        style(modeNow)
        bal.setOnClickListener { BotPrefs.save(this, mapOf("aggr" to "0")); style(0) }
        ag.setOnClickListener { BotPrefs.save(this, mapOf("aggr" to "1")); style(1) }
        cu.setOnClickListener { BotPrefs.save(this, mapOf("aggr" to "2")); style(2) }
        mode.addView(ui.row(
            bal.apply { layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(4); topMargin = dp(4) } },
            ag.apply { layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(4); topMargin = dp(4) } }
        ))
        mode.addView(cu.apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(8) } })
        mode.addView(cuBox)
        mode.addView(desc)
        col.addView(mode)

        col.addView(ui.section("ПАРАМЕТРЫ"))
        val prm = ui.card()
        prm.addView(ui.row(ui.labeled("Цена от, G", addField("min", "10", "10")), ui.labeled("Цена до, G", addField("max", "99999", "99999"))))
        prm.addView(ui.row(ui.labeled("Перезаход в окно, с (от 0.3)", addField("refresh", "1", "1")), ui.labeled("Отмена через, с (0 — не отменять)", addField("cancel", "2", "2"))))
        prm.addView(ui.row(ui.labeled("Работать, мин", addField("minutes", "119", "119")), ui.labeled("Лимит ставок всего", addField("bids", "300", "300"))))
        prm.addView(ui.row(ui.labeled("Ставок в минуту (0 — без лимита)", addField("perminute", "0", "0"))))
        prm.addView(ui.label("Лимит в минуту нужен, чтобы не гоняться за полной ценой с другими скриптами: сверх лимита бот перебития пропускает.", 11f, p.dim).apply { setPadding(dp(4), dp(6), dp(4), 0) })
        col.addView(prm)

        col.addView(ui.section("ПАНЕЛЬ ПОВЕРХ ИГРЫ"))
        val pn = ui.card()
        val scale = (BotPrefs.raw(this, "panel_scale", "75").toIntOrNull() ?: 75).coerceIn(40, 110)
        val scaleLabel = ui.label("Размер: $scale%", 13f, p.text, true)
        pn.addView(scaleLabel)
        pn.addView(SeekBar(this).apply {
            max = 70
            progress = scale - 40
            progressTintList = android.content.res.ColorStateList.valueOf(p.accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(p.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    scaleLabel.text = "Размер: ${v + 40}%"
                    BotPrefs.save(this@MainActivity, mapOf("panel_scale" to (v + 40).toString()))
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        pn.addView(ui.switch("Показывать журнал на панели", BotPrefs.flag(this, "panel_log", true)) {
            BotPrefs.save(this, mapOf("panel_log" to if (it) "1" else "0"))
        })
        pn.addView(ui.label("Размер применится при следующем запуске панели.", 11f, p.dim))
        col.addView(pn)

        col.addView(ui.section("АВТОНАСТРОЙКА"))
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        val au = ui.card()
        au.addView(ui.label(
            "Экран ${dm.widthPixels}×${dm.heightPixels}. При каждом запуске бот сам находит «Заказать», снимает раскладку окна запроса и проверяет, что цены читаются.",
            12f, p.dim
        ))
        val hasData = Ocr.hasData(this)
        au.addView(ui.ghost(if (ocrLoading) "Загрузка данных распознавания…" else if (hasData) "Данные распознавания: готово ✔" else "Скачать данные распознавания") {
            loadOcrData(force = true)
        })
        col.addView(au)

        col.addView(ui.section("ОТЛАДКА"))
        val dbg = ui.card()
        dbg.addView(ui.label("Запусти бота, затем открой журнал и нажми «Поделиться». Кадры (PNG) показывают, куда бот нажимает.", 12f, p.dim))
        dbg.addView(ui.ghost("🧾  Журнал отладки") { showDebugLog() })
        dbg.addView(ui.ghost("🖼  Кадры (PNG)") { shareFrames() })
        dbg.addView(ui.ghost("🎣  Уловы (видео)") { go(Screen.CATCHES) })
        col.addView(dbg)
        return col
    }

    /** Сохраняет числовые поля (есть только на экране настроек). */
    private fun saveSettings() {
        if (fields.isEmpty()) return
        BotPrefs.save(this, fields.mapValues { it.value.text.toString().trim() })
    }

    // ---------- данные распознавания ----------

    private fun loadOcrData(force: Boolean = false) {
        if (ocrLoading) return
        if (Ocr.hasData(this) && !force) return
        if (Ocr.hasData(this)) { toast("Данные уже загружены"); return }
        ocrLoading = true
        refresh()
        Thread {
            val ok = Ocr.download(this)
            if (!LabelOcr.hasData(this)) LabelOcr.download(this)
            runOnUiThread {
                ocrLoading = false
                if (!ok) toast("Не удалось скачать данные цен. Проверь интернет")
                if (screen == Screen.SETTINGS) render() else refresh()
            }
        }.start()
    }

    // ---------- скрипты: загрузка ----------

    private fun askUrl() {
        val input = EditText(this).apply { hint = "https://…/script.txt" }
        AlertDialog.Builder(this)
            .setTitle("Ссылка на скрипт")
            .setView(input)
            .setPositiveButton("Загрузить") { _, _ -> download(input.text.toString().trim()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun download(url: String) {
        if (!url.startsWith("https://")) { toast("Нужна ссылка https://"); return }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                val body = conn.inputStream.use { it.readBytes() }
                if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
                val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "script" }
                runOnUiThread {
                    draftName = name.substringBeforeLast('.')
                    draftBody = String(body, Charsets.UTF_8)
                    render()
                    toast("Загружено — проверь и нажми «Сохранить»")
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Не удалось загрузить: ${e.message}") }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            1 -> importFile(data)
            2 -> {
                val svc = Intent(this, OverlayService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(svc)
                toast("Панель запущена — переходите в игру")
                moveTaskToBack(true)
            }
        }
    }

    private fun importFile(data: Intent) {
        val uri = data.data ?: return
        try {
            var name = "script"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
            val body = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (body.size > 200_000) throw IllegalArgumentException("Файл слишком большой")
            draftName = name.substringBeforeLast('.')
            draftBody = String(body, Charsets.UTF_8)
            render()
            toast("Файл загружен — проверь и нажми «Сохранить»")
        } catch (e: Exception) {
            toast(e.message ?: "Не удалось прочитать файл")
        }
    }

    // ---------- запуск панели ----------

    private fun startPanel() {
        saveSettings()
        if (!Settings.canDrawOverlays(this)) {
            toast("Разреши показ поверх окон")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (ClickService.instance == null) {
            toast("Включи службу доступности: найди Scriptonit")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (Store.mode(this) == "market" && !KeyboardGuard.isDefault(this)) {
            AlertDialog.Builder(this)
                .setTitle("Включи клавиатуру Scriptonit")
                .setMessage("Для ловли запросов клавиатура Scriptonit обязательна: цена вводится через неё. Включи её и выбери по умолчанию — это два нажатия.")
                .setPositiveButton("Открыть") { _, _ -> go(Screen.KEYBOARD) }
                .setNegativeButton("Позже", null)
                .show()
            return
        }
        if (Store.mode(this) == "market" && !Ocr.hasData(this)) {
            toast("Данные распознавания ещё не загружены")
            loadOcrData()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    // ---------- уловы ----------

    private fun buildCatches(): View {
        val col = column()
        val sw = ui.card()
        sw.addView(ui.switch("Записывать видео уловов", BotPrefs.flag(this, "catch_video", true)) {
            BotPrefs.save(this, mapOf("catch_video" to if (it) "1" else "0"))
        })
        sw.addView(ui.label(
            "Улов — когда твой запрос исчез сам до того, как бот его отменил (его исполнили). Тогда сохраняется видео экрана: " +
                "≈12 с до улова и 3 с после. Запись применяется при следующем запуске скрипта. " +
                "Работает, если включена «Отмена через» (не 0).",
            11f, p.dim
        ).apply { setPadding(dp(2), dp(2), dp(2), dp(2)) })
        col.addView(sw)

        val clips = CatchRecorder.list(this)
        if (clips.isEmpty()) {
            col.addView(ui.card().apply {
                addView(ui.label("Пока уловов нет. Как только скрипт поймает скин, видео появится здесь.", 13f, p.dim))
            })
            return col
        }
        col.addView(ui.section("ВИДЕО (${clips.size})"))
        val fmtTime = java.text.SimpleDateFormat("dd.MM  HH:mm:ss", java.util.Locale.getDefault())
        for (c in clips) {
            val card = ui.card()
            val price = if (c.price > 0.0) "  ·  " + String.format(java.util.Locale.US, "%.2f", c.price) + " G" else ""
            card.addView(ui.label("🎣  " + fmtTime.format(java.util.Date(c.whenMs)) + price, 15f, p.text, true))
            card.addView(ui.label(String.format(java.util.Locale.US, "%.1f МБ", c.file.length() / 1048576.0), 11f, p.dim))
            fun btn(text: String, left: Int, right: Int, onClick: () -> Unit) = ui.ghost(text, onClick).apply {
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(left); rightMargin = dp(right); topMargin = dp(8) }
            }
            card.addView(ui.row(
                btn("▶ Смотреть", 0, 4) { playCatch(c.file) },
                btn("Поделиться", 4, 4) { shareFile(c.file, "video/mp4") },
                btn("Удалить", 4, 0) {
                    AlertDialog.Builder(this)
                        .setMessage("Удалить это видео?")
                        .setPositiveButton("Удалить") { _, _ -> c.file.delete(); render() }
                        .setNegativeButton("Отмена", null)
                        .show()
                }
            ))
            col.addView(card)
        }
        return col
    }

    private fun playCatch(f: File) {
        val vv = android.widget.VideoView(this)
        val h = (resources.displayMetrics.widthPixels * 0.62).toInt()
        val box = android.widget.FrameLayout(this).apply {
            addView(vv, android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER
            ))
        }
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        }
        vv.setVideoPath(f.absolutePath)
        vv.setOnPreparedListener { it.isLooping = true; vv.start() }
        vv.setOnErrorListener { _, _, _ -> toast("Не удалось воспроизвести видео"); true }
        vv.setOnClickListener { if (vv.isPlaying) vv.pause() else vv.start() }
        AlertDialog.Builder(this)
            .setView(holder)
            .setNegativeButton("Закрыть", null)
            .setOnDismissListener { vv.stopPlayback() }
            .show()
    }

    // ---------- журнал отладки ----------

    private fun showDebugLog() {
        val full = DebugLog.read()
        val shown = if (full.isEmpty()) "Журнал пуст. Запусти бота (▶ на панели) — сюда попадёт всё, что он делает." else full.takeLast(30_000)
        val tv = TextView(this).apply {
            text = shown
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(p.text)
            setTextIsSelectable(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val sv = ScrollView(this).apply {
            addView(tv)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.5).toInt()
            )
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(sv)
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(8), dp(6), dp(8), 0)
                addView(ui.small("Как текст") { shareText(full) })
                if (DebugLog.hasFrame()) addView(ui.small("Кадры (PNG)") { shareFrames() })
            })
        }
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
        AlertDialog.Builder(this)
            .setTitle("Журнал отладки")
            .setView(col)
            .setPositiveButton("Поделиться файлом") { _, _ -> DebugLog.logFile()?.let { shareFile(it, "text/plain") } }
            .setNeutralButton("Очистить") { _, _ -> DebugLog.clear(); toast("Журнал очищен") }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun shareText(full: String) {
        val text = if (full.isEmpty()) "(журнал пуст)" else full.takeLast(60_000)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Scriptonit — журнал отладки")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(i, "Отправить журнал"))
    }

    private fun shareFrames() {
        val files = DebugLog.frameFiles()
        if (files.isEmpty()) { toast("Кадров нет"); return }
        try {
            val uris = ArrayList<Uri>()
            for (f in files) uris.add(FileProvider.getUriForFile(this, "$packageName.fileprovider", f))
            val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                clipData = android.content.ClipData.newRawUri("", uris[0]).also { cd ->
                    for (k in 1 until uris.size) cd.addItem(android.content.ClipData.Item(uris[k]))
                }
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Отправить кадры"))
        } catch (e: Exception) {
            toast("Не удалось поделиться: ${e.message}")
        }
    }

    private fun shareFile(f: File, mime: String) {
        if (!f.exists() || f.length() == 0L) { toast("Файл пуст"); return }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = android.content.ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Отправить"))
        } catch (e: Exception) {
            toast("Не удалось поделиться: ${e.message}")
        }
    }

    private fun open(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
