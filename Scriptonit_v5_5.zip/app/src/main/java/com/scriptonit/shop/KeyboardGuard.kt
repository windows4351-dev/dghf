package com.scriptonit.shop

import android.content.Context
import android.provider.Settings

/** Клавиатура Scriptonit обязательна для ловли: без неё цену не ввести быстро и надёжно. */
object KeyboardGuard {
    const val MESSAGE = "Включи клавиатуру Scriptonit и выбери её по умолчанию (Клавиатура → шаги 1 и 2)"

    fun isDefault(ctx: Context): Boolean {
        val def = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return def.startsWith(ctx.packageName)
    }
}
