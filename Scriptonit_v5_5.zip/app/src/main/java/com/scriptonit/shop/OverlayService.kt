package com.scriptonit.shop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var playBtn: View
    private lateinit var stopBtn: View
    private lateinit var nameView: TextView
    private lateinit var statusView: TextView

    private val runner = ScriptRunner()
    private val main = Handler(Looper.getMainLooper())
    private val botScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var botJob: Job? = null
    private var projection: MediaProjection? = null
    private var grabber: ScreenGrabber? = null

    companion object {
        @Volatile var up = false
    }

    private val running get() = runner.running || botJob?.isActive == true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        DebugLog.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, buildNotification())
        }
        if (projection == null) {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projection = mpm.getMediaProjection(code, data)
            projection?.let { grabber = ScreenGrabber(this, it) }
        }
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        up = false
        botJob?.cancel()
        runner.stop()
        grabber?.release()
        try { projection?.stop() } catch (e: Exception) { }
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("panel", "Панель", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "panel")
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Scriptonit")
            .setContentText("Панель запущена")
            .setOngoing(true)
            .build()
    }

    /** Размер панели (1.0 = 100%) — настройка «Размер панели». */
    private var UI = 0.75f

    private fun dp(v: Int) = if (v == 0) 0 else (v * resources.displayMetrics.density * UI).toInt().coerceAtLeast(1)

    private val logLines = ArrayList<String>()
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private var logVisible = true
    private lateinit var pal: Palette

    private fun btn(kind: PanelIcon.Kind, danger: Boolean = false): View = android.widget.FrameLayout(this).apply {
        val a = if (danger) pal.warn else pal.accent
        val b = if (danger) 0xFFFF3D2E.toInt() else pal.accent2
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b))
            .apply { cornerRadius = dp(12).toFloat() }
        layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        addView(PanelIcon(this@OverlayService, kind, if (danger) 0xFFFFFFFF.toInt() else pal.onAccent),
            android.widget.FrameLayout.LayoutParams(-1, -1))
    }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        pal = Themes.current(this)
        UI = (BotPrefs.raw(this, "panel_scale", "75").toIntOrNull() ?: 75).coerceIn(40, 110) / 100f
        logVisible = BotPrefs.flag(this, "panel_log", true)

        nameView = TextView(this).apply {
            text = "TG:@Scriptoniit"
            textSize = 10f * UI
            setTextColor(pal.text)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(dp(6), dp(2), dp(6), 0)
        }
        playBtn = btn(PanelIcon.Kind.PLAY)
        stopBtn = btn(PanelIcon.Kind.STOP, danger = true)
        val logBtn = btn(PanelIcon.Kind.LOG)
        val gear = btn(PanelIcon.Kind.GEAR)
        val power = btn(PanelIcon.Kind.POWER)
        val handle = btn(PanelIcon.Kind.MOVE)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(playBtn); addView(stopBtn); addView(logBtn); addView(gear); addView(power); addView(handle)
        }

        logView = TextView(this).apply {
            textSize = 9f * UI
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(pal.text)
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        logScroll = ScrollView(this).apply {
            background = GradientDrawable().apply {
                setColor(Themes.withAlpha(pal.bg0, 0xE0)); cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(264), dp(96)).apply { setMargins(dp(3), dp(2), dp(3), dp(3)) }
            visibility = if (logVisible) View.VISIBLE else View.GONE
            addView(logView)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Themes.withAlpha(pal.card0, 0xF2), Themes.withAlpha(pal.bg0, 0xF2))
            ).apply { cornerRadius = dp(16).toFloat(); setStroke(dp(2), pal.accent) }
            addView(nameView)
            addView(top)
            addView(logScroll)
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(8)
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(root, params)
                }
            }
            true
        }
        playBtn.setOnClickListener { if (!running) toggle() }
        stopBtn.setOnClickListener { if (running) toggle() else toast("Скрипт не запущен") }
        logBtn.setOnClickListener {
            logVisible = !logVisible
            logScroll.visibility = if (logVisible) View.VISIBLE else View.GONE
            runCatching { wm.updateViewLayout(root, params) }
        }
        power.setOnClickListener { stopSelf() }
        gear.setOnClickListener {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java).putExtra("open", "settings")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (e: Exception) { toast("Не удалось открыть приложение") }
        }

        wm.addView(root, params)
        panel = root
        up = true
        refresh()
        setStatus("Панель запущена ✔ — нажми ▶ в нужной игре")
    }

    private fun refresh() {
        playBtn.alpha = if (running) 0.4f else 1f
        stopBtn.alpha = if (running) 1f else 0.4f
    }

    /** Строка в журнале на панели (и в файле отладки). */
    private fun setStatus(msg: String) {
        if (msg.isEmpty()) return
        main.post {
            val ts = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            logLines.add("[$ts] $msg")
            while (logLines.size > 40) logLines.removeAt(0)
            if (::logView.isInitialized) {
                logView.text = logLines.joinToString("\n")
                logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
    }

    private fun toggle() {
        if (running) {
            botJob?.cancel()
            runner.stop()
            setStatus("Остановлено")
            refresh()
            return
        }
        val svc = ClickService.instance
        if (svc == null) {
            toast("Включи службу доступности в приложении")
            return
        }
        if (!License.DEV_SKIP_LICENSE && !License.isActivatedLocally(this)) {
            toast("Приложение не активировано")
            stopSelf()
            return
        }
        if (Store.mode(this) == "market" && !KeyboardGuard.isDefault(this)) {
            setStatus("Включи клавиатуру Scriptonit — без неё скрипт не запускается")
            toast(KeyboardGuard.MESSAGE)
            return
        }
        setStatus("Скрипт запущен ✔")
        if (Store.mode(this) == "market") startMarket(svc) else startScript(svc)
        refresh()
    }

    private fun startMarket(svc: ClickService) {
        val g = grabber
        if (g == null) {
            toast("Нет доступа к экрану, запусти панель заново")
            return
        }
        if (!Ocr.hasData(this)) {
            toast("Данные распознавания ещё не загружены")
            return
        }
        val cfg = BotPrefs.load(this)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val devInfo = "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.SDK_INT}, " +
            "экран ${dm.widthPixels}x${dm.heightPixels}, dpi ${dm.densityDpi}"
        botJob = botScope.launch {
            val ocr = Ocr(this@OverlayService)
            // LabelOcr необязателен: если данные ещё не скачаны, бот продолжает работать по цвету, как и раньше
            val labelOcr = if (LabelOcr.hasData(this@OverlayService)) LabelOcr(this@OverlayService) else null
            try {
                DebugLog.add("=== Старт маркет-бота: $devInfo; OCR цен=${ocr.ready}; OCR надписей=${labelOcr?.ready}; DEV_SKIP_LICENSE=${License.DEV_SKIP_LICENSE}")
                if (!ocr.ready) {
                    setStatus("Распознавание цен не запустилось")
                    DebugLog.add("Распознавание цен не запустилось (нет eng.traineddata или ошибка Tesseract)")
                } else {
                    CatchRecorder.start(this@OverlayService)
                    MarketBot(
                        svc, g, ocr, cfg,
                        { Stats.addBid(this@OverlayService) },
                        { msg -> setStatus(msg); DebugLog.add(msg) },
                        labelOcr,
                        onCatch = { price ->
                            CatchRecorder.trigger(this@OverlayService, price) { msg -> setStatus(msg); DebugLog.add(msg) }
                        }
                    ).run()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (e is SecurityException && e.message?.contains("media projection", ignoreCase = true) == true) {
                    // система сама остановила запись экрана — новый доступ можно получить только заново запустив панель
                    setStatus("Запись экрана отключилась — закрой панель и запусти её заново из приложения")
                } else {
                    setStatus("Ошибка: ${e.message}")
                }
                DebugLog.add("ИСКЛЮЧЕНИЕ: " + e.stackTraceToString().take(2000))
            } finally {
                CatchRecorder.stop()
                ocr.close()
                labelOcr?.close()
                main.post { refresh() }
            }
        }
    }

    private fun startScript(svc: ClickService) {
        val file = Store.selected(this)
        if (file == null) {
            toast("Выбери скрипт в приложении")
            return
        }
        val script = try {
            ScriptParser.parse(file.readText())
        } catch (e: Exception) {
            toast(e.message ?: "Ошибка в скрипте")
            return
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        runner.start(svc, script, dm.widthPixels, dm.heightPixels) { refresh() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
