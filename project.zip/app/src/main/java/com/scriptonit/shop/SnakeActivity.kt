package com.scriptonit.shop

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

class SnakeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(SnakeView(this))
    }
}

/** Простая змейка: свайпы задают направление, тап после проигрыша начинает заново. */
class SnakeView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = ArrayList<IntArray>()
    private val food = IntArray(2)
    private val rnd = java.util.Random()
    private val handler = Handler(Looper.getMainLooper())

    private val cols = 18
    private var rows = 30
    private var cell = 0f
    private var dx = 1
    private var dy = 0
    private var nx = 1
    private var ny = 0
    private var score = 0
    private var best = Stats.snakeBest(ctx)
    private var alive = true
    private var downX = 0f
    private var downY = 0f

    private val tick = object : Runnable {
        override fun run() {
            step()
            invalidate()
            if (alive) handler.postDelayed(this, (170 - score * 3L).coerceAtLeast(70L))
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cell = w / cols.toFloat()
        rows = (h / cell).toInt().coerceAtLeast(10)
        reset()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    private fun reset() {
        handler.removeCallbacks(tick)
        body.clear()
        val cx = cols / 2
        val cy = rows / 2
        body.add(intArrayOf(cx, cy))
        body.add(intArrayOf(cx - 1, cy))
        body.add(intArrayOf(cx - 2, cy))
        dx = 1; dy = 0; nx = 1; ny = 0
        score = 0
        alive = true
        placeFood()
        handler.postDelayed(tick, 400)
        invalidate()
    }

    private fun placeFood() {
        while (true) {
            val x = rnd.nextInt(cols)
            val y = rnd.nextInt(rows)
            if (body.none { it[0] == x && it[1] == y }) {
                food[0] = x
                food[1] = y
                return
            }
        }
    }

    private fun step() {
        dx = nx
        dy = ny
        val hx = body[0][0] + dx
        val hy = body[0][1] + dy
        if (hx < 0 || hy < 0 || hx >= cols || hy >= rows || body.any { it[0] == hx && it[1] == hy }) {
            alive = false
            if (score > best) {
                best = score
                Stats.setSnakeBest(context, best)
            }
            return
        }
        body.add(0, intArrayOf(hx, hy))
        if (hx == food[0] && hy == food[1]) {
            score++
            placeFood()
        } else {
            body.removeAt(body.size - 1)
        }
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF060D09.toInt())
        paint.style = Paint.Style.FILL
        paint.color = 0xFF0E1D15.toInt()
        for (x in 0 until cols) for (y in 0 until rows) {
            if ((x + y) % 2 == 0) c.drawRect(x * cell, y * cell, (x + 1) * cell, (y + 1) * cell, paint)
        }
        paint.color = 0xFFFBBF24.toInt()
        c.drawCircle((food[0] + 0.5f) * cell, (food[1] + 0.5f) * cell, cell * 0.36f, paint)
        for ((i, p) in body.withIndex()) {
            paint.color = if (i == 0) 0xFF6EF0B4.toInt() else 0xFF22C55E.toInt()
            val r = RectF(p[0] * cell + 2, p[1] * cell + 2, (p[0] + 1) * cell - 2, (p[1] + 1) * cell - 2)
            c.drawRoundRect(r, cell * 0.3f, cell * 0.3f, paint)
        }
        drawFace(c)
        paint.color = 0xFFE6FFEE.toInt()
        paint.textSize = cell * 0.9f
        c.drawText("$score  ·  рекорд $best", cell * 0.5f, cell * 1.2f, paint)
        if (!alive) {
            paint.textSize = cell * 1.3f
            paint.textAlign = Paint.Align.CENTER
            c.drawText("Конец. Тап — заново", width / 2f, height / 2f, paint)
            paint.textAlign = Paint.Align.LEFT
        }
    }

    /** Мордочка на голове змейки: глаза смотрят по направлению движения, язычок иногда выглядывает. */
    private fun drawFace(c: Canvas) {
        if (body.isEmpty()) return
        val head = body[0]
        val hx = (head[0] + 0.5f) * cell
        val hy = (head[1] + 0.5f) * cell
        val fwd = cell * 0.26f
        val side = cell * 0.17f
        val eyeR = cell * 0.09f
        val dx = dx.toFloat(); val dy = dy.toFloat()
        val perpX = -dy; val perpY = dx

        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        val e1x = hx + dx * fwd + perpX * side
        val e1y = hy + dy * fwd + perpY * side
        val e2x = hx + dx * fwd - perpX * side
        val e2y = hy + dy * fwd - perpY * side
        c.drawCircle(e1x, e1y, eyeR, paint)
        c.drawCircle(e2x, e2y, eyeR, paint)
        paint.color = 0xFF0B1F14.toInt()
        c.drawCircle(e1x + dx * eyeR * 0.3f, e1y + dy * eyeR * 0.3f, eyeR * 0.5f, paint)
        c.drawCircle(e2x + dx * eyeR * 0.3f, e2y + dy * eyeR * 0.3f, eyeR * 0.5f, paint)

        if (alive && (System.currentTimeMillis() / 400) % 3 == 0L) {
            paint.color = 0xFFEF4444.toInt()
            paint.strokeWidth = cell * 0.05f
            val tipX = hx + dx * cell * 0.75f
            val tipY = hy + dy * cell * 0.75f
            val baseX = hx + dx * cell * 0.45f
            val baseY = hy + dy * cell * 0.45f
            c.drawLine(baseX, baseY, tipX, tipY, paint)
            c.drawLine(tipX, tipY, tipX + perpX * cell * 0.12f, tipY + perpY * cell * 0.12f, paint)
            c.drawLine(tipX, tipY, tipX - perpX * cell * 0.12f, tipY - perpY * cell * 0.12f, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
            }
            MotionEvent.ACTION_UP -> {
                val mx = e.x - downX
                val my = e.y - downY
                if (!alive) {
                    reset()
                } else if (abs(mx) > abs(my) && abs(mx) > 30) {
                    if (mx > 0 && dx != -1) { nx = 1; ny = 0 } else if (mx < 0 && dx != 1) { nx = -1; ny = 0 }
                } else if (abs(my) > 30) {
                    if (my > 0 && dy != -1) { nx = 0; ny = 1 } else if (my < 0 && dy != 1) { nx = 0; ny = -1 }
                }
            }
        }
        return true
    }
}
