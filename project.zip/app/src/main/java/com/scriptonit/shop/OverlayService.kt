package com.scriptonit.shop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var playBtn: TextView
    private lateinit var nameView: TextView
    private lateinit var statusView: TextView

    private val runner = ScriptRunner()
    private val main = Handler(Looper.getMainLooper())
    private val botScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var botJob: Job? = null
    private var projection: MediaProjection? = null
    private var grabber: ScreenGrabber? = null

    private val running get() = runner.running || botJob?.isActive == true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        DebugLog.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, buildNotification())
        }
        if (projection == null) {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projection = mpm.getMediaProjection(code, data)
            projection?.let { grabber = ScreenGrabber(this, it) }
        }
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        botJob?.cancel()
        runner.stop()
        grabber?.release()
        try { projection?.stop() } catch (e: Exception) { }
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("panel", "Панель", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "panel")
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Scriptonit")
            .setContentText("Панель запущена")
            .setOngoing(true)
            .build()
    }

    /** Панель в 1.5 раза меньше прежней: все размеры (dp и шрифты) умножаются на этот коэффициент. */
    private val UI = 1f / 1.5f

    private fun dp(v: Int) = if (v == 0) 0 else (v * resources.displayMetrics.density * UI).toInt().coerceAtLeast(1)

    private fun chip(text: String, size: Float = 18f): TextView = TextView(this).apply {
        this.text = text
        textSize = size * UI
        setTextColor(0xFFD5FBE2.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = chip("⚡", 20f)
        nameView = chip("", 13f)
        playBtn = chip("▶", 22f).apply { setTextColor(0xFF22C55E.toInt()) }
        val close = chip("✕", 16f)
        top.addView(handle)
        top.addView(nameView)
        top.addView(playBtn)
        top.addView(close)

        statusView = TextView(this).apply {
            textSize = 11f * UI
            setTextColor(0xFF7FA38C.toInt())
            setPadding(dp(10), 0, dp(10), dp(4))
            visibility = View.GONE
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
            background = GradientDrawable().apply {
                setColor(0xF2060D09.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFF22C55E.toInt())
            }
            addView(top)
            addView(statusView)
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(8)
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(root, params)
                }
            }
            true
        }
        playBtn.setOnClickListener { toggle() }
        close.setOnClickListener { stopSelf() }

        wm.addView(root, params)
        panel = root
        refresh()
    }

    private fun refresh() {
        nameView.text = "Tg:@Scriptonit_Shop"
        playBtn.text = if (running) "■" else "▶"
    }

    private fun setStatus(msg: String) {
        main.post {
            statusView.text = msg
            statusView.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
            panel?.let { v -> runCatching { wm.updateViewLayout(v, params) } }
        }
    }

    private fun toggle() {
        if (running) {
            botJob?.cancel()
            runner.stop()
            setStatus("")
            refresh()
            return
        }
        val svc = ClickService.instance
        if (svc == null) {
            toast("Включи службу доступности в приложении")
            return
        }
        if (!License.DEV_SKIP_LICENSE && !License.isActivatedLocally(this)) {
            toast("Приложение не активировано")
            stopSelf()
            return
        }
        if (Store.mode(this) == "market") startMarket(svc) else startScript(svc)
        refresh()
    }

    private fun startMarket(svc: ClickService) {
        val g = grabber
        if (g == null) {
            toast("Нет доступа к экрану, запусти панель заново")
            return
        }
        if (!Ocr.hasData(this)) {
            toast("Данные распознавания ещё не загружены")
            return
        }
        val cfg = BotPrefs.load(this)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val devInfo = "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.SDK_INT}, " +
            "экран ${dm.widthPixels}x${dm.heightPixels}, dpi ${dm.densityDpi}"
        botJob = botScope.launch {
            val ocr = Ocr(this@OverlayService)
            // LabelOcr необязателен: если данные ещё не скачаны, бот продолжает работать по цвету, как и раньше
            val labelOcr = if (LabelOcr.hasData(this@OverlayService)) LabelOcr(this@OverlayService) else null
            try {
                DebugLog.add("=== Старт маркет-бота: $devInfo; OCR цен=${ocr.ready}; OCR надписей=${labelOcr?.ready}; DEV_SKIP_LICENSE=${License.DEV_SKIP_LICENSE}")
                if (!ocr.ready) {
                    setStatus("Не удалось запустить распознавание цен")
                    DebugLog.add("Распознавание цен не запустилось (нет eng.traineddata или ошибка Tesseract)")
                } else {
                    MarketBot(
                        svc, g, ocr, cfg,
                        { Stats.addBid(this@OverlayService) },
                        { msg -> setStatus(msg); DebugLog.add(msg) },
                        labelOcr
                    ).run()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (e is SecurityException && e.message?.contains("media projection", ignoreCase = true) == true) {
                    // система сама остановила запись экрана — новый доступ можно получить только заново запустив панель
                    setStatus("Запись экрана отключилась — закрой панель и запусти её заново из приложения")
                } else {
                    setStatus("Ошибка: ${e.message}")
                }
                DebugLog.add("ИСКЛЮЧЕНИЕ: " + e.stackTraceToString().take(2000))
            } finally {
                ocr.close()
                labelOcr?.close()
                main.post { refresh() }
            }
        }
    }

    private fun startScript(svc: ClickService) {
        val file = Store.selected(this)
        if (file == null) {
            toast("Выбери скрипт в приложении")
            return
        }
        val script = try {
            ScriptParser.parse(file.readText())
        } catch (e: Exception) {
            toast(e.message ?: "Ошибка в скрипте")
            return
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        runner.start(svc, script, dm.widthPixels, dm.heightPixels) { refresh() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
