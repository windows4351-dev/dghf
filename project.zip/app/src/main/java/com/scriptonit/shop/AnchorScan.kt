package com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max

/**
 * Поиск элементов интерфейса по цвету, без привязки к конкретному разрешению или
 * раскладке экрана. Кнопка «Заказать» и синие кнопки «Купить»/«Отмена» в Standoff 2
 * имеют один и тот же цвет независимо от размера окна — меняется только их положение
 * и масштаб. Ищет СВЯЗНЫЕ пятна нужного цвета (не просто границы всех подходящих
 * точек), поэтому не путает кнопку со случайными похожими пикселями в другом месте
 * экрана — это проверено на реальных скриншотах из разных мест игры.
 */
object AnchorScan {
    data class Band(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
        val w get() = x1 - x0
        val h get() = y1 - y0
        val cx get() = (x0 + x1) / 2
        val cy get() = (y0 + y1) / 2
    }

    val ORDER_COLOR = Triple(242, 163, 52)   // кнопка «Заказать»
    val ACTION_COLOR = Triple(131, 154, 202) // кнопки «Купить» / «Отмена»
    private const val TOL = 46
    private const val MIN_CELLS = 6

    private class Blob(val band: Band, val cells: Int)

    private fun dist(c: Int, t: Triple<Int, Int, Int>): Int =
        abs(Color.red(c) - t.first) + abs(Color.green(c) - t.second) + abs(Color.blue(c) - t.third)

    private fun matches(c: Int, t: Triple<Int, Int, Int>, tol: Int = TOL): Boolean = dist(c, t) < tol

    private fun clampRegion(frame: Frame, region: Rect?): Rect {
        val rx0 = (region?.left ?: 0).coerceIn(0, frame.w - 1)
        val ry0 = (region?.top ?: 0).coerceIn(0, frame.h - 1)
        val rx1 = (region?.right ?: frame.w).coerceIn(rx0 + 1, frame.w)
        val ry1 = (region?.bottom ?: frame.h).coerceIn(ry0 + 1, frame.h)
        return Rect(rx0, ry0, rx1, ry1)
    }

    /** Все связные пятна цвета в области, БЕЗ фильтра размера/пропорций (только минимум ячеек). */
    private fun rawClusters(frame: Frame, target: Triple<Int, Int, Int>, step: Int, region: Rect?, minCells: Int, tol: Int): List<Blob> {
        val bmp = frame.bmp
        val rg = clampRegion(frame, region)
        val cells = HashSet<Long>()
        fun key(gx: Int, gy: Int) = (gx.toLong() shl 20) or (gy.toLong() and 0xFFFFF)
        var y = rg.top
        while (y < rg.bottom) {
            var x = rg.left
            while (x < rg.right) {
                if (matches(bmp.getPixel(x, y), target, tol)) cells.add(key(x / step, y / step))
                x += step
            }
            y += step
        }
        if (cells.size < minCells) return emptyList()

        val visited = HashSet<Long>()
        val result = ArrayList<Blob>()
        for (start in cells) {
            if (start in visited) continue
            val stack = ArrayDeque<Long>()
            stack.addLast(start); visited.add(start)
            var minGx = Int.MAX_VALUE; var minGy = Int.MAX_VALUE; var maxGx = Int.MIN_VALUE; var maxGy = Int.MIN_VALUE
            var size = 0
            while (stack.isNotEmpty()) {
                val c = stack.removeLast()
                val gx = (c shr 20).toInt()
                val gy = (c and 0xFFFFF).toInt()
                size++
                if (gx < minGx) minGx = gx
                if (gx > maxGx) maxGx = gx
                if (gy < minGy) minGy = gy
                if (gy > maxGy) maxGy = gy
                for (dx in -2..2) for (dy in -2..2) {
                    val n = key(gx + dx, gy + dy)
                    if (n in cells && n !in visited) {
                        visited.add(n); stack.addLast(n)
                    }
                }
            }
            if (size < minCells) continue
            result.add(Blob(Band(minGx * step, minGy * step, maxGx * step, maxGy * step), size))
        }
        return result
    }

    /** null — пятно годится как кнопка; иначе причина отказа (для диагностики). */
    private fun rejectReason(frame: Frame, b: Band): String? {
        val minW = frame.w * 0.025f; val maxW = frame.w * 0.38f
        val minH = frame.h * 0.01f; val maxH = frame.h * 0.2f
        if (b.w < minW) return "слишком узкое (ширина ${b.w} < ${minW.toInt()})"
        if (b.w > maxW) return "слишком широкое (ширина ${b.w} > ${maxW.toInt()})"
        if (b.h < minH) return "слишком низкое (высота ${b.h} < ${minH.toInt()})"
        if (b.h > maxH) return "слишком высокое (высота ${b.h} > ${maxH.toInt()})"
        return null
    }

    /** Все связные пятна нужного цвета в области (каждое — отдельный элемент списка), уже прошедшие проверку размера/пропорций. */
    private fun clusters(frame: Frame, target: Triple<Int, Int, Int>, step: Int, region: Rect?): List<Band> =
        rawClusters(frame, target, step, region, MIN_CELLS, TOL).map { it.band }.filter { rejectReason(frame, it) == null }

    /** Пятна, прошедшие все фильтры — то, что реально видит бот. */
    fun candidates(frame: Frame, target: Triple<Int, Int, Int>, step: Int = 5, region: Rect? = null): List<Band> =
        clusters(frame, target, step, region)

    /** СЫРОЕ число проб, совпавших с цветом (до кластеризации и до фильтра размера). */
    fun rawCount(frame: Frame, target: Triple<Int, Int, Int>, step: Int = 5, region: Rect? = null, tol: Int = TOL): Int {
        val rg = clampRegion(frame, region)
        var n = 0
        var y = rg.top
        while (y < rg.bottom) {
            var x = rg.left
            while (x < rg.right) {
                if (matches(frame.bmp.getPixel(x, y), target, tol)) n++
                x += step
            }
            y += step
        }
        return n
    }

    private fun rgb(c: Int) = "rgb(${Color.red(c)},${Color.green(c)},${Color.blue(c)})"

    /** Общая картина кадра: средний цвет и яркость. Почти чёрный кадр = запись экрана заблокирована. */
    fun frameStats(frame: Frame): String {
        val sx = max(1, frame.w / 24)
        val sy = max(1, frame.h / 40)
        var r = 0L; var g = 0L; var b = 0L; var n = 0; var mxL = 0
        var y = 0
        while (y < frame.h) {
            var x = 0
            while (x < frame.w) {
                val c = frame.bmp.getPixel(x, y)
                r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
                val l = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (l > mxL) mxL = l
                x += sx
            }
            y += sy
        }
        if (n == 0) return "  кадр пуст"
        val note = if (mxL < 12) "  ← кадр почти чёрный: запись экрана, возможно, заблокирована" else ""
        return "  средний цвет кадра rgb(${r / n},${g / n},${b / n}), максимальная яркость $mxL$note"
    }

    /** Подробный отчёт о поиске цвета в области: сырые счётчики, ближайший цвет, пятна и причины отказа. */
    fun diagnose(frame: Frame, name: String, target: Triple<Int, Int, Int>, step: Int = 5, region: Rect? = null): String {
        val rg = clampRegion(frame, region)
        var sampled = 0; var n46 = 0; var n90 = 0; var n140 = 0
        var best = Int.MAX_VALUE; var bestC = 0; var bestX = 0; var bestY = 0
        var sumR = 0L; var sumG = 0L; var sumB = 0L; var sn = 0
        var y = rg.top
        while (y < rg.bottom) {
            var x = rg.left
            while (x < rg.right) {
                val c = frame.bmp.getPixel(x, y)
                val d = dist(c, target)
                sampled++
                if (d < TOL) n46++
                if (d < 90) n90++
                if (d < 140) { n140++; sumR += Color.red(c); sumG += Color.green(c); sumB += Color.blue(c); sn++ }
                if (d < best) { best = d; bestC = c; bestX = x; bestY = y }
                x += step
            }
            y += step
        }
        val o = StringBuilder()
        o.append("▸ $name\n")
        o.append("  цель rgb(${target.first},${target.second},${target.third}); область (${rg.left},${rg.top})–(${rg.right},${rg.bottom}); проб $sampled, шаг $step\n")
        o.append("  СЫРЫХ совпадений: допуск $TOL → $n46 | допуск 90 → $n90 | допуск 140 → $n140\n")
        if (sampled > 0) o.append("  ближайший к цели пиксель: ${rgb(bestC)} в ($bestX,$bestY), отличие $best (подходит, если < $TOL)\n")
        if (sn > 0) o.append("  средний цвет пикселей, близких к цели (допуск 140): rgb(${sumR / sn},${sumG / sn},${sumB / sn})\n")
        val blobs = rawClusters(frame, target, step, region, 1, TOL).sortedByDescending { it.cells }
        if (blobs.isEmpty()) {
            o.append("  пятен нужного цвета нет\n")
        } else {
            o.append("  пятна при допуске $TOL (до фильтра), всего ${blobs.size}:\n")
            for ((i, bl) in blobs.take(5).withIndex()) o.append("    ${blobDesc(frame, i + 1, bl)}\n")
        }
        if (n46 < MIN_CELLS && n90 > 0) {
            val loose = rawClusters(frame, target, step, region, 3, 90).sortedByDescending { it.cells }
            o.append("  при допуске 90 (цвет кнопки мог слегка отличаться), пятен ${loose.size}:\n")
            for ((i, bl) in loose.take(3).withIndex()) o.append("    ${blobDesc(frame, i + 1, bl)}\n")
        }
        return o.toString()
    }

    private fun blobDesc(frame: Frame, n: Int, bl: Blob): String {
        val b = bl.band
        val cx = b.cx.coerceIn(0, frame.bmp.width - 1)
        val cy = b.cy.coerceIn(0, frame.bmp.height - 1)
        val verdict = when {
            bl.cells < MIN_CELLS -> "ОТБРОШЕНО: мало ячеек (${bl.cells} < $MIN_CELLS)"
            else -> rejectReason(frame, b)?.let { "ОТБРОШЕНО: $it" } ?: "прошло фильтр"
        }
        return "#$n (${b.x0},${b.y0})–(${b.x1},${b.y1}) ${b.w}x${b.h}, ячеек ${bl.cells}, центр ${rgb(frame.bmp.getPixel(cx, cy))} → $verdict"
    }

    /**
     * Самое большое подходящее пятно нужного цвета — для одиночных элементов вроде
     * кнопки «Заказать», которая на экране только одна.
     */
    fun scan(frame: Frame, target: Triple<Int, Int, Int>, step: Int = 5, region: Rect? = null): Band? =
        clusters(frame, target, step, region).maxByOrNull { it.w.toLong() * it.h }

    /**
     * Кнопка такого же вида сразу под указанной — берётся ВЕРХНЯЯ (ближайшая) из
     * найденных в области, а не самая крупная: ниже кнопки «Заказать» друг под другом
     * могут стоять и «Отмена» (если уже есть свой запрос), и дальше по списку «Купить» —
     * нужна именно первая, иначе бот иногда путает её с нижним пунктом списка.
     */
    fun scanBelow(frame: Frame, target: Triple<Int, Int, Int>, above: Band, maxGapPx: Int, step: Int = 5): Band? =
        clustersBelow(frame, target, above, maxGapPx, step).firstOrNull()

    /** Все подходящие пятна под указанной кнопкой, от самого верхнего (ближайшего) к дальним. */
    fun clustersBelow(frame: Frame, target: Triple<Int, Int, Int>, above: Band, maxGapPx: Int, step: Int = 5): List<Band> {
        return clusters(frame, target, step, regionBelow(frame, above, maxGapPx)).sortedBy { it.y0 }
    }

    /** Область поиска под кнопкой — вынесена отдельно, чтобы диагностика смотрела в то же место. */
    fun regionBelow(frame: Frame, above: Band, maxGapPx: Int): Rect {
        val pad = above.w / 6
        return Rect(above.x0 - pad, above.y1, above.x1 + pad, (above.y1 + maxGapPx).coerceAtMost(frame.h))
    }

    fun probe(frame: Frame, band: Band, target: Triple<Int, Int, Int>): Boolean =
        band.cx in 0 until frame.w && band.cy in 0 until frame.h && matches(frame.bmp.getPixel(band.cx, band.cy), target)

    /** Полоса с ценой слева от кнопки: соотношение выведено из реальных скриншотов игры и не зависит от разрешения. */
    fun priceRegionLeftOf(button: Band): Rect {
        val l = (button.x0 - button.w * 0.80f).toInt()
        val r = (button.x0 - button.w * 0.03f).toInt()
        return Rect(l.coerceAtLeast(0), button.y0, r.coerceAtLeast(l + 10), button.y1)
    }

    /** Точка со смещением (dxW, dyW) от центра band, в единицах ширины band — не зависит от разрешения. */
    /**
     * Ищет галочку «Только мои запросы» по картинке: тёмный квадрат (≈0.167 ширины кнопки «Заказать»),
     * у которого со всех четырёх сторон снаружи светлее, чем внутри у края. Берётся минимум по четырём
     * сторонам — поэтому «птичка» внутри и текст рядом не мешают, а миниатюры предметов (рисунок внутри)
     * не проходят. По вертикали ищем вокруг расчётной строки py (±0.6 ширины кнопки), по горизонтали — по всей
     * полосе xFrom..xTo (расстояние от «Заказать» до галочки зависит от пропорций экрана, а высота строки — нет).
     * Из подходящих кандидатов берётся ближайший к строке и самый левый (первая галочка в ряду).
     * Проверено на кадрах 1920×1080 в обоих состояниях галочки.
     */
    fun findCheckbox(frame: Frame, py: Int, w: Int, xFrom: Int, xTo: Int): Pt? {
        val s = (w * 0.167f).toInt().coerceAtLeast(12)
        val g = maxOf(2, s / 10)
        val t = maxOf(g, s / 8)
        val h = s / 2
        val win = (w * 0.6f).toInt()
        val cxMin = xFrom.coerceIn(0, frame.w - 1)
        val cxMax = xTo.coerceIn(cxMin + 1, frame.w - 1)
        val x0 = (cxMin - s).coerceAtLeast(0)
        val x1 = (cxMax + s).coerceAtMost(frame.w)
        val y0 = (py - win - s).coerceAtLeast(0)
        val y1 = (py + win + s).coerceAtMost(frame.h)
        val gw = (x1 - x0 + g - 1) / g
        val gh = (y1 - y0 + g - 1) / g
        if (gw < 6 || gh < 6) return null
        val stride = gw + 1
        val ii = IntArray(stride * (gh + 1))
        for (j in 0 until gh) {
            var rowSum = 0
            val yy = minOf(y0 + j * g, frame.bmp.height - 1)
            for (i in 0 until gw) {
                val xx = minOf(x0 + i * g, frame.bmp.width - 1)
                val c = frame.bmp.getPixel(xx, yy)
                rowSum += (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                ii[(j + 1) * stride + (i + 1)] = ii[j * stride + (i + 1)] + rowSum
            }
        }
        fun mean(xa: Int, ya: Int, xb: Int, yb: Int): Float {
            val gx0 = maxOf(Math.floorDiv(xa - x0, g), 0)
            val gx1 = minOf(Math.floorDiv(xb - x0, g), gw)
            val gy0 = maxOf(Math.floorDiv(ya - y0, g), 0)
            val gy1 = minOf(Math.floorDiv(yb - y0, g), gh)
            val n = (gx1 - gx0) * (gy1 - gy0)
            if (n <= 0) return Float.NaN
            val sum = ii[gy1 * stride + gx1] - ii[gy0 * stride + gx1] - ii[gy1 * stride + gx0] + ii[gy0 * stride + gx0]
            return sum.toFloat() / n
        }
        val cxs = ArrayList<Int>()
        val cys = ArrayList<Int>()
        val scores = ArrayList<Float>()
        var best = -1000f
        var cy = (py - win).coerceAtLeast(0)
        while (cy <= minOf(frame.h, py + win)) {
            var cx = cxMin
            while (cx <= cxMax) {
                val l = cx - h; val r = cx + h; val tp = cy - h; val b = cy + h
                val top = mean(l + t, tp - t, r - t, tp) - mean(l + t, tp, r - t, tp + t)
                val bottom = mean(l + t, b, r - t, b + t) - mean(l + t, b - t, r - t, b)
                val left = mean(l - t, tp + t, l, b - t) - mean(l, tp + t, l + t, b - t)
                val right = mean(r, tp + t, r + t, b - t) - mean(r - t, tp + t, r, b - t)
                if (!top.isNaN() && !bottom.isNaN() && !left.isNaN() && !right.isNaN()) {
                    val sc = minOf(minOf(top, bottom), minOf(left, right))
                    cxs.add(cx); cys.add(cy); scores.add(sc)
                    if (sc > best) best = sc
                }
                cx += g
            }
            cy += g
        }
        if (best < 12f) return null
        var bestIdx = -1
        var bestKey = Long.MAX_VALUE
        val rowStep = maxOf(1, s / 2)
        for (k in scores.indices) {
            if (scores[k] >= best * 0.75f) {
                val rowBucket = (Math.abs(cys[k] - py) / rowStep).toLong()
                val key = rowBucket * 1_000_000L + cxs[k]
                if (key < bestKey) { bestKey = key; bestIdx = k }
            }
        }
        return if (bestIdx >= 0) Pt(cxs[bestIdx], cys[bestIdx]) else null
    }

    /** Центр масс почти белых пикселей в окне — центр белых цифр поля цены или белого крестика окна. */
    fun whiteCentroid(frame: Frame, cx: Int, cy: Int, halfW: Int, halfH: Int, thr: Int = 215, minCount: Int = 12): Pt? {
        val xa = (cx - halfW).coerceAtLeast(0)
        val xb = (cx + halfW).coerceAtMost(frame.w - 1)
        val ya = (cy - halfH).coerceAtLeast(0)
        val yb = (cy + halfH).coerceAtMost(frame.h - 1)
        var n = 0
        var sx = 0L
        var sy = 0L
        var y = ya
        while (y <= yb) {
            var x = xa
            while (x <= xb) {
                val c = frame.bmp.getPixel(x, y)
                val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (lum >= thr) { n++; sx += x; sy += y }
                x += 2
            }
            y += 2
        }
        return if (n >= minCount) Pt((sx / n).toInt(), (sy / n).toInt()) else null
    }

    fun offsetFrom(band: Band, dxW: Float, dyW: Float): android.graphics.Point =
        android.graphics.Point((band.cx + dxW * band.w).toInt(), (band.cy + dyW * band.w).toInt())
}
