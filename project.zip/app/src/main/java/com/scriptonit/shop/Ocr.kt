package com.scriptonit.shop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Чтение цены с кадра экрана. */
class Ocr(ctx: Context) {
    private val tess = TessBaseAPI()
    val ready: Boolean

    /** Что произошло при последнем чтении цены — для журнала отладки. */
    @Volatile var lastNote: String = ""

    init {
        var ok = false
        try {
            ok = hasData(ctx) && tess.init(ctx.filesDir.absolutePath, "eng")
            if (ok) {
                tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE)
                tess.setVariable(TessBaseAPI.VAR_CHAR_WHITELIST, "0123456789.,")
            }
        } catch (e: Exception) {
            ok = false
        }
        ready = ok
    }

    fun close() {
        try { tess.recycle() } catch (e: Exception) { }
    }

    /** Возвращает цену вида 61999.97 или null, если распознать не удалось. */
    fun readPrice(frame: Frame, region: Rect): Double? {
        if (!ready) { lastNote = "OCR не запущен"; return null }
        val r = Rect(
            region.left.coerceIn(0, frame.w - 1), region.top.coerceIn(0, frame.h - 1),
            region.right.coerceIn(region.left + 1, frame.w), region.bottom.coerceIn(region.top + 1, frame.h)
        )
        val crop = Bitmap.createBitmap(frame.bmp, r.left, r.top, r.width(), r.height())
        val k = 2
        val scaled = Bitmap.createScaledBitmap(crop, crop.width * k, crop.height * k, true)
        if (scaled !== crop) crop.recycle()
        val w = scaled.width
        val h = scaled.height
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        scaled.recycle()

        // адаптивный порог: работает и на ярком тексте, и на затемнённом (когда открыто окно)
        var mn = 255
        var mx = 0
        for (c in px) {
            val l = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
            if (l < mn) mn = l
            if (l > mx) mx = l
        }
        if (mx - mn < 25) { lastNote = "мало контраста в области (разброс яркости ${mx - mn} < 25)"; return null }
        val thr = (mn + mx) / 2
        for (i in px.indices) {
            val c = px[i]
            val l = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
            px[i] = if (l > thr) Color.BLACK else Color.WHITE
        }

        val pad = 24
        val out = Bitmap.createBitmap(w + pad * 2, h + pad * 2, Bitmap.Config.ARGB_8888)
        Canvas(out).drawColor(Color.WHITE)
        out.setPixels(px, 0, w, pad, pad, w, h)
        return try {
            tess.setImage(out)
            val raw = tess.getUTF8Text() ?: ""
            val parsed = parsePrice(raw)
            lastNote = "сырой текст='${raw.trim()}' → $parsed"
            parsed
        } catch (e: Exception) {
            lastNote = "исключение: ${e.message}"
            null
        } finally {
            out.recycle()
        }
    }

    companion object {
        private const val URL_ENG = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata"

        fun dataFile(ctx: Context) = File(File(ctx.filesDir, "tessdata"), "eng.traineddata")

        fun hasData(ctx: Context): Boolean = dataFile(ctx).let { it.exists() && it.length() > 1_000_000 }

        /** Скачивает языковые данные (один раз, около 4 МБ). */
        fun download(ctx: Context): Boolean {
            return try {
                val f = dataFile(ctx)
                f.parentFile?.mkdirs()
                val tmp = File(f.parentFile, "eng.tmp")
                val conn = URL(URL_ENG).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                if (tmp.length() > 1_000_000) tmp.renameTo(f) else { tmp.delete(); false }
            } catch (e: Exception) {
                false
            }
        }

        fun parsePrice(raw: String): Double? {
            var s = raw.replace(',', '.').filter { it.isDigit() || it == '.' }.trim('.')
            if (s.isEmpty()) return null
            if (!s.contains('.')) {
                if (s.length < 3) return null
                s = s.dropLast(2) + "." + s.takeLast(2)
            }
            if (!Regex("^\\d{1,6}\\.\\d{2}$").matches(s)) return null
            return s.toDoubleOrNull()
        }
    }
}
