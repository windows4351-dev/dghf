package com.scriptonit.shop

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Журнал отладки в файле (filesDir/debug/debug.log). Пишется всё, что бот сообщает на панель,
 * плюс подробная диагностика. Размер ограничен: при превышении ~100 КБ старое обрезается.
 * Последний «проблемный» кадр экрана сохраняется в debug_frame.png.
 */
object DebugLog {
    private const val MAX_BYTES = 100_000L
    private const val KEEP_CHARS = 40_000

    @Volatile private var dir: File? = null

    fun init(ctx: Context) {
        if (dir != null) return
        val d = File(ctx.applicationContext.filesDir, "debug")
        d.mkdirs()
        dir = d
    }

    fun logFile(): File? = dir?.let { File(it, "debug.log") }
    fun frameFile(): File? = dir?.let { File(it, "debug_frame.png") }

    @Synchronized
    fun add(msg: String) {
        val f = logFile() ?: return
        try {
            val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
            val sb = StringBuilder()
            msg.trimEnd('\n').split('\n').forEachIndexed { i, line ->
                sb.append(if (i == 0) ts else "            ").append(' ').append(line).append('\n')
            }
            f.appendText(sb.toString())
            if (f.length() > MAX_BYTES) trim(f)
        } catch (e: Exception) {
        }
    }

    private fun trim(f: File) {
        val text = f.readText()
        val tail = text.takeLast(KEEP_CHARS)
        val cut = tail.indexOf('\n')
        val clean = if (cut >= 0) tail.substring(cut + 1) else tail
        f.writeText("(старые записи обрезаны)\n" + clean)
    }

    @Synchronized
    fun read(): String = try { logFile()?.takeIf { it.exists() }?.readText() ?: "" } catch (e: Exception) { "" }

    @Synchronized
    fun clear() {
        try { logFile()?.delete() } catch (e: Exception) { }
        try { frameFile()?.delete() } catch (e: Exception) { }
    }

    fun hasFrame(): Boolean = frameFile()?.let { it.exists() && it.length() > 0 } == true

    /** Сохраняет кадр экрана как PNG (без потерь, чтобы по нему можно было проверять точные цвета). */
    fun saveFrame(frame: Frame) {
        val f = frameFile() ?: return
        try {
            val w = frame.w.coerceAtMost(frame.bmp.width)
            val h = frame.h.coerceAtMost(frame.bmp.height)
            val crop = Bitmap.createBitmap(frame.bmp, 0, 0, w, h)
            f.outputStream().use { crop.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (crop !== frame.bmp) crop.recycle()
            add("Кадр экрана ${w}x${h} сохранён в debug_frame.png")
        } catch (e: Exception) {
            add("Не удалось сохранить кадр: ${e.message}")
        }
    }
}
