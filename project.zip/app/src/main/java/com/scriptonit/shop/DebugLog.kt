package com.scriptonit.shop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Журнал отладки в файле (filesDir/debug/debug.log). Пишется всё, что бот сообщает на панель,
 * плюс подробная диагностика. Размер ограничен: при превышении ~100 КБ старое обрезается.
 * Последний «проблемный» кадр экрана сохраняется в debug_frame.png.
 */
object DebugLog {
    private const val MAX_BYTES = 100_000L
    private const val KEEP_CHARS = 40_000

    @Volatile private var dir: File? = null

    fun init(ctx: Context) {
        if (dir != null) return
        val d = File(ctx.applicationContext.filesDir, "debug")
        d.mkdirs()
        dir = d
    }

    fun logFile(): File? = dir?.let { File(it, "debug.log") }
    fun frameFile(tag: String = ""): File? =
        dir?.let { File(it, if (tag.isEmpty()) "debug_frame.png" else "debug_frame_$tag.png") }

    fun frameFiles(): List<File> =
        dir?.listFiles { f -> f.name.startsWith("debug_frame") && f.name.endsWith(".png") && f.length() > 0 }
            ?.sortedBy { it.name } ?: emptyList()

    @Synchronized
    fun add(msg: String) {
        val f = logFile() ?: return
        try {
            val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
            val sb = StringBuilder()
            msg.trimEnd('\n').split('\n').forEachIndexed { i, line ->
                sb.append(if (i == 0) ts else "            ").append(' ').append(line).append('\n')
            }
            f.appendText(sb.toString())
            if (f.length() > MAX_BYTES) trim(f)
        } catch (e: Exception) {
        }
    }

    private fun trim(f: File) {
        val text = f.readText()
        val tail = text.takeLast(KEEP_CHARS)
        val cut = tail.indexOf('\n')
        val clean = if (cut >= 0) tail.substring(cut + 1) else tail
        f.writeText("(старые записи обрезаны)\n" + clean)
    }

    @Synchronized
    fun read(): String = try { logFile()?.takeIf { it.exists() }?.readText() ?: "" } catch (e: Exception) { "" }

    @Synchronized
    fun clear() {
        try { logFile()?.delete() } catch (e: Exception) { }
        try { dir?.listFiles { f -> f.name.startsWith("debug_frame") }?.forEach { it.delete() } } catch (e: Exception) { }
    }

    fun hasFrame(): Boolean = frameFiles().isNotEmpty()

    /**
     * Сохраняет кадр экрана как PNG (без потерь). Если переданы метки — рисует на кадре красные кресты с подписями
     * в тех точках, куда бот будет нажимать: по такому снимку сразу видно, правильно ли он нашёл кнопки на этом экране.
     */
    fun saveFrame(frame: Frame, tag: String = "", marks: List<Pair<String, Pt>> = emptyList()) {
        val f = frameFile(tag) ?: return
        try {
            val w = frame.w.coerceAtMost(frame.bmp.width)
            val h = frame.h.coerceAtMost(frame.bmp.height)
            val crop = Bitmap.createBitmap(frame.bmp, 0, 0, w, h)
            val out = if (marks.isEmpty()) crop else crop.copy(Bitmap.Config.ARGB_8888, true)
            if (marks.isNotEmpty()) {
                val cv = Canvas(out)
                val r = maxOf(14f, w / 70f)
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = maxOf(3f, w / 450f)
                    color = Color.RED
                }
                val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = Color.YELLOW
                    textSize = maxOf(24f, w / 55f)
                    setShadowLayer(4f, 0f, 0f, Color.BLACK)
                }
                for ((label, p) in marks) {
                    val x = p.x.toFloat()
                    val y = p.y.toFloat()
                    cv.drawCircle(x, y, r, line)
                    cv.drawLine(x - r * 1.6f, y, x + r * 1.6f, y, line)
                    cv.drawLine(x, y - r * 1.6f, x, y + r * 1.6f, line)
                    cv.drawText(label, x + r * 1.2f, y - r * 1.2f, txt)
                }
            }
            f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (out !== crop) out.recycle()
            if (crop !== frame.bmp) crop.recycle()
            add("Кадр экрана ${w}x${h} сохранён (${f.name})" + if (marks.isNotEmpty()) " с метками: " + marks.joinToString { "${it.first}=${it.second.x},${it.second.y}" } else "")
        } catch (e: Exception) {
            add("Не удалось сохранить кадр: ${e.message}")
        }
    }
}
