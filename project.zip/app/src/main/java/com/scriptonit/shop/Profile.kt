package com.scriptonit.shop

import android.graphics.Color
import android.graphics.Rect

data class Pt(val x: Int, val y: Int)

/** Кадр экрана: bitmap может быть шире экрана из-за выравнивания строк, поэтому w и h хранятся отдельно. */
class Frame(val bmp: android.graphics.Bitmap, val w: Int, val h: Int)

/**
 * Определение элементов интерфейса маркета без привязки к конкретному разрешению или
 * аспекту экрана — все точки находятся на лету по кадру, координат «под один телефон»
 * здесь нет.
 *
 * Кнопка «Заказать» на странице предмета и синие кнопки «Купить»/«Отмена» ищутся
 * цветовым поиском (AnchorScan) — проверено на реальных скриншотах с телефона и с ПК,
 * цвет этих кнопок одинаков на обеих платформах, меняется только положение.
 *
 * Кнопка «Заказать» ВНУТРИ модального окна «Запрос на покупку» — того же цвета, что и
 * кнопка на странице, поэтому тоже находится цветовым поиском, когда открыто окно.
 * Поле цены и крестик закрытия окна у неё нет собственного цвета (тёмно-серые на
 * тёмно-сером), поэтому их положение вычисляется как смещение от найденной кнопки —
 * соотношение подобрано по реальному скриншоту открытого окна и не зависит от
 * разрешения экрана (в отличие от прежнего варианта с фиксированными долями экрана).
 */
object Profile {
    // --- смещения элементов окна «Запрос на покупку» относительно его кнопки «Заказать», ---
    // --- в единицах ширины этой кнопки (измерено по реальному скриншоту окна) ---
    // Смещения от центра кнопки «Заказать» в окне (в ширинах кнопки). Перепроверены по полному
    // кадру 2412x1084 (кнопка окна 402 px шириной): поле цены и крестик совпали с этими значениями.
    private const val PRICE_FIELD_DXW = -0.122f
    private const val PRICE_FIELD_DYW = -0.792f
    private const val CLOSE_DXW = 1.524f
    private const val CLOSE_DYW = -1.190f

    /** «Заказать» страницы лежит в правом столбце. Кнопка окна стоит по центру экрана, и поиск
     * по правой половине (x >= 0.5) резал её пополам и принимал за кнопку страницы. */
    private const val PAGE_LEFT = 0.62f

    /** Допустимые обрезки надписи «ЗАКАЗАТЬ»: распознавание иногда теряет буквы (видели «ЗАТЬ»). */
    private val ORDER_LABELS = arrayOf("ЗАКАЗ", "АКАЗ", "КАЗА", "АЗАТ", "ЗАТЬ")

    /** Окно поиска синей кнопки под «Заказать» — доля высоты кадра. В альбомной ориентации
     * первая «Купить» лежит ниже, чем при 0.22 (не находилась). */
    private const val ACTION_GAP = 0.40f

    /** Высота окна поиска синей кнопки под «Заказать»: берём бОльшее из доли высоты кадра и 2.4 ширины самой кнопки —
     * на планшетах (4:3, 16:10) высота кадра относительно интерфейса другая, а размер кнопки всегда соответствует масштабу интерфейса. */
    fun actionGapPx(f: Frame, order: AnchorScan.Band): Int =
        maxOf((f.h * ACTION_GAP).toInt(), (order.w * 2.4f).toInt()).coerceAtMost(f.h)

    // смещение галочки «Только мои запросы» относительно кнопки «Заказать» на СТРАНИЦЕ
    // (измерено сравнением отмеченного/неотмеченного состояния на реальном скриншоте)
    private const val CHECKBOX_DXW = -4.942f
    private const val CHECKBOX_DYW = 0.715f

    var orderBand: AnchorScan.Band? = null; private set
    /** Синяя кнопка ПЕРВОГО ЛОТА («Купить») — не нажимается никогда, нужна только чтобы прочитать цену лота (потолок ставки). */
    var actionBand: AnchorScan.Band? = null; private set
    /** Синяя кнопка «Отмена» нашего запроса: стоит почти вплотную под «Заказать» (≈0.4 её ширины), «Купить» первого лота — ≈1.0 ширины. */
    var cancelBand: AnchorScan.Band? = null; private set
    var dialogOrderBand: AnchorScan.Band? = null; private set

    /** Последнее найденное положение «Заказать» на странице — помним его, пока окно запроса открыто
     * и кнопка на странице затемнена (по цвету её тогда не найти). */
    private var pageOrderMemo: AnchorScan.Band? = null

    /** Пустое место рядом с «Заказать» страницы (левее кнопки, в строке «Запросов на покупку …»):
     * вне окна запроса. Касание тут закрывает окно, а на самой странице ничего не нажимает —
     * в отличие от «Назад», которое со страницы выкидывает в список маркета. */
    fun backdropTap(f: Frame): Pt? {
        val b = pageOrderMemo ?: return null
        return Pt((b.x0 - (b.w * 1.5f).toInt()).coerceIn(1, f.w - 1), b.cy.coerceIn(1, f.h - 1))
    }

    /** Читает надпись на найденном цветовом пятне, если дан labelOcr, и проверяет, что она похожа на ожидаемую. Без labelOcr (данные ещё не скачаны) пропускает проверку — остаётся старое поведение «только по цвету». */
    private fun verifyLabel(f: Frame, band: AnchorScan.Band, expectedContains: Array<String>, labelOcr: LabelOcr?): Boolean {
        if (labelOcr == null || !labelOcr.ready) return true
        val text = labelOcr.readLabel(f, band)
        if (text.isEmpty()) return true // пустой текст не отвергаем — распознавание не всегда читает идеально
        return expectedContains.any { text.contains(it) }
    }

    /** Поиск кнопки «Заказать» на СТРАНИЦЕ: ищем только в правой половине экрана, где она всегда находится — это отсекает случайные совпадения цвета слева (картинка предмета, фон). Если дан labelOcr, дополнительно читает надпись и отбрасывает ложные совпадения цвета, у которых написано что-то другое. */
    private fun rescanPage(f: Frame, labelOcr: LabelOcr? = null) {
        val region = Rect((f.w * PAGE_LEFT).toInt(), 0, f.w, f.h)
        var order = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5, region = region)
        if (order != null && !verifyLabel(f, order, ORDER_LABELS, labelOcr)) order = null
        if (order == null) {
            // другие пропорции экрана (планшеты): правый столбец может начинаться левее 0.62 — расширяем поиск,
            // но кнопку, стоящую ровно по центру (это окно запроса), не берём
            val wide = AnchorScan.candidates(f, AnchorScan.ORDER_COLOR, 5, Rect((f.w * 0.40f).toInt(), 0, f.w, f.h))
                .filter { it.cx > f.w * 0.58f && it.w > f.w * 0.04f && it.w >= it.h * 2.5f }
                .sortedByDescending { it.w.toLong() * it.h }
            order = wide.firstOrNull { verifyLabel(f, it, ORDER_LABELS, labelOcr) }
        }
        orderBand = order
        if (order != null) pageOrderMemo = order
        if (order == null) { actionBand = null; cancelBand = null; return }
        scanBlue(f, labelOcr)
    }

    /**
     * Ищет синие кнопки под «Заказать» и разделяет их по расстоянию (в ширинах кнопки «Заказать» — не зависит от экрана):
     * ближе 0.7 — «Отмена» нашего запроса, дальше 0.8 — «Купить» первого лота. Эти кнопки появляются и пропадают
     * (запрос поставлен/отменён, список грузится), поэтому не кэшируются и страница определяется только по «Заказать».
     */
    fun scanBlue(f: Frame, labelOcr: LabelOcr? = null) {
        val order = orderBand
        if (order == null) { actionBand = null; cancelBand = null; return }
        val cands = AnchorScan.clustersBelow(f, AnchorScan.ACTION_COLOR, order, maxGapPx = actionGapPx(f, order))
        cancelBand = cands.firstOrNull { (it.cy - order.cy) < order.w * 0.7f && verifyLabel(f, it, arrayOf("ОТМЕН"), labelOcr) }
        actionBand = cands.firstOrNull { (it.cy - order.cy) >= order.w * 0.8f }
    }

    fun cancelTap(f: Frame): Pt? = cancelBand?.let { Pt(it.cx, it.cy) }

    /** Поиск кнопки «Заказать» ВНУТРИ открытого модального окна — окно центрировано, поэтому ищем по всему кадру. */
    private fun rescanDialog(f: Frame, labelOcr: LabelOcr? = null): AnchorScan.Band? {
        var found = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5, region = null)
        // пока окно ещё не открылось, на кадре видна «Заказать» самой страницы — это не кнопка окна
        val page = orderBand
        if (found != null && page != null &&
            kotlin.math.abs(found.cx - page.cx) < page.w / 2 && kotlin.math.abs(found.cy - page.cy) < page.h
        ) found = null
        if (found != null && !verifyLabel(f, found, ORDER_LABELS, labelOcr)) found = null
        if (found != null) dialogOrderBand = found
        return found ?: dialogOrderBand
    }

    /** Страница предмета: кнопка «Заказать» видна (ярко-оранжевая) в правой половине экрана. labelOcr необязателен — передай, когда он есть, для более надёжной проверки. */
    fun isPage(f: Frame, labelOcr: LabelOcr? = null): Boolean {
        val b = orderBand
        // пока синяя кнопка не найдена, кэш «Заказать» не считается достаточным — ищем заново,
        // иначе единожды не найденная синяя кнопка не искалась бы больше никогда
        if (b != null && AnchorScan.probe(f, b, AnchorScan.ORDER_COLOR)) return true
        rescanPage(f, labelOcr)
        return orderBand != null
    }

    /** Открыта клавиатура ввода цены: либо белая панель игры, либо видна наша собственная клавиатура Scriptonit (на части устройств белой панели нет вообще). */
    fun isKeyboard(f: Frame): Boolean =
        inputBarY(f) != null || ScriptoKeyboardService.instance?.isInputViewShown == true

    /** Не страница и не поле ввода — считаем, что открыто модальное окно поверх страницы. */
    fun isDialog(f: Frame): Boolean = !isPage(f) && !isKeyboard(f)

    fun orderTap(f: Frame): Pt? = orderBand?.let { Pt(it.cx, it.cy) }
    fun actionTap(f: Frame): Pt? = actionBand?.let { Pt(it.cx, it.cy) }

    fun requestPriceRegion(f: Frame): Rect? = orderBand?.let { AnchorScan.priceRegionLeftOf(it) }
    fun lotPriceRegion(f: Frame): Rect? = actionBand?.let { AnchorScan.priceRegionLeftOf(it) }

    // Положение галочки: сначала ищем её по картинке (AnchorScan.findCheckbox) около расчётной точки, найденное
    // смещение запоминаем (в ширинах кнопки «Заказать») — дальше берём из кэша, без поиска.
    private var cbDxW: Float? = null
    private var cbDyW: Float? = null
    private var cbTries = 0
    var checkboxInfo: String = "не искалась"; private set

    /** Левая панель предмета («Осмотреть», картинка оружия): нажимать туда нельзя. */
    private const val LEFT_PANEL = 0.27f

    /**
     * Галочка «Только мои запросы». Возвращает точку ТОЛЬКО если галочка найдена по картинке (и лежит правее левой панели).
     * Раньше при неудаче бот жал «расчётную» точку вслепую — на планшетах с другими пропорциями она попадала
     * на оружие/«Осмотреть» и открывала осмотр. Теперь при неудаче возвращается null, и бот просто не трогает галочку.
     */
    fun myRequestsTap(f: Frame): Pt? {
        val ob = orderBand ?: return null
        val minX = (f.w * (LEFT_PANEL + 0.02f)).toInt()
        val dx = cbDxW
        val dy = cbDyW
        if (dx != null && dy != null) {
            val p = AnchorScan.offsetFrom(ob, dx, dy)
            return if (p.x >= minX && p.x < f.w && p.y in 0 until f.h) Pt(p.x, p.y) else null
        }
        if (cbTries >= 4) return null
        cbTries++
        val pred = AnchorScan.offsetFrom(ob, CHECKBOX_DXW, CHECKBOX_DYW)
        val found = AnchorScan.findCheckbox(
            f, pred.y, ob.w,
            xFrom = minX,
            xTo = (ob.x0 - ob.w / 2).coerceAtLeast(minX + 20)
        )
        if (found != null && found.x >= minX) {
            cbDxW = (found.x - ob.cx).toFloat() / ob.w
            cbDyW = (found.y - ob.cy).toFloat() / ob.w
            checkboxInfo = "найдена по картинке в (${found.x},${found.y}); расчётная точка была (${pred.x},${pred.y})"
            DebugLog.add("Галочка «Только мои запросы»: $checkboxInfo")
            return Pt(found.x, found.y)
        }
        checkboxInfo = "по картинке не найдена (попытка $cbTries) — вслепую не жму"
        DebugLog.add("Галочка «Только мои запросы»: $checkboxInfo")
        return null
    }

    /**
     * Раскладка окна «Запрос на покупку», снятая ОДИН раз при калибровке (когда окно открылось до конца) и
     * дальше используемая как жёсткие координаты: поле цены, крестик, кнопка подтверждения.
     * Поле цены и крестик уточняются по картинке (центр белых цифр / белого крестика) около расчётных мест.
     */
    data class DialogLayout(val band: AnchorScan.Band, val priceTap: Pt, val closeTap: Pt, val confirmTap: Pt, val info: String)

    var dialogLayout: DialogLayout? = null; private set

    /** Оранжевая кнопка окна (не кнопка самой страницы), без проверки надписи. */
    fun scanDialogBand(f: Frame): AnchorScan.Band? {
        val found = AnchorScan.scan(f, AnchorScan.ORDER_COLOR, step = 5, region = null) ?: return null
        val page = pageOrderMemo
        if (page != null && kotlin.math.abs(found.cx - page.cx) < page.w / 2 && kotlin.math.abs(found.cy - page.cy) < page.h) return null
        // кнопка окна всегда по центру экрана, а её ширина ≈ 1.3 ширины кнопки «Заказать» страницы
        // (интерфейс масштабируется целиком) — всё остальное оранжевое не наше
        if (kotlin.math.abs(found.cx - f.w / 2) > f.w * 0.12f) return null
        if (page != null) {
            val ratio = found.w.toFloat() / page.w
            if (ratio < 0.9f || ratio > 2.2f) return null
        }
        return found
    }

    /** Строит и запоминает раскладку по кадру f, на котором кнопка окна найдена как band (самая полная из виденных). */
    fun setDialogLayout(f: Frame, band: AnchorScan.Band) {
        val predPrice = dialogOffset(band, PRICE_FIELD_DXW, PRICE_FIELD_DYW)
        val predClose = dialogOffset(band, CLOSE_DXW, CLOSE_DYW)
        val w = band.w
        fun refine(pred: Pt, halfW: Int, halfH: Int, maxShift: Int): Pair<Pt, Boolean> {
            val c = AnchorScan.whiteCentroid(f, pred.x, pred.y, halfW, halfH)
            if (c == null) return Pair(pred, false)
            val dx = c.x - pred.x
            val dy = c.y - pred.y
            return if (dx * dx + dy * dy <= maxShift * maxShift) Pair(c, true) else Pair(pred, false)
        }
        val price = refine(predPrice, (w * 0.34f).toInt(), (w * 0.11f).toInt(), (w * 0.25f).toInt())
        val close = refine(predClose, (w * 0.11f).toInt(), (w * 0.11f).toInt(), (w * 0.2f).toInt())
        val h = maxOf(band.h, (band.w * 0.23f).toInt())
        val confirm = Pt(band.cx, band.y0 + h / 2)
        dialogOrderBand = band
        dialogLayout = DialogLayout(
            band, price.first, close.first, confirm,
            "кнопка ${fmtBand(band)}; поле цены ${price.first.x},${price.first.y} (${if (price.second) "по цифрам" else "расчётное"}); " +
                "крестик ${close.first.x},${close.first.y} (${if (close.second) "по картинке" else "расчётный"}); подтверждение ${confirm.x},${confirm.y}"
        )
    }

    fun dialogMarks(): List<Pair<String, Pt>> {
        val l = dialogLayout ?: return emptyList()
        return listOf("price" to l.priceTap, "close" to l.closeTap, "confirm" to l.confirmTap)
    }

    /** Страница с кнопкой «Заказать» видна (одна проверка цвета в запомненной точке — почти бесплатно). */
    fun pageVisibleFast(f: Frame): Boolean =
        pageOrderMemo?.let { AnchorScan.probe(f, it, AnchorScan.ORDER_COLOR) } == true

    /** Левый и правый края кнопки окна (у верхнего края кнопки, куда не достаёт клавиатура) оранжевые — кнопка стоит в полный размер. */
    private fun edgesOrange(f: Frame, l: DialogLayout): Boolean {
        val b = l.band
        val y = (b.y0 + 6).coerceIn(0, f.h - 1)
        return AnchorScan.colorNear(f, b.x0 + 5, y, AnchorScan.ORDER_COLOR, 90) &&
            AnchorScan.colorNear(f, b.x1 - 5, y, AnchorScan.ORDER_COLOR, 90)
    }

    /**
     * Окно открылось до конца: «Заказать» страницы уже не яркая, а кнопка окна стоит в полный размер
     * (идёт анимация появления — нет) или уже поднялась клавиатура. Четыре проверки цвета вместо поиска по кадру.
     */
    fun dialogReady(f: Frame): Boolean {
        val l = dialogLayout ?: return false
        if (pageVisibleFast(f)) return false
        return edgesOrange(f, l) || isKeyboard(f)
    }

    /**
     * Окно запроса ТОЧНО открыто сейчас (не закрывается и не закрыто): кнопка окна в полный размер на сохранённом
     * месте либо крестик виден ровно там, где был при калибровке. Нужна перед нажатием на крестик: если окно уже
     * закрылось, нажатие по этому месту попадает в строку лота страницы и открывает осмотр предмета.
     */
    fun dialogOpenStrict(f: Frame): Boolean {
        val l = dialogLayout ?: return false
        if (pageVisibleFast(f)) return false // «Заказать» страницы снова яркая — окно закрыто, жать крестик нельзя
        if (edgesOrange(f, l)) return true
        val w = l.band.w
        val c = AnchorScan.whiteCentroid(f, l.closeTap.x, l.closeTap.y, (w * 0.11f).toInt(), (w * 0.11f).toInt()) ?: return false
        val dx = (c.x - l.closeTap.x).toFloat()
        val dy = (c.y - l.closeTap.y).toFloat()
        return dx * dx + dy * dy <= (w * 0.05f) * (w * 0.05f)
    }

    /** Стрелка «назад» слева сверху на экране осмотра предмета (положение в единицах 1920 px ширины интерфейса). */
    fun inspectBackArrow(f: Frame): Pt {
        val k = f.w / 1920f
        val pred = Pt((74 * k).toInt(), (71 * k).toInt())
        val r = maxOf((f.w * 0.03f).toInt(), (f.h * 0.08f).toInt())
        return AnchorScan.whiteCentroid(f, pred.x, pred.y, r, r) ?: pred
    }

    /** Кнопка «Заказать» внутри окна — её же центр одновременно и точка подтверждения. */
    fun dialogConfirmTap(f: Frame, labelOcr: LabelOcr? = null): Pt? =
        dialogLayout?.confirmTap ?: rescanDialog(f, labelOcr)?.let { Pt(it.cx, it.cy) }

    /**
     * Смещение от кнопки окна. Когда поднята клавиатура, она закрывает низ кнопки, и по цвету видна только
     * верхняя часть (на 1280×720 — всего 10 px). Поэтому центр по вертикали считаем от верхнего края
     * и ожидаемой высоты кнопки (≈0.23 её ширины), а не от обрезанного пятна.
     */
    private fun dialogOffset(b: AnchorScan.Band, dxW: Float, dyW: Float): Pt {
        val h = maxOf(b.h, (b.w * 0.23f).toInt())
        val cy = b.y0 + h / 2
        return Pt(b.cx + (dxW * b.w).toInt(), cy + (dyW * b.w).toInt())
    }

    /** Поле ввода цены — смещение от найденной кнопки окна. */
    fun dialogPriceFieldTap(f: Frame, labelOcr: LabelOcr? = null): Pt? {
        dialogLayout?.let { return it.priceTap }
        val b = dialogOrderBand ?: rescanDialog(f, labelOcr) ?: return null
        return dialogOffset(b, PRICE_FIELD_DXW, PRICE_FIELD_DYW)
    }

    /** Крестик закрытия окна — смещение от кнопки «Заказать» в окне. Касание пустого места окно в этой игре не закрывает. */
    fun dialogCloseTap(f: Frame, labelOcr: LabelOcr? = null): Pt? {
        dialogLayout?.let { return it.closeTap }
        val b = dialogOrderBand ?: rescanDialog(f, labelOcr) ?: return null
        return dialogOffset(b, CLOSE_DXW, CLOSE_DYW)
    }

    fun resetDialogCache() {
        dialogOrderBand = null
    }

    /** Полный сброс всех найденных координат. Обязательно перед каждым новым запуском —
     * Profile хранится как один общий объект, и без сброса калибровка могла бы принять
     * координаты с прошлого запуска (или с другого предмета) за «уже проверено». */
    fun reset() {
        orderBand = null
        actionBand = null
        cancelBand = null
        dialogOrderBand = null
        pageOrderMemo = null
        cbDxW = null
        cbDyW = null
        cbTries = 0
        checkboxInfo = "не искалась"
        dialogLayout = null
    }

    private fun fmtBand(b: AnchorScan.Band?) =
        if (b == null) "нет" else "(${b.x0},${b.y0})–(${b.x1},${b.y1}) ${b.w}x${b.h}"

    private fun labelInfo(f: Frame, b: AnchorScan.Band, expected: Array<String>, labelOcr: LabelOcr?): String {
        if (labelOcr == null || !labelOcr.ready) return "надпись не читалась (LabelOcr выключен)"
        val t = labelOcr.readLabel(f, b)
        val ok = t.isEmpty() || expected.any { t.contains(it) }
        return "надпись='$t' → " + (if (ok) "принята" else "ОТКЛОНЕНА (ожидалось что-то из: ${expected.joinToString("/")})")
    }

    /** Полный отчёт для журнала: что бот видит на странице и почему не находит кнопки. */
    fun diagnose(f: Frame, labelOcr: LabelOcr?): String {
        val sb = StringBuilder()
        sb.append("Кадр ${f.w}x${f.h}, bitmap ${f.bmp.width}x${f.bmp.height}\n")
        sb.append(AnchorScan.frameStats(f)).append('\n')
        sb.append("Profile сейчас: «Заказать»=${fmtBand(orderBand)}; синяя кнопка=${fmtBand(actionBand)}\n")
        sb.append("LabelOcr: ").append(
            when {
                labelOcr == null -> "не подключён (нет rus.traineddata)"
                labelOcr.ready -> "готов"
                else -> "не запустился"
            }
        ).append('\n')
        val right = Rect((f.w * PAGE_LEFT).toInt(), 0, f.w, f.h)
        sb.append(AnchorScan.diagnose(f, "«Заказать» на странице, правый столбец", AnchorScan.ORDER_COLOR, 5, right))
        val orders = AnchorScan.candidates(f, AnchorScan.ORDER_COLOR, 5, right).sortedByDescending { it.w.toLong() * it.h }
        for ((i, b) in orders.take(3).withIndex()) {
            sb.append("  кандидат «Заказать» #${i + 1} ${fmtBand(b)}: ${labelInfo(f, b, ORDER_LABELS, labelOcr)}\n")
        }
        val ref = orders.firstOrNull()
        if (ref == null) {
            sb.append("  ⇒ «Заказать» по цвету НЕ найдена\n")
            sb.append(AnchorScan.diagnose(f, "синяя кнопка (кнопки «Заказать» нет — ищу по всей правой половине)", AnchorScan.ACTION_COLOR, 5, right))
        } else {
            sb.append("  ⇒ бот берёт самую крупную: ${fmtBand(ref)} (если надпись отклонена — считает, что кнопки нет)\n")
            val gap = actionGapPx(f, ref)
            sb.append(AnchorScan.diagnose(f, "синяя «Купить»/«Отмена» под «Заказать»", AnchorScan.ACTION_COLOR, 5, AnchorScan.regionBelow(f, ref, gap)))
            val below = AnchorScan.clustersBelow(f, AnchorScan.ACTION_COLOR, ref, gap)
            for ((i, b) in below.take(4).withIndex()) {
                sb.append("  кандидат синей #${i + 1} ${fmtBand(b)}: ${labelInfo(f, b, arrayOf("ОТМЕН", "КУП"), labelOcr)}\n")
            }
        }
        return sb.toString()
    }

    /** Отчёт по окну «Запрос на покупку». */
    fun diagnoseDialog(f: Frame, labelOcr: LabelOcr?): String {
        val sb = StringBuilder()
        sb.append("Кадр ${f.w}x${f.h}\n").append(AnchorScan.frameStats(f)).append('\n')
        sb.append(AnchorScan.diagnose(f, "«Заказать» в окне запроса (весь кадр)", AnchorScan.ORDER_COLOR, 5, null))
        val c = AnchorScan.candidates(f, AnchorScan.ORDER_COLOR, 5, null).sortedByDescending { it.w.toLong() * it.h }
        for ((i, b) in c.take(3).withIndex()) {
            sb.append("  кандидат #${i + 1} ${fmtBand(b)}: ${labelInfo(f, b, ORDER_LABELS, labelOcr)}\n")
        }
        return sb.toString()
    }

    fun requestHash(f: Frame): Int? = requestPriceRegion(f)?.let { regionHash(f, it) }

    fun regionHash(f: Frame, r: Rect): Int {
        var hash = 17
        var y = r.top
        while (y < r.bottom) {
            var x = r.left
            while (x < r.right) {
                val c = f.bmp.getPixel(x.coerceIn(0, f.w - 1), y.coerceIn(0, f.h - 1))
                val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                hash = hash * 31 + (lum shr 5)
                x += 2
            }
            y += 2
        }
        return hash
    }

    /** Центр белой панели ввода по вертикали в пикселях экрана, и её левый/правый край — или null, если панели нет. */
    fun inputBar(f: Frame): Triple<Int, Int, Int>? {
        val x = (f.w * 0.25f).toInt().coerceIn(0, f.w - 1)
        var first = -1
        var last = -1
        var y = 0
        while (y < f.h) {
            val c = f.bmp.getPixel(x, y)
            val white = Color.red(c) > 240 && Color.green(c) > 240 && Color.blue(c) > 240
            if (white) {
                if (first < 0) first = y
                last = y
            } else if (first >= 0 && y - last > 12) {
                break
            }
            y += 3
        }
        if (first < 0 || last - first <= f.h * 0.03f) return null
        val rowY = (first + last) / 2
        var left = -1
        var right = -1
        var xx = 0
        while (xx < f.w) {
            val c = f.bmp.getPixel(xx, rowY)
            val white = Color.red(c) > 235 && Color.green(c) > 235 && Color.blue(c) > 235
            if (white) {
                if (left < 0) left = xx
                right = xx
            }
            xx += 4
        }
        return Triple(rowY, if (left >= 0) left else 0, if (right >= 0) right else f.w - 1)
    }

    fun inputBarY(f: Frame): Int? = inputBar(f)?.first
}
