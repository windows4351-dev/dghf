package com.scriptonit.shop

import android.content.Context

object Stats {
    private const val P = "scriptonit"

    fun bids(c: Context): Int = c.getSharedPreferences(P, Context.MODE_PRIVATE).getInt("total_bids", 0)

    fun addBid(c: Context) {
        val sp = c.getSharedPreferences(P, Context.MODE_PRIVATE)
        sp.edit().putInt("total_bids", sp.getInt("total_bids", 0) + 1).apply()
    }

    fun snakeBest(c: Context): Int = c.getSharedPreferences(P, Context.MODE_PRIVATE).getInt("snake_best", 0)

    fun setSnakeBest(c: Context, v: Int) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putInt("snake_best", v).apply()
    }
}
