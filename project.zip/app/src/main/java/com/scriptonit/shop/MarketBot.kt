package com.scriptonit.shop

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Rect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.util.Locale
import kotlin.math.abs

data class BotConfig(
    val min: Double,
    val max: Double,
    val step: Double,
    val gap: Double,
    val cancelDelayMs: Long,
    val refreshMs: Long,
    val maxMinutes: Int,
    val maxBids: Int,
    val aggressive: Boolean,
    val matchEqual: Boolean
)

object BotPrefs {
    private const val P = "bot"

    fun raw(c: Context, key: String, def: String): String =
        c.getSharedPreferences(P, Context.MODE_PRIVATE).getString(key, null) ?: def

    fun save(c: Context, values: Map<String, String>) {
        val e = c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }

    fun load(c: Context): BotConfig {
        fun d(k: String, def: String) = raw(c, k, def).replace(',', '.').toDoubleOrNull() ?: def.toDouble()
        return BotConfig(
            min = d("min", "10"),
            max = d("max", "99999"),
            step = 0.01, // фиксированные: режимы «Агрессивный» и «Сбалансированный» сами решают, сколько ставить
            gap = 0.01,
            cancelDelayMs = (d("cancel", "2") * 1000).toLong().coerceAtLeast(0),
            refreshMs = (d("refresh", "5") * 1000).toLong().coerceAtLeast(2000),
            maxMinutes = d("minutes", "119").toInt().coerceAtLeast(1),
            maxBids = d("bids", "300").toInt().coerceAtLeast(1),
            aggressive = raw(c, "aggr", "0") == "1",
            matchEqual = true
        )
    }
}

/**
 * Встроенная логика перебива запросов. Координаты кнопок и областей цен определяются
 * динамически по цвету (Profile/AnchorScan), а не по фиксированным пикселям, поэтому
 * работает на разных экранах и раскладках без ручной калибровки под каждое устройство.
 *
 * Цикл: на странице предмета ищем кнопку «Заказать» и первую синюю кнопку под ней —
 * это «Отмена» (если наш запрос уже стоит) или «Купить» первого лота (если нет).
 * Читаем цену лота и верхнего запроса, запоминаем их, открываем поле ввода и остаёмся
 * там. Пока запрос не растёт, ничего не делаем. Как только он вырос — мгновенно ставим
 * цену (см. chooseBid), подтверждаем и через cancelDelayMs отменяем свой запрос.
 * Раз в refreshMs выходим на страницу и заново запоминаем лот и запрос.
 */
class MarketBot(
    private val svc: ClickService,
    private val grab: ScreenGrabber,
    private val ocr: Ocr,
    private val cfg: BotConfig,
    private val onBid: () -> Unit,
    private val log: (String) -> Unit,
    private val labelOcr: LabelOcr? = null
) {
    private enum class Screen { PAGE, DIALOG, KEYBOARD, UNKNOWN }

    private var fw = 1
    private var fh = 1

    private var lot: Double? = null
    private var req: Double? = null
    private var baseReq: Double? = null
    private var refreshedAt = 0L
    private var needRefresh = true
    private var firstRefresh = true
    private var inHold = false
    private var lastHash = 0
    private var lastOcrAt = 0L
    private var lowCount = 0
    private var bids = 0
    private var noActionCount = 0
    private var unexpectedScreens = 0

    // Базовая цена в окне запроса (сравнение «окно с окном», а не «окно со страницей»: сквозь затемнение
    // цифры читаются иначе, из-за чего раньше бот видел «рост» запроса при каждом обновлении и ставил сам)
    private var holdBase: Double? = null
    private var holdPending: Double? = null
    private var downVal: Double? = null
    private var downCount = 0
    private var lastOwnBid: Double? = null

    // Галочка «Только мои запросы»: после первого сбоя больше не нажимаем (иначе на нестандартных экранах
    // каждый цикл тапал бы по странице и открывал осмотр оружия)
    private var checkboxOff = false

    private fun isOwn(r: Double): Boolean {
        val o = lastOwnBid ?: return false
        if (abs(o - r) < 0.005) return true
        lastOwnBid = null // в списке уже другая цена — наш запрос исчез
        return false
    }

    private val CALIB_PRICE = 0.03
    private var lastCrossTapAt = 0L

        private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun round2(v: Double) = Math.round(v * 100.0) / 100.0

    private fun track(f: Frame) {
        fw = f.w
        fh = f.h
        // после нажатия по крестику все нажатия заблокированы, пока на кадре не появится яркая страница
        if (crossLockAt != 0L && Profile.pageVisibleFast(f)) crossLockAt = 0L
    }

    /** Момент нажатия по крестику; пока ненулевой (и не прошло 8 с) — НИКАКИХ нажатий по экрану, чтобы не попасть в лот. */
    @Volatile private var crossLockAt = 0L

    private fun crossLocked(): Boolean {
        val t = crossLockAt
        return t != 0L && System.currentTimeMillis() - t < 8000
    }

    /** Быстрый тап без пауз после: короткое касание, подтверждение результата — по картинке. */
    private suspend fun quickTap(p: Pt) {
        if (!tapAllowed(p)) return
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), 30)
    }

    /** Лёгкая «подпись» кадра: яркость в узлах сетки. Нужна, чтобы по двум кадрам понять, ЧТО изменилось на экране. */
    private fun sig(f: Frame, step: Int): IntArray {
        val gw = f.w / step
        val gh = f.h / step
        val a = IntArray(gw * gh)
        for (j in 0 until gh) for (i in 0 until gw) {
            val c = f.bmp.getPixel((i * step + step / 2).coerceIn(0, f.bmp.width - 1), (j * step + step / 2).coerceIn(0, f.bmp.height - 1))
            a[j * gw + i] = (android.graphics.Color.red(c) * 3 + android.graphics.Color.green(c) * 6 + android.graphics.Color.blue(c)) / 10
        }
        return a
    }

    /** Доля узлов сетки ВНЕ круга радиуса rad вокруг точки нажатия, у которых яркость заметно изменилась. */
    private fun foreignChange(a: IntArray, b: IntArray, f: Frame, step: Int, cx: Int, cy: Int, rad: Int): Float {
        if (a.size != b.size) return 1f
        val gw = f.w / step
        var n = 0
        var ch = 0
        for (k in a.indices) {
            val x = (k % gw) * step + step / 2
            val y = (k / gw) * step + step / 2
            val dx = x - cx
            val dy = y - cy
            if (dx * dx + dy * dy <= rad * rad) continue
            n++
            if (abs(a[k] - b[k]) > 45) ch++
        }
        return if (n == 0) 0f else ch.toFloat() / n
    }

    /**
     * Одно нажатие по галочке с проверкой по картинке: (1) в области галочки что-то изменилось, (2) НИГДЕ ЕЩЁ на экране
     * ничего существенно не изменилось. Если нажатие попало не в галочку (строка лота → осмотр предмета, окно и т. п.), весь
     * экран меняется — возвращаем false, и вызывающий больше не жмёт эту точку. Повторных нажатий «на всякий случай» нет:
     * из-за них число переключений становилось нечётным, и список оставался в режиме «Только мои запросы».
     */
    private suspend fun verifiedTap(cb: Pt, rect: Rect, rad: Int, step: Int): Boolean {
        val before = grab.frame() ?: return false
        track(before)
        val sigB = sig(before, step)
        val hB = Profile.regionHash(before, rect)
        quickTap(cb)
        val end = System.currentTimeMillis() + 450
        while (System.currentTimeMillis() < end) {
            delay(30)
            val f = grab.frame() ?: continue
            val fc = foreignChange(sigB, sig(f, step), f, step, cb.x, cb.y, rad)
            if (fc > 0.10f) {
                DebugLog.add("Галочка: после нажатия в (${cb.x},${cb.y}) изменилось ${(fc * 100).toInt()}% экрана — это не галочка (осмотр/окно)")
                DebugLog.saveFrame(f)
                return false
            }
            if (Profile.regionHash(f, rect) != hB) return true
        }
        DebugLog.add("Галочка: нажатие в (${cb.x},${cb.y}) ничего не изменило за 450 мс")
        return false
    }

    /**
     * Дважды переключает галочку «Только мои запросы» (список перечитывается) и проверяет, что в конце она в ТОМ ЖЕ
     * состоянии, что и в начале. Если нет — одно исправляющее нажатие; если и оно не помогло — false (галочка отключается).
     */
    private suspend fun toggleMyRequestsTwice(cb: Pt, r: Int): Boolean {
        val f0 = grab.frame() ?: return false
        track(f0)
        val step = maxOf(6, f0.w / 160)
        val rect = Rect(cb.x - r, cb.y - r, cb.x + r, cb.y + r)
        val rad = r * 3
        val t0 = System.currentTimeMillis()
        for (toggle in 1..2) {
            if (!verifiedTap(cb, rect, rad, step)) return false
            delay(70)
        }
        DebugLog.add("Галочка: два переключения за ${System.currentTimeMillis() - t0} мс")
        return true
    }

    /**
     * Список без кнопки лота: возможно, он завис в режиме «Только мои запросы». Одно проверенное нажатие по галочке;
     * если кнопка лота после этого не появилась — нажимаем обратно (список мог быть пуст на самом деле).
     */
    private suspend fun healMyRequests(f: Frame) {
        if (checkboxOff) return
        val cb = Profile.myRequestsTap(f) ?: return
        val r = ((Profile.orderBand?.w ?: 200) * 0.12f).toInt().coerceAtLeast(12)
        val rect = Rect(cb.x - r, cb.y - r, cb.x + r, cb.y + r)
        val step = maxOf(6, f.w / 160)
        DebugLog.add("Список без кнопки лота — пробую переключить галочку «Только мои запросы»")
        if (!verifiedTap(cb, rect, r * 3, step)) { checkboxOff = true; return }
        delay(500)
        val f2 = grab.frame() ?: return
        val lr = Profile.lotPriceRegion(f2)
        val lotOk = if (lr != null) ocr.readPrice(f2, lr) != null else { Profile.scanBlue(f2, labelOcr); Profile.actionBand != null }
        if (!lotOk) {
            DebugLog.add("Цена лота не появилась — возвращаю галочку обратно")
            if (!verifiedTap(cb, rect, r * 3, step)) checkboxOff = true
            delay(300)
        }
    }

    private fun settleHash(f: Frame): Int {
        var h = 17
        val x0 = (f.w * 0.62f).toInt()
        val y1 = (f.h * 0.32f).toInt()
        var y = 0
        while (y < y1) {
            var x = x0
            while (x < f.w) {
                val c = f.bmp.getPixel(x, y)
                h = h * 31 + (((android.graphics.Color.red(c) + android.graphics.Color.green(c) + android.graphics.Color.blue(c)) / 3) shr 3)
                x += 12
            }
            y += 12
        }
        return h
    }

    /** Ждёт, пока правая верхняя часть экрана перестанет меняться (закончится анимация окна). */
    private suspend fun waitSettled(maxMs: Long = 150) {
        val end = System.currentTimeMillis() + maxMs
        var last = 0
        var haveLast = false
        var same = 0
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                val h = settleHash(f)
                if (haveLast && h == last) {
                    same++
                    if (same >= 2) return
                } else {
                    same = 0
                }
                last = h
                haveLast = true
            }
            delay(8)
        }
    }

    private fun screenOf(f: Frame) = when {
        Profile.isKeyboard(f) -> Screen.KEYBOARD
        Profile.isPage(f, labelOcr) -> Screen.PAGE
        else -> Screen.DIALOG
    }

    /**
     * Защита от случайных нажатий: ни одна наша кнопка не лежит в левой панели предмета («Осмотреть», «Продать»,
     * график) — это ≈27% ширины слева, при любых пропорциях экрана. Любое нажатие туда — ошибка расчёта.
     */
    private fun tapAllowed(p: Pt, allowLeft: Boolean = false): Boolean {
        if (crossLocked()) {
            DebugLog.add("Тап (${p.x},${p.y}) заблокирован: после крестика ждём страницу, повторных нажатий нет")
            return false
        }
        if (p.x < 0 || p.y < 0 || (fw > 0 && p.x >= fw) || (fh > 0 && p.y >= fh)) {
            DebugLog.add("Тап мимо экрана (${p.x},${p.y}) — пропущен")
            return false
        }
        if (!allowLeft && fw > 0 && p.x < fw * 0.27f) {
            DebugLog.add("Тап в левую панель (${p.x},${p.y}) отклонён — это не наша кнопка")
            return false
        }
        return true
    }

    private suspend fun tap(p: Pt, allowLeft: Boolean = false) {
        if (!tapAllowed(p, allowLeft)) return
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), 30)
        delay(15)
    }

    private suspend fun waitFor(timeoutMs: Long, cond: (Frame) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (cond(f)) return true
            }
            delay(8)
        }
        return false
    }

    private suspend fun typeText(text: String): Boolean =
        withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.replaceText(text) == true }

    private suspend fun imeDone() {
        val ok = withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.done() == true }
        if (!ok) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    /** Закрывает поле ввода через действие IME; если поле его игнорирует, жмёт кнопку в правом краю найденной белой панели. */
    private suspend fun closeKeyboard(): Boolean {
        imeDone()
        if (waitFor(600) { !Profile.isKeyboard(it) }) return true
        val f = grab.frame() ?: return false
        track(f)
        val bar = Profile.inputBar(f)
        if (bar == null) {
            // белой панели нет (наша клавиатура) — одно «Назад» закрывает именно клавиатуру
            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            return waitFor(700) { !Profile.isKeyboard(it) }
        }
        val (rowY, _, right) = bar
        tap(Pt((right - (right - bar.second) * 0.06f).toInt(), rowY))
        return waitFor(700) { !Profile.isKeyboard(it) }
    }

    /** Открывает окно, находит в нём кнопку «Заказать» по цвету и тапает поле цены как смещение от неё. */
    private suspend fun enterHold(price: Double): Boolean {
        val lay = Profile.dialogLayout
        if (lay == null) {
            DebugLog.add("Ввод цены: раскладка окна запроса не снята при калибровке")
            return false
        }
        val tEnter = System.currentTimeMillis()
        val order = Profile.orderTap(grab.frame() ?: return false) ?: return false
        quickTap(order)
        // ждём, пока окно откроется до конца (идёт анимация появления): дальше — жёсткие координаты из калибровки
        if (!waitFor(1500) { Profile.dialogReady(it) }) {
            DebugLog.add("Ввод цены: окно запроса не открылось за 1.5 с после нажатия «Заказать»")
            grab.frame()?.let { DebugLog.saveFrame(it, "enter", Profile.dialogMarks()) }
            return false
        }
        val tOpen = System.currentTimeMillis()
        val priceTap = lay.priceTap
        if (grab.frame()?.let { Profile.pageVisibleFast(it) } == true) {
            DebugLog.add("Ввод цены: страница ещё не затемнена — тап по полю цены отменён (попал бы в список)")
            return false
        }
        quickTap(priceTap)
        if (!waitFor(1500) { Profile.isKeyboard(it) }) {
            DebugLog.add("Ввод цены: поле не открылось за 1.5 с после тапа $priceTap (клавиатура Scriptonit показана=${ScriptoKeyboardService.instance?.isInputViewShown}, службы=${ScriptoKeyboardService.instance != null})")
            grab.frame()?.let { DebugLog.saveFrame(it, "enter", Profile.dialogMarks()) }
            return false
        }
        val tKb = System.currentTimeMillis()
        delay(30)
        if (!typeText(fmt(price))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return false
        }
        DebugLog.add("Вход в окно запроса: открытие ${tOpen - tEnter} мс, поле ${tKb - tOpen} мс, ввод ${System.currentTimeMillis() - tKb} мс")
        inHold = true
        lastHash = 0
        lastOcrAt = 0
        holdBase = null
        holdPending = null
        downVal = null
        downCount = 0
        return true
    }

    /**
     * Закрывает окно запроса крестиком — РОВНО ОДНО нажатие. Нажатие по крестику закрывает и окно, и клавиатуру разом
     * (клавиатуру перед этим не трогаем). Повторного нажатия нет никогда: на месте крестика на странице лежит второй лот,
     * и второе нажатие по уже закрытому окну открывало осмотр предмета. После нажатия только ждём страницу (до 3 с);
     * новое нажатие по крестику возможно не раньше чем через 4 с после предыдущего.
     */
    private suspend fun crossClose(maxMs: Long = 3500): Boolean {
        val t0 = System.currentTimeMillis()
        var tapped = false
        while (System.currentTimeMillis() - t0 < maxMs) {
            yield()
            val f = grab.frame()
            if (f == null) { delay(20); continue }
            track(f)
            if (Profile.pageVisibleFast(f) || Profile.isPage(f, labelOcr)) {
                crossLockAt = 0L
                DebugLog.add("Закрытие окна запроса: ${System.currentTimeMillis() - t0} мс (${if (tapped) 1 else 0} нажатий)")
                return true
            }
            if (tapped) { delay(40); continue }
            if (System.currentTimeMillis() - lastCrossTapAt < 4000) { delay(60); continue }
            if (crossLocked()) { delay(60); continue }
            val close = Profile.liveClose(f) ?: if (Profile.dialogOpenStrict(f)) Profile.dialogCloseTap(f) else null
            if (close == null) { delay(60); continue }
            quickTap(close)
            tapped = true
            lastCrossTapAt = System.currentTimeMillis()
            crossLockAt = lastCrossTapAt
        }
        DebugLog.add("Закрытие окна запроса: страница не появилась за ${System.currentTimeMillis() - t0} мс (нажатий ${if (tapped) 1 else 0})")
        return false
    }

    private suspend fun closeDialog() {
        if (grab.frame()?.let { Profile.isKeyboard(it) && !Profile.pageVisibleFast(it) } == true) closeKeyboard()
        crossClose()
    }

    private suspend fun exitHold() {
        crossClose()
        inHold = false
    }

    private var unknownBacks = 0
    private var unknownSaved = false

    private var lastBackAt = 0L

    /**
     * Экран не страница, не окно запроса и не клавиатура: осмотр предмета, список маркета, идущая анимация или загрузка.
     * Сначала даём странице до 1.5 с проявиться, потом «Назад» (не больше 2 раз за 8 с), потом стрелка слева сверху.
     */
    private suspend fun recoverScreen() {
        if (crossLocked()) { delay(100); return } // только что нажали крестик — ждём, пока страница проявится
        val f = grab.frame() ?: return
        if (Profile.dialogOpenStrict(f)) { closeDialog(); return }
        if (waitFor(1500) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) { unknownBacks = 0; return }
        val f2 = grab.frame() ?: return
        if (Profile.dialogOpenStrict(f2)) { closeDialog(); return }
        if (!unknownSaved) {
            unknownSaved = true
            DebugLog.saveFrame(f2, "unknown", listOf("arrow" to Profile.inspectBackArrow(f2)))
        }
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastBackAt > 8000) unknownBacks = 0
        if (unknownBacks >= 2) {
            DebugLog.add("Неизвестный экран держится после «Назад» — жду")
            delay(300)
            return
        }
        unknownBacks++
        lastBackAt = nowMs
        DebugLog.add("Неизвестный экран (осмотр предмета?) — «Назад» №$unknownBacks")
        svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        if (waitFor(1800) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) { unknownBacks = 0; return }
        val f3 = grab.frame() ?: return
        val arrow = Profile.inspectBackArrow(f3)
        DebugLog.add("«Назад» не помог — стрелка слева сверху (${arrow.x},${arrow.y})")
        tap(arrow, allowLeft = true)
        if (waitFor(1500) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) unknownBacks = 0
    }

    /** Одно полное обновление: страница, галочка «Мои запросы», чтение цен через найденные кнопки. */
    private suspend fun refreshPage(): Boolean {
        val refreshT0 = System.currentTimeMillis()
        // галочка «Только мои запросы»: нажать дважды, чтобы заставить список перечитаться —
        // координата находится автоматически, от уже найденной кнопки «Заказать»
        if (!firstRefresh && !checkboxOff) {
            // после быстрого закрытия окна страница ещё проявляется из затемнения — нажатия в это время
            // проглатываются, поэтому ждём, пока верхняя часть кадра перестанет меняться (обычно 30–100 мс)
            waitSettled()
            val f0 = grab.frame()
            if (f0 != null) {
                track(f0)
                val cb = Profile.myRequestsTap(f0)
                if (cb != null) {
                    if (!toggleMyRequestsTwice(cb, ((Profile.orderBand?.w ?: 200) * 0.12f).toInt().coerceAtLeast(12))) {
                        checkboxOff = true
                        log("Галочка «Только мои запросы» не сработала на этом экране — дальше работаю без неё")
                    }
                } else {
                    checkboxOff = true
                    DebugLog.add("Галочка «Только мои запросы» не найдена по картинке — дальше работаю без неё (orderBand=${Profile.orderBand})")
                }
            }
        }
        var prevR: Double? = null
        var prevL: Double? = null
        var prevHR = 0
        var prevHL = 0
        var noPriceCount = 0
        var noLotSince = 0L
        var healTried = false
        val end = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f == null) { delay(8); continue }
            track(f)
            if (!Profile.isPage(f, labelOcr)) { delay(20); continue }
            if (!Profile.calibrated || Profile.lotPriceRegion(f) == null) Profile.scanBlue(f, labelOcr) // после калибровки синюю кнопку НЕ ищем — цена лота читается по запомненной области
            val rr = Profile.requestPriceRegion(f)
            val lr = Profile.lotPriceRegion(f)
            if (rr == null) { delay(20); continue }
            val hR = Profile.regionHash(f, rr)
            val hL = if (lr != null) Profile.regionHash(f, lr) else 0
            val r: Double?
            val l: Double?
            if (prevR != null && hR == prevHR && hL == prevHL) {
                r = prevR
                l = prevL
            } else {
                r = ocr.readPrice(f, rr)
                val noteR = ocr.lastNote
                l = if (lr != null) ocr.readPrice(f, lr) else null
                val noteL = if (lr != null) ocr.lastNote else "область лота не задана"
                if (r == null) {
                    noPriceCount++
                    if (noPriceCount == 45) {
                        log("Кнопки на месте, но цена запроса не читается")
                        DebugLog.add("=== ДИАГНОСТИКА: цена не читается во время работы ===\nобласть запроса $rr → $noteR\nобласть лота $lr → $noteL")
                        DebugLog.saveFrame(f)
                    }
                }
            }
            if (r == null) { delay(20); continue }
            noPriceCount = 0
            val lotMissing = l == null
            if (lotMissing) { if (noLotSince == 0L) noLotSince = System.currentTimeMillis() } else noLotSince = 0L
            val stable = prevR != null && abs(prevR - r) < 0.001 &&
                ((l == null && prevL == null) || (l != null && prevL != null && abs(prevL - l) < 0.001))
            prevR = r
            prevL = l
            prevHR = hR
            prevHL = hL
            if (!stable) { delay(20); continue }
            if (lotMissing) {
                // цена лота не читается: список мог ещё грузиться или зависнуть в режиме «Только мои запросы»
                val waited = System.currentTimeMillis() - noLotSince
                if (waited < 1200) { delay(20); continue }
                if (!healTried) { healTried = true; healMyRequests(f); noLotSince = System.currentTimeMillis() - 600; prevR = null; continue }
            }
            req = r
            lot = l
            refreshedAt = System.currentTimeMillis()
            log(if (l != null) "Лот ${fmt(l)} · запрос ${fmt(r)}" else "Запрос ${fmt(r)} · цена лота не видна")
            DebugLog.add("обновление страницы: ${System.currentTimeMillis() - refreshT0} мс")
            return true
        }
        return false
    }

    /**
     * Цена ставки. Потолок = запомненный лот минус gap, поэтому ставка не может
     * сравняться с лотом или превысить его (защита от фуллпрайса).
     * Обычно: r + шаг. Если на шаг перебить уже нельзя, а r сам ниже потолка —
     * при включённом «Нельзя перебить на шаг» ставим ровно r (тот же запрос).
     * «Агрессивно» сразу ставит на потолок (копейка ниже лота).
     */
    private fun chooseBid(r: Double): Double? {
        val l = lot ?: return null
        if (l < cfg.min || l > cfg.max) return null
        val ceiling = round2(l - cfg.gap)
        val outbid = round2(r + cfg.step)
        val bid = when {
            outbid <= ceiling -> if (cfg.aggressive) ceiling else outbid
            // перебить на шаг нельзя (упрёмся в лот), но под лотом ещё есть место:
            // ставим на копейку ниже первого лота, а не пропускаем
            round2(r) <= ceiling -> ceiling
            else -> return null
        }
        return if (bid > cfg.max) null else bid
    }

    /** Почему chooseBid отказался ставить — чтобы на панели была настоящая причина, а не всегда «вплотную». */
    private fun skipReason(r: Double): String {
        val l = lot ?: return "лот не прочитан"
        return when {
            l < cfg.min -> "лот ${fmt(l)} ниже «Цена от» (${fmt(cfg.min)}) — измени в настройках приложения"
            l > cfg.max -> "лот ${fmt(l)} выше «Цена до» (${fmt(cfg.max)}) — подними «Цена до» в настройках приложения"
            else -> "запрос ${fmt(r)} уже выше потолка ${fmt(round2(l - cfg.gap))} (лот ${fmt(l)} минус gap)"
        }
    }

    private suspend fun bidFromHold(bid: Double) {
        inHold = false
        needRefresh = true
        baseReq = null
        holdBase = null
        lastOwnBid = bid
        if (!typeText(fmt(bid))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return
        }
        if (!closeKeyboard()) return
        if (!waitFor(800) { Profile.isDialog(it) }) return
        // подтверждаем только если окно точно открыто: иначе нажатие по центру экрана попало бы в строку лота
        if (!waitFor(500) { Profile.dialogOpenStrict(it) }) { log("Окно запроса не открыто — подтверждение отменено"); return }
        val confirm = grab.frame()?.let { Profile.dialogConfirmTap(it, labelOcr) }
        if (confirm != null) tap(confirm) else { log("Не нашёл кнопку «Заказать» в окне"); return }
        bids++
        onBid()
        log("#$bids: ${fmt(bid)} G · лот ${fmt(lot ?: 0.0)}")
        if (cfg.cancelDelayMs > 0) {
            delay(cfg.cancelDelayMs)
            cancelOwnRequest(bid)
        }
        waitFor(1500) { Profile.isPage(it, labelOcr) }
    }

    /**
     * Нажимает «Отмена» по координатам, запомненным при калибровке (без поиска кнопки по картинке). Перед нажатием лишь
     * проверяется, что на этом месте уже синяя кнопка (она появляется, когда запрос реально создан); после — что она исчезла.
     * «Купить» лота стоит в другом месте и не нажимается никогда.
     */
    private suspend fun cancelOwnRequest(bid: Double, attempt: Int = 0) {
        if (attempt >= 3) { log("Не удалось отменить запрос ${fmt(bid)} за 3 попытки, проверь вручную"); return }
        var present = false
        val end = System.currentTimeMillis() + 3000
        while (System.currentTimeMillis() < end) {
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (Profile.pageVisibleFast(f) && Profile.cancelPresent(f)) { present = true; break }
            }
            delay(25)
        }
        if (!present) {
            log("«Отмена» на месте не появилась — запрос ${fmt(bid)} не создан или ещё не виден; ничего не нажимаю")
            DebugLog.add("Отмена: на запомненном месте нет синей кнопки за 3 с")
            grab.frame()?.let { DebugLog.saveFrame(it) }
            return
        }
        val cp = grab.frame()?.let { Profile.cancelTap(it) } ?: return
        tap(cp)
        if (waitFor(1500) { Profile.pageVisibleFast(it) && !Profile.cancelPresent(it) }) return
        cancelOwnRequest(bid, attempt + 1)
    }

    private suspend fun pageTick() {
        inHold = false
        val now = System.currentTimeMillis()
        if (needRefresh || now - refreshedAt >= cfg.refreshMs) {
            if (!refreshPage()) { delay(100); return }
            needRefresh = false
            firstRefresh = false
            val r = req ?: return
            val base = baseReq
            baseReq = r
            holdBase = null
            if (base != null && r > base + 0.001 && !isOwn(r)) {
                val bid = chooseBid(r)
                if (bid != null) {
                    if (enterHold(bid)) bidFromHold(bid)
                    return
                }
                log("Пропуск: ${skipReason(r)}")
            }
        }
        val r = baseReq ?: req ?: return
        val bid = chooseBid(r) ?: round2(r + cfg.step)
        if (!enterHold(bid)) delay(150)
    }

    private suspend fun holdTick(f: Frame?) {
        val now = System.currentTimeMillis()
        if (now - refreshedAt >= cfg.refreshMs) {
            exitHold()
            needRefresh = true
            return
        }
        if (f == null) return
        val region = Profile.requestPriceRegion(f) ?: return
        val hash = Profile.regionHash(f, region)
        if (hash == lastHash && now - lastOcrAt < 600) return
        lastHash = hash
        lastOcrAt = now
        val r = ocr.readPrice(f, region) ?: return
        val base = holdBase
        if (base == null) {
            // Первая цена в окне. Если она совпала со страницей — берём сразу; иначе нужны два одинаковых чтения подряд
            // (одно «кривое» распознавание раньше превращалось в ложный «перебив»)
            val pageR = baseReq
            val pend = holdPending
            if (pageR != null && abs(pageR - r) < 0.001) { holdBase = r; holdPending = null }
            else if (pend != null && abs(pend - r) < 0.001) { holdBase = r; holdPending = null }
            else holdPending = r
            return
        }
        if (r > base + 0.001) {
            // рост подтверждаем вторым чтением со свежего кадра — одиночный сбой распознавания не повод ставить
            if (!confirmRead(r)) return
            holdBase = r
            downVal = null; downCount = 0
            if (isOwn(r)) return
            val bid = chooseBid(r)
            if (bid != null) {
                bidFromHold(bid)
            } else {
                log("Пропуск: ${skipReason(r)}")
            }
        } else if (r < base - 0.001) {
            // снижение принимаем, только когда одно и то же новое значение прочитано два раза подряд
            if (downVal != null && abs(downVal!! - r) < 0.001) downCount++ else { downVal = r; downCount = 1 }
            if (downCount >= 2) { holdBase = r; downVal = null; downCount = 0 }
        } else {
            downVal = null; downCount = 0
        }
    }

    /** Перечитывает цену запроса со следующего кадра: true, если значение то же самое (рост настоящий). */
    private suspend fun confirmRead(r: Double): Boolean {
        delay(25)
        val f2 = grab.frame() ?: return false
        track(f2)
        val reg = Profile.requestPriceRegion(f2) ?: return false
        val r2 = ocr.readPrice(f2, reg) ?: return false
        val ok = abs(r2 - r) < 0.001
        if (!ok) DebugLog.add("Рост запроса не подтвердился повторным чтением (${fmt(r)} → ${fmt(r2)}) — ставку не делаю")
        return ok
    }


    /**
     * Перед началом торговли до 10 секунд ищет и проверяет все нужные кнопки:
     * сперва «Заказать» и «Купить»/«Отмена» на странице, затем один раз открывает
     * окно «Запрос на покупку», чтобы найти кнопку внутри него — и сразу закрывает
     * окно обратно, ничего не вводя и не отправляя. Торговля начинается только
     * после успешной проверки.
     */
    private suspend fun calibrate(): Boolean {
        log("Калибровка: ищу кнопки на странице…")
        val pageStart = System.currentTimeMillis()
        var pageOk = false
        var lastFrame: Frame? = null
        var framesSeen = 0
        while (System.currentTimeMillis() - pageStart < 10_000) {
            yield()
            val f = grab.frame()
            if (f != null) {
                framesSeen++
                lastFrame = f
                track(f)
                if (framesSeen == 1) DebugLog.add("Калибровка: первый кадр ${f.w}x${f.h}")
                if (Profile.isPage(f, labelOcr)) { pageOk = true; break }
            }
            delay(60)
        }
        if (!pageOk) {
            log("Не нашёл кнопки «Заказать»/«Купить» — открой страницу предмета в маркете. Подробности: «Журнал отладки» в приложении")
            val ff = lastFrame
            if (ff == null) {
                DebugLog.add("ДИАГНОСТИКА: за 10 секунд не пришло ни одного кадра экрана (запись экрана не работает?)")
            } else {
                DebugLog.add("=== ДИАГНОСТИКА: не найдены кнопки страницы (кадров получено: $framesSeen) ===\n" + Profile.diagnose(ff, labelOcr))
                DebugLog.saveFrame(ff)
            }
            return false
        }
        grab.frame()?.let { Profile.scanBlue(it, labelOcr) }
        if (Profile.cancelBand != null) {
            log("На странице уже есть твой запрос («Отмена» под «Заказать») — отмени его вручную и запусти заново: калибровка ставит пробный запрос и сама его отменяет")
            return false
        }
        DebugLog.add("Кнопки страницы: «Заказать»=${Profile.orderBand} синяя=${Profile.actionBand}")
        log("Кнопки страницы найдены ✓ проверяю, читается ли цена…")
        // сразу находим галочку «Только мои запросы» и сохраняем кадр страницы с метками (куда бот будет нажимать)
        grab.frame()?.let { f ->
            val cb = Profile.myRequestsTap(f)
            val marks = ArrayList<Pair<String, Pt>>()
            Profile.orderTap(f)?.let { marks.add("order" to it) }
            Profile.actionTap(f)?.let { marks.add("action" to it) }
            if (cb != null) marks.add("checkbox" to cb)
            DebugLog.saveFrame(f, "page", marks)
        }

        // проверяем, что цифры цены реально распознаются — раньше калибровка этого
        // не делала и могла бы написать «пройдена», даже если OCR не читает цену вообще
        var priceOk = false
        var priceFrame: Frame? = null
        var lastRr: Rect? = null
        var lastLr: Rect? = null
        var noteR = ""
        var noteL = ""
        val priceEnd = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < priceEnd) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                Profile.scanBlue(f, labelOcr)
                val rr = Profile.requestPriceRegion(f)
                val lr = Profile.lotPriceRegion(f)
                if (rr != null) {
                    val a = ocr.readPrice(f, rr)
                    noteR = ocr.lastNote
                    val b = if (lr != null) ocr.readPrice(f, lr) else null
                    noteL = if (lr != null) ocr.lastNote else "кнопка лота не видна (не обязательна)"
                    priceFrame = f; lastRr = rr; lastLr = lr
                    if (a != null && (lr == null || b != null)) { priceOk = true; break }
                }
            }
            delay(60)
        }
        if (!priceOk) {
            log("Кнопки найдены, но цена не читается — проверь «Распознавание цен» в Подготовке. Подробности: «Журнал отладки»")
            DebugLog.add("=== ДИАГНОСТИКА: цена не читается ===\nOCR готов=${ocr.ready}\nобласть запроса $lastRr → $noteR\nобласть лота $lastLr → $noteL")
            priceFrame?.let { DebugLog.saveFrame(it) }
            return false
        }
        log("Цена читается ✓ проверяю галочку и окно запроса…")
        if (!calibrateCheckbox()) return false

        val order = grab.frame()?.let { Profile.orderTap(it) }
        if (order == null) {
            log("Калибровка: не удалось нажать «Заказать» для пробного открытия окна")
            DebugLog.add("ДИАГНОСТИКА: перед пробным открытием окна нет кадра или кнопки «Заказать» (orderBand=${Profile.orderBand})")
            return false
        }
        Profile.resetDialogCache()
        tap(order)
        // Снимаем раскладку окна ОДИН раз: берём самую полную (самую большую) кнопку окна за время появления,
        // а когда она перестала расти — фиксируем координаты, которыми дальше жмём без поиска
        var dialogOk = false
        var bestArea = 0
        var lastGrowthAt = 0L
        val dialogEnd = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < dialogEnd) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                val band = Profile.scanDialogBand(f)
                if (band != null) {
                    val area = band.w * band.h
                    if (area > bestArea * 1.03) {
                        bestArea = area
                        lastGrowthAt = System.currentTimeMillis()
                        Profile.setDialogLayout(f, band)
                    }
                }
                if (bestArea > 0 && (System.currentTimeMillis() - lastGrowthAt > 250 || Profile.isKeyboard(f))) {
                    dialogOk = true
                    break
                }
            }
            delay(15)
        }
        if (dialogOk) {
            DebugLog.add("Окно запроса: ${Profile.dialogLayout?.info}")
            grab.frame()?.let { DebugLog.saveFrame(it, "dialog", Profile.dialogMarks()) }
        }
        if (!dialogOk) {
            // кадр снимаем ДО закрытия окна, чтобы видеть, что было на экране
            grab.frame()?.let { f ->
                DebugLog.add("=== ДИАГНОСТИКА: в окне запроса не найдена кнопка «Заказать» ===\n" + Profile.diagnoseDialog(f, labelOcr))
                DebugLog.saveFrame(f)
            }
        }
        if (!dialogOk) {
            closeDialog()
            log("Не нашёл кнопку в окне запроса — проверь вручную и перезапусти. Подробности: «Журнал отладки»")
            return false
        }
        if (!calibrateCancel()) return false
        log("Калибровка пройдена ✓ все координаты запомнены, работаю по ним")
        return true
    }

    /**
     * Полный цикл на живой игре: вводим пробную цену (она заведомо ниже любого лота — фулпрайса не будет), подтверждаем,
     * ждём, пока появится «Отмена», запоминаем её место и область цены лота, ждём заданное время и нажимаем «Отмена».
     * Дальше бот работает по этим координатам.
     */
    /**
     * Нажимает галочку «Только мои запросы» дважды с проверкой по двум кадрам и запоминает её координаты.
     * Не нашлась / нажатие попало не туда — галочка отключается, калибровка продолжается без неё.
     * false — только если страница потеряна (открылся осмотр) и вернуться не удалось.
     */
    private suspend fun calibrateCheckbox(): Boolean {
        val f = grab.frame() ?: return true
        val cb = Profile.myRequestsTap(f)
        if (cb == null) {
            checkboxOff = true
            log("Калибровка: галочка «Только мои запросы» не найдена по картинке — работаю без неё")
            return true
        }
        val r = ((Profile.orderBand?.w ?: 200) * 0.12f).toInt().coerceAtLeast(12)
        if (toggleMyRequestsTwice(cb, r)) {
            delay(150)
            log("Калибровка: галочка «Только мои запросы» нажата дважды ✓ (${cb.x},${cb.y}) запомнена")
            return true
        }
        checkboxOff = true
        log("Калибровка: галочка не сработала — дальше без неё")
        if (!waitFor(900) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) {
            recoverScreen()
            if (!waitFor(2500) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) {
                log("Калибровка: после нажатия по галочке страница не вернулась — открой страницу предмета и запусти заново")
                return false
            }
        }
        return true
    }

    private suspend fun calibrateCancel(): Boolean {
        val lay = Profile.dialogLayout ?: return false
        val price = fmt(CALIB_PRICE)
        log("Калибровка: ставлю пробный запрос $price и ищу «Отмена»…")
        quickTap(lay.priceTap)
        if (!waitFor(1500) { Profile.isKeyboard(it) }) {
            log("Калибровка: поле цены не открылось"); closeDialog(); return false
        }
        delay(40)
        if (!typeText(price)) {
            log("Калибровка: не удалось ввести цену — выбери клавиатуру Scriptonit по умолчанию"); closeDialog(); return false
        }
        delay(150)
        grab.frame()?.let { f ->
            val c = Profile.liveClose(f)
            DebugLog.add(if (c != null) "Окно с клавиатурой: крестик ${c.x},${c.y} (без клавиатуры ${lay.closeTap.x},${lay.closeTap.y})"
                         else "Окно с клавиатурой: крестик по живому кадру не найден")
            DebugLog.saveFrame(f, "dialog_kb", Profile.dialogMarks())
        }
        if (!closeKeyboard()) { log("Калибровка: клавиатура не закрылась"); closeDialog(); return false }
        if (!waitFor(900) { Profile.dialogOpenStrict(it) }) {
            log("Калибровка: окно запроса пропало — пробный запрос не ставлю"); closeDialog(); return false
        }
        val confirm = grab.frame()?.let { Profile.dialogConfirmTap(it, labelOcr) }
        if (confirm == null) { closeDialog(); return false }
        tap(confirm)

        // «Отмена» появляется только когда запрос реально создан
        var cancelPt: Pt? = null
        val end = System.currentTimeMillis() + 6000
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (Profile.isPage(f, labelOcr)) {
                    Profile.scanBlue(f, labelOcr)
                    val c = Profile.cancelTap(f)
                    if (c != null && Profile.cancelBand != null) { cancelPt = c; break }
                }
            }
            delay(40)
        }
        val cp = cancelPt
        val cb = Profile.cancelBand
        if (cp == null || cb == null) {
            log("Калибровка: после пробного запроса кнопка «Отмена» не появилась. Если запрос $price создался — отмени его вручную. Подробности: «Журнал отладки»")
            grab.frame()?.let { DebugLog.saveFrame(it) }
            return false
        }
        Profile.storeCancel(cb)
        Profile.storeLot()
        grab.frame()?.let { DebugLog.saveFrame(it, "cancel", listOf("cancel" to cp)) }
        val wait = cfg.cancelDelayMs.coerceIn(800, 5000)
        log("Калибровка: «Отмена» найдена ✓ нажму через ${wait / 1000.0} с")
        DebugLog.add("Запомнено: Отмена ${cp.x},${cp.y}; область цены лота ${Profile.lotPriceRegion(grab.frame() ?: return false)}")
        delay(wait)
        for (attempt in 1..3) {
            tap(cp)
            if (waitFor(1800) { Profile.pageVisibleFast(it) && !Profile.cancelPresent(it) }) {
                DebugLog.add("Калибровка: пробный запрос отменён с попытки $attempt")
                return true
            }
        }
        log("Калибровка: не смог отменить пробный запрос $price — отмени вручную и перезапусти")
        return false
    }

    suspend fun run() {
        Profile.reset()
        DebugLog.add("=== Запуск бота: $cfg ===")
        val start = System.currentTimeMillis()
        val limitMs = cfg.maxMinutes * 60_000L
        var screen = Screen.UNKNOWN
        var lost = 0
        var backStreak = 0
        var unrecSince = 0L
        if (!calibrate()) return

        while (true) {
            yield()
            if (System.currentTimeMillis() - start >= limitMs) { log("Время работы вышло"); break }
            if (bids >= cfg.maxBids) { log("Лимит ставок: $bids"); break }

            val f = grab.frame()
            if (f != null) {
                track(f)
                screen = screenOf(f)
            }

            when (screen) {
                Screen.KEYBOARD -> {
                    lost = 0
                    backStreak = 0
                    unrecSince = 0L
                    if (inHold) {
                        holdTick(f)
                    } else if (f != null && Profile.isPage(f, labelOcr)) {
                        // окно уже закрыто, клавиатура ещё «доживает» — это уже страница, повторный выход
                        // дал бы лишний тап по ней
                        pageTick()
                    } else {
                        exitHold(); needRefresh = true
                    }
                }
                Screen.PAGE -> {
                    lost = 0
                    backStreak = 0
                    unrecSince = 0L
                    unknownBacks = 0
                    pageTick()
                }
                Screen.DIALOG -> {
                    // неожиданное окно (не мы его открывали) — закрываем и пробуем снова с чистой страницы
                    lost = 0
                    inHold = false
                    unexpectedScreens++
                    if (unexpectedScreens == 1 && f != null) {
                        DebugLog.add("=== Экран не распознан как страница/поле ввода (первый раз) — разбираюсь ===\n" + Profile.diagnose(f, labelOcr))
                        DebugLog.saveFrame(f)
                    } else if (unexpectedScreens % 25 == 0) {
                        DebugLog.add("Экран не распознан как страница/поле ввода, раз №$unexpectedScreens")
                    }
                    val nowMs = System.currentTimeMillis()
                    if (unrecSince == 0L) unrecSince = nowMs
                    if (nowMs - unrecSince > 25_000) {
                        log("Не узнаю экран 25 секунд и не могу вернуться — остановился. Открой страницу предмета и запусти заново")
                        break
                    }
                    recoverScreen()
                }
                Screen.UNKNOWN -> {
                    lost++
                    if (lost == 200) DebugLog.add("Кадры экрана не приходят уже ~3 секунды (grab.frame()==null)")
                    if (lost > 400) { log("Открой страницу предмета в маркете"); break }
                    delay(15)
                }
            }
            delay(4)
        }
    }
}
