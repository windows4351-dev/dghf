package com.scriptonit.shop

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Rect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.util.Locale
import kotlin.math.abs

data class BotConfig(
    val min: Double,
    val max: Double,
    val step: Double,
    val gap: Double,
    val cancelDelayMs: Long,
    val refreshMs: Long,
    val maxMinutes: Int,
    val maxBids: Int,
    val aggressive: Boolean,
    val matchEqual: Boolean
)

object BotPrefs {
    private const val P = "bot"

    fun raw(c: Context, key: String, def: String): String =
        c.getSharedPreferences(P, Context.MODE_PRIVATE).getString(key, null) ?: def

    fun save(c: Context, values: Map<String, String>) {
        val e = c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }

    fun load(c: Context): BotConfig {
        fun d(k: String, def: String) = raw(c, k, def).replace(',', '.').toDoubleOrNull() ?: def.toDouble()
        return BotConfig(
            min = d("min", "10"),
            max = d("max", "99999"),
            step = 0.01, // фиксированные: режимы «Агрессивный» и «Сбалансированный» сами решают, сколько ставить
            gap = 0.01,
            cancelDelayMs = (d("cancel", "2") * 1000).toLong().coerceAtLeast(0),
            refreshMs = (d("refresh", "5") * 1000).toLong().coerceAtLeast(2000),
            maxMinutes = d("minutes", "119").toInt().coerceAtLeast(1),
            maxBids = d("bids", "300").toInt().coerceAtLeast(1),
            aggressive = raw(c, "aggr", "0") == "1",
            matchEqual = true
        )
    }
}

/**
 * Встроенная логика перебива запросов. Координаты кнопок и областей цен определяются
 * динамически по цвету (Profile/AnchorScan), а не по фиксированным пикселям, поэтому
 * работает на разных экранах и раскладках без ручной калибровки под каждое устройство.
 *
 * Цикл: на странице предмета ищем кнопку «Заказать» и первую синюю кнопку под ней —
 * это «Отмена» (если наш запрос уже стоит) или «Купить» первого лота (если нет).
 * Читаем цену лота и верхнего запроса, запоминаем их, открываем поле ввода и остаёмся
 * там. Пока запрос не растёт, ничего не делаем. Как только он вырос — мгновенно ставим
 * цену (см. chooseBid), подтверждаем и через cancelDelayMs отменяем свой запрос.
 * Раз в refreshMs выходим на страницу и заново запоминаем лот и запрос.
 */
class MarketBot(
    private val svc: ClickService,
    private val grab: ScreenGrabber,
    private val ocr: Ocr,
    private val cfg: BotConfig,
    private val onBid: () -> Unit,
    private val log: (String) -> Unit,
    private val labelOcr: LabelOcr? = null
) {
    private enum class Screen { PAGE, DIALOG, KEYBOARD, UNKNOWN }

    private var fw = 1
    private var fh = 1

    private var lot: Double? = null
    private var req: Double? = null
    private var baseReq: Double? = null
    private var refreshedAt = 0L
    private var needRefresh = true
    private var firstRefresh = true
    private var inHold = false
    private var lastHash = 0
    private var lastOcrAt = 0L
    private var lowCount = 0
    private var bids = 0
    private var noActionCount = 0
    private var unexpectedScreens = 0

    // Базовая цена в окне запроса (сравнение «окно с окном», а не «окно со страницей»: сквозь затемнение
    // цифры читаются иначе, из-за чего раньше бот видел «рост» запроса при каждом обновлении и ставил сам)
    private var holdBase: Double? = null
    private var holdPending: Double? = null
    private var downVal: Double? = null
    private var downCount = 0
    private var lastOwnBid: Double? = null

    // Галочка «Только мои запросы»: после первого сбоя больше не нажимаем (иначе на нестандартных экранах
    // каждый цикл тапал бы по странице и открывал осмотр оружия)
    private var checkboxOff = false

    private fun isOwn(r: Double): Boolean {
        val o = lastOwnBid ?: return false
        if (abs(o - r) < 0.005) return true
        lastOwnBid = null // в списке уже другая цена — наш запрос исчез
        return false
    }

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun round2(v: Double) = Math.round(v * 100.0) / 100.0

    private fun track(f: Frame) {
        fw = f.w
        fh = f.h
    }

    /** Быстрый тап без пауз после: короткое касание, подтверждение результата — по картинке. */
    private suspend fun quickTap(p: Pt) {
        if (!tapAllowed(p)) return
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), 30)
    }

    /**
     * Дважды переключает галочку «Только мои запросы» (список перечитывается) и проверяет по картинке, что
     * каждое нажатие подействовало: если страница ещё не принимает касания, нажатие повторяется.
     * Ничего не ждёт «на всякий случай» — скорость определяется самой игрой, а не фиксированными паузами,
     * поэтому на телефоне и на ПК получается одинаково быстро.
     */
    private suspend fun toggleMyRequestsTwice(cb: Pt, r: Int): Boolean {
        val rect = Rect(cb.x - r, cb.y - r, cb.x + r, cb.y + r)
        fun hashNow(): Int? = grab.frame()?.let { Profile.regionHash(it, rect) }
        var prev = hashNow()
        if (prev == null) {
            quickTap(cb); delay(100); quickTap(cb); delay(150)
            return true
        }
        val t0 = System.currentTimeMillis()
        var failed = false
        for (toggle in 1..2) {
            var changed = false
            for (attempt in 1..3) {
                quickTap(cb)
                // если после нажатия страница пропала (открылся осмотр предмета) — это не галочка: больше не жмём
                if (!waitFor(200) { Profile.pageVisibleFast(it) }) {
                    DebugLog.add("Галочка: после нажатия в (${cb.x},${cb.y}) страница не видна — вероятно открылся осмотр. Галочку отключаю до конца запуска")
                    grab.frame()?.let { DebugLog.saveFrame(it) }
                    return false
                }
                val end = System.currentTimeMillis() + 220
                while (System.currentTimeMillis() < end) {
                    val h = hashNow()
                    if (h != null && h != prev) { prev = h; changed = true; break }
                    delay(8)
                }
                if (changed) {
                    // короткая пауза, пока галочка не перестанет меняться (не дольше 80 мс)
                    var same = 0
                    val settleEnd = System.currentTimeMillis() + 40
                    while (same < 1 && System.currentTimeMillis() < settleEnd) {
                        delay(8)
                        val h = hashNow() ?: continue
                        if (h == prev) same++ else { prev = h; same = 0 }
                    }
                    break
                }
                DebugLog.add("Галочка: нажатие $toggle.$attempt не подействовало за 220 мс — повторяю")
            }
            if (!changed) {
                failed = true
                DebugLog.add("Галочка «Только мои запросы» не реагирует на нажатие (точка ${cb.x},${cb.y}); ${Profile.checkboxInfo}")
            }
        }
        if (failed) grab.frame()?.let { DebugLog.saveFrame(it) }
        delay(60)
        DebugLog.add("Галочка: два переключения за ${System.currentTimeMillis() - t0} мс")
        return !failed
    }

    private fun settleHash(f: Frame): Int {
        var h = 17
        val x0 = (f.w * 0.62f).toInt()
        val y1 = (f.h * 0.32f).toInt()
        var y = 0
        while (y < y1) {
            var x = x0
            while (x < f.w) {
                val c = f.bmp.getPixel(x, y)
                h = h * 31 + (((android.graphics.Color.red(c) + android.graphics.Color.green(c) + android.graphics.Color.blue(c)) / 3) shr 3)
                x += 12
            }
            y += 12
        }
        return h
    }

    /** Ждёт, пока правая верхняя часть экрана перестанет меняться (закончится анимация окна). */
    private suspend fun waitSettled(maxMs: Long = 150) {
        val end = System.currentTimeMillis() + maxMs
        var last = 0
        var haveLast = false
        var same = 0
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                val h = settleHash(f)
                if (haveLast && h == last) {
                    same++
                    if (same >= 2) return
                } else {
                    same = 0
                }
                last = h
                haveLast = true
            }
            delay(8)
        }
    }

    private fun screenOf(f: Frame) = when {
        Profile.isKeyboard(f) -> Screen.KEYBOARD
        Profile.isPage(f, labelOcr) -> Screen.PAGE
        else -> Screen.DIALOG
    }

    /**
     * Защита от случайных нажатий: ни одна наша кнопка не лежит в левой панели предмета («Осмотреть», «Продать»,
     * график) — это ≈27% ширины слева, при любых пропорциях экрана. Любое нажатие туда — ошибка расчёта.
     */
    private fun tapAllowed(p: Pt, allowLeft: Boolean = false): Boolean {
        if (p.x < 0 || p.y < 0 || (fw > 0 && p.x >= fw) || (fh > 0 && p.y >= fh)) {
            DebugLog.add("Тап мимо экрана (${p.x},${p.y}) — пропущен")
            return false
        }
        if (!allowLeft && fw > 0 && p.x < fw * 0.27f) {
            DebugLog.add("Тап в левую панель (${p.x},${p.y}) отклонён — это не наша кнопка")
            return false
        }
        return true
    }

    private suspend fun tap(p: Pt, allowLeft: Boolean = false) {
        if (!tapAllowed(p, allowLeft)) return
        svc.gesture(p.x.toFloat(), p.y.toFloat(), p.x.toFloat(), p.y.toFloat(), 30)
        delay(15)
    }

    private suspend fun waitFor(timeoutMs: Long, cond: (Frame) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                if (cond(f)) return true
            }
            delay(8)
        }
        return false
    }

    private suspend fun typeText(text: String): Boolean =
        withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.replaceText(text) == true }

    private suspend fun imeDone() {
        val ok = withContext(Dispatchers.Main) { ScriptoKeyboardService.instance?.done() == true }
        if (!ok) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    /** Закрывает поле ввода через действие IME; если поле его игнорирует, жмёт кнопку в правом краю найденной белой панели. */
    private suspend fun closeKeyboard(): Boolean {
        imeDone()
        if (waitFor(600) { !Profile.isKeyboard(it) }) return true
        val f = grab.frame() ?: return false
        track(f)
        val bar = Profile.inputBar(f)
        if (bar == null) {
            // белой панели нет (наша клавиатура) — одно «Назад» закрывает именно клавиатуру
            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            return waitFor(700) { !Profile.isKeyboard(it) }
        }
        val (rowY, _, right) = bar
        tap(Pt((right - (right - bar.second) * 0.06f).toInt(), rowY))
        return waitFor(700) { !Profile.isKeyboard(it) }
    }

    /** Открывает окно, находит в нём кнопку «Заказать» по цвету и тапает поле цены как смещение от неё. */
    private suspend fun enterHold(price: Double): Boolean {
        val lay = Profile.dialogLayout
        if (lay == null) {
            DebugLog.add("Ввод цены: раскладка окна запроса не снята при калибровке")
            return false
        }
        val tEnter = System.currentTimeMillis()
        val order = Profile.orderTap(grab.frame() ?: return false) ?: return false
        quickTap(order)
        // ждём, пока окно откроется до конца (идёт анимация появления): дальше — жёсткие координаты из калибровки
        if (!waitFor(1500) { Profile.dialogReady(it) }) {
            DebugLog.add("Ввод цены: окно запроса не открылось за 1.5 с после нажатия «Заказать»")
            grab.frame()?.let { DebugLog.saveFrame(it, "enter", Profile.dialogMarks()) }
            return false
        }
        val tOpen = System.currentTimeMillis()
        val priceTap = lay.priceTap
        if (grab.frame()?.let { Profile.pageVisibleFast(it) } == true) {
            DebugLog.add("Ввод цены: страница ещё не затемнена — тап по полю цены отменён (попал бы в список)")
            return false
        }
        quickTap(priceTap)
        if (!waitFor(1500) { Profile.isKeyboard(it) }) {
            DebugLog.add("Ввод цены: поле не открылось за 1.5 с после тапа $priceTap (клавиатура Scriptonit показана=${ScriptoKeyboardService.instance?.isInputViewShown}, службы=${ScriptoKeyboardService.instance != null})")
            grab.frame()?.let { DebugLog.saveFrame(it, "enter", Profile.dialogMarks()) }
            return false
        }
        val tKb = System.currentTimeMillis()
        delay(30)
        if (!typeText(fmt(price))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return false
        }
        DebugLog.add("Вход в окно запроса: открытие ${tOpen - tEnter} мс, поле ${tKb - tOpen} мс, ввод ${System.currentTimeMillis() - tKb} мс")
        inHold = true
        lastHash = 0
        lastOcrAt = 0
        holdBase = null
        holdPending = null
        downVal = null
        downCount = 0
        return true
    }

    /**
     * Закрывает окно запроса крестиком (по логам касание пустого места эту игру не закрывает).
     * Положение крестика берётся из уже известного положения кнопки «Заказать» в окне — без поиска по кадру.
     * Если не помогло — «Назад» только для клавиатуры, потом ещё раз крестик.
     */
    private suspend fun closeDialog() {
        if (grab.frame()?.let { Profile.isKeyboard(it) && !Profile.pageVisibleFast(it) } == true) closeKeyboard()
        for (attempt in 0 until 2) {
            val f = grab.frame()
            if (f != null && (Profile.pageVisibleFast(f) || Profile.isPage(f, labelOcr))) return
            // крестик нажимаем ТОЛЬКО если окно точно открыто: иначе нажатие попадёт в строку лота страницы
            if (f == null || !Profile.dialogOpenStrict(f)) {
                if (waitFor(400) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) return
                continue
            }
            val close = Profile.dialogCloseTap(f, labelOcr) ?: break
            tap(close)
            if (waitFor(700) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) return
        }
        waitFor(500) { Profile.isPage(it, labelOcr) }
    }

    /**
     * Быстрый выход из окна запроса: сразу крестик (без пауз), дальше только ждём, пока откроется страница.
     * Повторное нажатие — лишь когда окно ТОЧНО всё ещё открыто (Profile.dialogOpenStrict); раньше повтор по
     * «страница ещё не узнана» попадал по строке лота на странице и открывал осмотр предмета.
     */
    private suspend fun exitHold() {
        val t0 = System.currentTimeMillis()
        val f0 = grab.frame()
        if (f0 != null && (Profile.pageVisibleFast(f0) || Profile.isPage(f0))) {
            inHold = false
            return // окно уже закрыто — жать крестик нельзя: точка попала бы в строку лота и открыла осмотр
        }
        val close = f0?.takeIf { Profile.dialogOpenStrict(it) }?.let { Profile.dialogCloseTap(it) }
        if (close != null) {
            quickTap(close)
            var taps = 1
            var nextTapAt = System.currentTimeMillis() + 320
            while (System.currentTimeMillis() - t0 < 1600) {
                yield()
                val f = grab.frame()
                if (f != null) {
                    track(f)
                    if (Profile.pageVisibleFast(f) || Profile.isPage(f)) {
                        inHold = false
                        DebugLog.add("Выход из окна запроса: ${System.currentTimeMillis() - t0} мс ($taps нажатий)")
                        return
                    }
                    if (taps < 3 && System.currentTimeMillis() >= nextTapAt && Profile.dialogOpenStrict(f)) {
                        quickTap(close)
                        taps++
                        nextTapAt = System.currentTimeMillis() + 350
                    }
                }
                delay(6)
            }
        }
        inHold = false
        DebugLog.add("Выход из окна запроса: страница не появилась за ${System.currentTimeMillis() - t0} мс — дальше разбирается основной цикл")
    }

    private var unknownBacks = 0
    private var unknownSaved = false

    /**
     * Экран не страница, не окно запроса и не клавиатура: осмотр предмета (случайно открывшийся), список маркета,
     * идущая анимация. Крестик здесь не жмём. Порядок: дать странице проявиться → «Назад» (не больше 2 раз подряд) →
     * стрелка «назад» слева сверху (на экране осмотра она в левом верхнем углу).
     */
    private suspend fun recoverScreen() {
        val f = grab.frame() ?: return
        if (Profile.dialogOpenStrict(f)) { closeDialog(); return }
        if (waitFor(500) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) { unknownBacks = 0; return }
        val f2 = grab.frame() ?: return
        if (Profile.dialogOpenStrict(f2)) { closeDialog(); return }
        if (!unknownSaved) {
            unknownSaved = true
            DebugLog.saveFrame(f2, "unknown", listOf("arrow" to Profile.inspectBackArrow(f2)))
        }
        if (unknownBacks >= 2) {
            DebugLog.add("Неизвестный экран держится после «Назад» — жду")
            delay(300)
            return
        }
        unknownBacks++
        DebugLog.add("Неизвестный экран (осмотр предмета?) — «Назад» №$unknownBacks")
        svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        if (waitFor(900) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) { unknownBacks = 0; return }
        val f3 = grab.frame() ?: return
        val arrow = Profile.inspectBackArrow(f3)
        DebugLog.add("«Назад» не помог — стрелка слева сверху (${arrow.x},${arrow.y})")
        tap(arrow, allowLeft = true)
        if (waitFor(900) { Profile.pageVisibleFast(it) || Profile.isPage(it, labelOcr) }) unknownBacks = 0
    }

    /** Одно полное обновление: страница, галочка «Мои запросы», чтение цен через найденные кнопки. */
    private suspend fun refreshPage(): Boolean {
        val refreshT0 = System.currentTimeMillis()
        // галочка «Только мои запросы»: нажать дважды, чтобы заставить список перечитаться —
        // координата находится автоматически, от уже найденной кнопки «Заказать»
        if (!firstRefresh && !checkboxOff) {
            // после быстрого закрытия окна страница ещё проявляется из затемнения — нажатия в это время
            // проглатываются, поэтому ждём, пока верхняя часть кадра перестанет меняться (обычно 30–100 мс)
            waitSettled()
            val f0 = grab.frame()
            if (f0 != null) {
                track(f0)
                val cb = Profile.myRequestsTap(f0)
                if (cb != null) {
                    if (!toggleMyRequestsTwice(cb, ((Profile.orderBand?.w ?: 200) * 0.12f).toInt().coerceAtLeast(12))) {
                        checkboxOff = true
                        log("Галочка «Только мои запросы» не сработала на этом экране — дальше работаю без неё")
                    }
                } else {
                    checkboxOff = true
                    DebugLog.add("Галочка «Только мои запросы» не найдена по картинке — дальше работаю без неё (orderBand=${Profile.orderBand})")
                }
            }
        }
        var prevR: Double? = null
        var prevL: Double? = null
        var prevHR = 0
        var prevHL = 0
        var noPriceCount = 0
        val end = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < end) {
            yield()
            val f = grab.frame()
            if (f == null) { delay(8); continue }
            track(f)
            if (!Profile.isPage(f, labelOcr)) { delay(20); continue }
            val rr = Profile.requestPriceRegion(f)
            val lr = Profile.lotPriceRegion(f)
            if (rr == null || lr == null) {
                if (rr != null && lr == null) {
                    noActionCount++
                    if (noActionCount == 40) {
                        log("Не вижу синюю кнопку под «Заказать» (ни «Купить», ни «Отмена») — список предложений пуст?")
                        DebugLog.add("=== ДИАГНОСТИКА: синяя кнопка не найдена во время работы ===\n" + Profile.diagnose(f, labelOcr))
                        DebugLog.saveFrame(f)
                    }
                } else {
                    noActionCount = 0
                }
                delay(20); continue
            }
            noActionCount = 0
            val hR = Profile.regionHash(f, rr)
            val hL = Profile.regionHash(f, lr)
            if (prevR != null && prevL != null && hR == prevHR && hL == prevHL) {
                // картинка с обеими ценами не изменилась с прошлой итерации — те же цифры, второе распознавание не нужно
                req = prevR
                lot = prevL
                refreshedAt = System.currentTimeMillis()
                log("Лот ${fmt(prevL)} · запрос ${fmt(prevR)}")
                DebugLog.add("обновление страницы: ${System.currentTimeMillis() - refreshT0} мс")
                return true
            }
            val r = ocr.readPrice(f, rr)
            val noteR = ocr.lastNote
            val l = ocr.readPrice(f, lr)
            val noteL = ocr.lastNote
            if (r == null || l == null) {
                noPriceCount++
                // примерно раз в секунду при затяжном сбое — не на каждую неудачную попытку
                if (noPriceCount == 45) {
                    log("Кнопки на месте, но цена не читается (запрос=${r != null}, лот=${l != null})")
                    DebugLog.add("=== ДИАГНОСТИКА: цена не читается во время работы ===\nобласть запроса $rr → $noteR\nобласть лота $lr → $noteL")
                    DebugLog.saveFrame(f)
                }
            } else {
                noPriceCount = 0
            }
            if (r != null && l != null) {
                if (prevR != null && prevL != null && abs(prevR - r) < 0.001 && abs(prevL - l) < 0.001) {
                    req = r
                    lot = l
                    refreshedAt = System.currentTimeMillis()
                    log("Лот ${fmt(l)} · запрос ${fmt(r)}")
                    DebugLog.add("обновление страницы: ${System.currentTimeMillis() - refreshT0} мс")
                    return true
                }
                prevR = r
                prevL = l
                prevHR = hR
                prevHL = hL
            }
            delay(20)
        }
        return false
    }

    /**
     * Цена ставки. Потолок = запомненный лот минус gap, поэтому ставка не может
     * сравняться с лотом или превысить его (защита от фуллпрайса).
     * Обычно: r + шаг. Если на шаг перебить уже нельзя, а r сам ниже потолка —
     * при включённом «Нельзя перебить на шаг» ставим ровно r (тот же запрос).
     * «Агрессивно» сразу ставит на потолок (копейка ниже лота).
     */
    private fun chooseBid(r: Double): Double? {
        val l = lot ?: return null
        if (l < cfg.min || l > cfg.max) return null
        val ceiling = round2(l - cfg.gap)
        val outbid = round2(r + cfg.step)
        val bid = when {
            outbid <= ceiling -> if (cfg.aggressive) ceiling else outbid
            // перебить на шаг нельзя (упрёмся в лот), но под лотом ещё есть место:
            // ставим на копейку ниже первого лота, а не пропускаем
            round2(r) <= ceiling -> ceiling
            else -> return null
        }
        return if (bid > cfg.max) null else bid
    }

    /** Почему chooseBid отказался ставить — чтобы на панели была настоящая причина, а не всегда «вплотную». */
    private fun skipReason(r: Double): String {
        val l = lot ?: return "лот не прочитан"
        return when {
            l < cfg.min -> "лот ${fmt(l)} ниже «Цена от» (${fmt(cfg.min)}) — измени в настройках приложения"
            l > cfg.max -> "лот ${fmt(l)} выше «Цена до» (${fmt(cfg.max)}) — подними «Цена до» в настройках приложения"
            else -> "запрос ${fmt(r)} уже выше потолка ${fmt(round2(l - cfg.gap))} (лот ${fmt(l)} минус gap)"
        }
    }

    private suspend fun bidFromHold(bid: Double) {
        inHold = false
        needRefresh = true
        baseReq = null
        holdBase = null
        lastOwnBid = bid
        if (!typeText(fmt(bid))) {
            log("Выбери клавиатуру Scriptonit по умолчанию")
            return
        }
        if (!closeKeyboard()) return
        if (!waitFor(800) { Profile.isDialog(it) }) return
        // подтверждаем только если окно точно открыто: иначе нажатие по центру экрана попало бы в строку лота
        if (!waitFor(500) { Profile.dialogOpenStrict(it) }) { log("Окно запроса не открыто — подтверждение отменено"); return }
        val confirm = grab.frame()?.let { Profile.dialogConfirmTap(it, labelOcr) }
        if (confirm != null) tap(confirm) else { log("Не нашёл кнопку «Заказать» в окне"); return }
        bids++
        onBid()
        log("#$bids: ${fmt(bid)} G · лот ${fmt(lot ?: 0.0)}")
        if (cfg.cancelDelayMs > 0) {
            delay(cfg.cancelDelayMs)
            cancelOwnRequest(bid)
        }
        waitFor(1500) { Profile.isPage(it, labelOcr) }
    }

    /**
     * Нажимает «Отмена» на нашей строке запроса. Если после этого в той же строке
     * всё ещё видна НАША цена bid — значит отмена не прошла (лаг сети, промах),
     * пробует ещё раз, чтобы бот не принял собственный незакрытый запрос за лот
     * и не начал бы торговаться сам с собой.
     */
    private suspend fun cancelOwnRequest(bid: Double, attempt: Int = 0) {
        if (attempt >= 3) { log("Не удалось отменить запрос $attempt-й попыткой, проверь вручную"); return }
        val f0 = grab.frame() ?: return
        track(f0)
        val action = Profile.actionTap(f0) ?: return
        // Защита от покупки лота: если запрос не создался, первая синяя кнопка — «Купить» лота, а не наша «Отмена».
        // Нажимаем, только если в строке наша цена или надпись «Отмена»
        var own = false
        val lotRect = Profile.lotPriceRegion(f0)
        if (lotRect != null) {
            val p = ocr.readPrice(f0, lotRect)
            if (p != null && Math.abs(p - bid) < 0.005) own = true
        }
        val band = Profile.actionBand
        if (!own && band != null && labelOcr != null && labelOcr.ready && labelOcr.readLabel(f0, band).contains("ОТМЕН")) own = true
        if (!own) {
            DebugLog.add("Отмена не нажата: первая синяя кнопка не наша (цена в строке не равна ставке ${fmt(bid)}, надпись не «Отмена») — защита от покупки лота")
            return
        }
        tap(action)
        delay(350)
        val f1 = grab.frame() ?: return
        track(f1)
        val lr = Profile.lotPriceRegion(f1) ?: return
        val still = ocr.readPrice(f1, lr)
        if (still != null && Math.abs(still - bid) < 0.001) {
            cancelOwnRequest(bid, attempt + 1)
        }
    }

    private suspend fun pageTick() {
        inHold = false
        val now = System.currentTimeMillis()
        if (needRefresh || now - refreshedAt >= cfg.refreshMs) {
            if (!refreshPage()) { delay(100); return }
            needRefresh = false
            firstRefresh = false
            val r = req ?: return
            val base = baseReq
            baseReq = r
            holdBase = null
            if (base != null && r > base + 0.001 && !isOwn(r)) {
                val bid = chooseBid(r)
                if (bid != null) {
                    if (enterHold(bid)) bidFromHold(bid)
                    return
                }
                log("Пропуск: ${skipReason(r)}")
            }
        }
        val r = baseReq ?: req ?: return
        val bid = chooseBid(r) ?: round2(r + cfg.step)
        if (!enterHold(bid)) delay(150)
    }

    private suspend fun holdTick(f: Frame?) {
        val now = System.currentTimeMillis()
        if (now - refreshedAt >= cfg.refreshMs) {
            exitHold()
            needRefresh = true
            return
        }
        if (f == null) return
        val region = Profile.requestPriceRegion(f) ?: return
        val hash = Profile.regionHash(f, region)
        if (hash == lastHash && now - lastOcrAt < 600) return
        lastHash = hash
        lastOcrAt = now
        val r = ocr.readPrice(f, region) ?: return
        val base = holdBase
        if (base == null) {
            // Первая цена в окне. Если она совпала со страницей — берём сразу; иначе нужны два одинаковых чтения подряд
            // (одно «кривое» распознавание раньше превращалось в ложный «перебив»)
            val pageR = baseReq
            val pend = holdPending
            if (pageR != null && abs(pageR - r) < 0.001) { holdBase = r; holdPending = null }
            else if (pend != null && abs(pend - r) < 0.001) { holdBase = r; holdPending = null }
            else holdPending = r
            return
        }
        if (r > base + 0.001) {
            // рост подтверждаем вторым чтением со свежего кадра — одиночный сбой распознавания не повод ставить
            if (!confirmRead(r)) return
            holdBase = r
            downVal = null; downCount = 0
            if (isOwn(r)) return
            val bid = chooseBid(r)
            if (bid != null) {
                bidFromHold(bid)
            } else {
                log("Пропуск: ${skipReason(r)}")
            }
        } else if (r < base - 0.001) {
            // снижение принимаем, только когда одно и то же новое значение прочитано два раза подряд
            if (downVal != null && abs(downVal!! - r) < 0.001) downCount++ else { downVal = r; downCount = 1 }
            if (downCount >= 2) { holdBase = r; downVal = null; downCount = 0 }
        } else {
            downVal = null; downCount = 0
        }
    }

    /** Перечитывает цену запроса со следующего кадра: true, если значение то же самое (рост настоящий). */
    private suspend fun confirmRead(r: Double): Boolean {
        delay(25)
        val f2 = grab.frame() ?: return false
        track(f2)
        val reg = Profile.requestPriceRegion(f2) ?: return false
        val r2 = ocr.readPrice(f2, reg) ?: return false
        val ok = abs(r2 - r) < 0.001
        if (!ok) DebugLog.add("Рост запроса не подтвердился повторным чтением (${fmt(r)} → ${fmt(r2)}) — ставку не делаю")
        return ok
    }


    /**
     * Перед началом торговли до 10 секунд ищет и проверяет все нужные кнопки:
     * сперва «Заказать» и «Купить»/«Отмена» на странице, затем один раз открывает
     * окно «Запрос на покупку», чтобы найти кнопку внутри него — и сразу закрывает
     * окно обратно, ничего не вводя и не отправляя. Торговля начинается только
     * после успешной проверки.
     */
    private suspend fun calibrate(): Boolean {
        log("Калибровка: ищу кнопки на странице…")
        val pageStart = System.currentTimeMillis()
        var pageOk = false
        var lastFrame: Frame? = null
        var framesSeen = 0
        while (System.currentTimeMillis() - pageStart < 10_000) {
            yield()
            val f = grab.frame()
            if (f != null) {
                framesSeen++
                lastFrame = f
                track(f)
                if (framesSeen == 1) DebugLog.add("Калибровка: первый кадр ${f.w}x${f.h}")
                if (Profile.isPage(f, labelOcr) && Profile.actionBand != null) { pageOk = true; break }
            }
            delay(60)
        }
        if (!pageOk) {
            log("Не нашёл кнопки «Заказать»/«Купить» — открой страницу предмета в маркете. Подробности: «Журнал отладки» в приложении")
            val ff = lastFrame
            if (ff == null) {
                DebugLog.add("ДИАГНОСТИКА: за 10 секунд не пришло ни одного кадра экрана (запись экрана не работает?)")
            } else {
                DebugLog.add("=== ДИАГНОСТИКА: не найдены кнопки страницы (кадров получено: $framesSeen) ===\n" + Profile.diagnose(ff, labelOcr))
                DebugLog.saveFrame(ff)
            }
            return false
        }
        DebugLog.add("Кнопки страницы: «Заказать»=${Profile.orderBand} синяя=${Profile.actionBand}")
        log("Кнопки страницы найдены ✓ проверяю, читается ли цена…")
        // сразу находим галочку «Только мои запросы» и сохраняем кадр страницы с метками (куда бот будет нажимать)
        grab.frame()?.let { f ->
            val cb = Profile.myRequestsTap(f)
            val marks = ArrayList<Pair<String, Pt>>()
            Profile.orderTap(f)?.let { marks.add("order" to it) }
            Profile.actionTap(f)?.let { marks.add("action" to it) }
            if (cb != null) marks.add("checkbox" to cb)
            DebugLog.saveFrame(f, "page", marks)
        }

        // проверяем, что цифры цены реально распознаются — раньше калибровка этого
        // не делала и могла бы написать «пройдена», даже если OCR не читает цену вообще
        var priceOk = false
        var priceFrame: Frame? = null
        var lastRr: Rect? = null
        var lastLr: Rect? = null
        var noteR = ""
        var noteL = ""
        val priceEnd = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < priceEnd) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                val rr = Profile.requestPriceRegion(f)
                val lr = Profile.lotPriceRegion(f)
                if (rr != null && lr != null) {
                    val a = ocr.readPrice(f, rr)
                    noteR = ocr.lastNote
                    val b = ocr.readPrice(f, lr)
                    noteL = ocr.lastNote
                    priceFrame = f; lastRr = rr; lastLr = lr
                    if (a != null && b != null) { priceOk = true; break }
                }
            }
            delay(60)
        }
        if (!priceOk) {
            log("Кнопки найдены, но цена не читается — проверь «Распознавание цен» в Подготовке. Подробности: «Журнал отладки»")
            DebugLog.add("=== ДИАГНОСТИКА: цена не читается ===\nOCR готов=${ocr.ready}\nобласть запроса $lastRr → $noteR\nобласть лота $lastLr → $noteL")
            priceFrame?.let { DebugLog.saveFrame(it) }
            return false
        }
        log("Цена читается ✓ проверяю окно запроса…")

        val order = grab.frame()?.let { Profile.orderTap(it) }
        if (order == null) {
            log("Калибровка: не удалось нажать «Заказать» для пробного открытия окна")
            DebugLog.add("ДИАГНОСТИКА: перед пробным открытием окна нет кадра или кнопки «Заказать» (orderBand=${Profile.orderBand})")
            return false
        }
        Profile.resetDialogCache()
        tap(order)
        // Снимаем раскладку окна ОДИН раз: берём самую полную (самую большую) кнопку окна за время появления,
        // а когда она перестала расти — фиксируем координаты, которыми дальше жмём без поиска
        var dialogOk = false
        var bestArea = 0
        var lastGrowthAt = 0L
        val dialogEnd = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < dialogEnd) {
            yield()
            val f = grab.frame()
            if (f != null) {
                track(f)
                val band = Profile.scanDialogBand(f)
                if (band != null) {
                    val area = band.w * band.h
                    if (area > bestArea * 1.03) {
                        bestArea = area
                        lastGrowthAt = System.currentTimeMillis()
                        Profile.setDialogLayout(f, band)
                    }
                }
                if (bestArea > 0 && (System.currentTimeMillis() - lastGrowthAt > 250 || Profile.isKeyboard(f))) {
                    dialogOk = true
                    break
                }
            }
            delay(15)
        }
        if (dialogOk) {
            DebugLog.add("Окно запроса: ${Profile.dialogLayout?.info}")
            grab.frame()?.let { DebugLog.saveFrame(it, "dialog", Profile.dialogMarks()) }
        }
        if (!dialogOk) {
            // кадр снимаем ДО закрытия окна, чтобы видеть, что было на экране
            grab.frame()?.let { f ->
                DebugLog.add("=== ДИАГНОСТИКА: в окне запроса не найдена кнопка «Заказать» ===\n" + Profile.diagnoseDialog(f, labelOcr))
                DebugLog.saveFrame(f)
            }
        }
        // закрываем пробное окно — калибровка ничего не вводит и не отправляет
        closeDialog()

        if (!dialogOk) {
            log("Не нашёл кнопку в окне запроса — проверь вручную и перезапусти. Подробности: «Журнал отладки»")
            return false
        }
        log("Калибровка пройдена ✓ начинаю торговать")
        return true
    }

    suspend fun run() {
        Profile.reset()
        DebugLog.add("=== Запуск бота: $cfg ===")
        val start = System.currentTimeMillis()
        val limitMs = cfg.maxMinutes * 60_000L
        var screen = Screen.UNKNOWN
        var lost = 0
        var backStreak = 0
        if (!calibrate()) return

        while (true) {
            yield()
            if (System.currentTimeMillis() - start >= limitMs) { log("Время работы вышло"); break }
            if (bids >= cfg.maxBids) { log("Лимит ставок: $bids"); break }

            val f = grab.frame()
            if (f != null) {
                track(f)
                screen = screenOf(f)
            }

            when (screen) {
                Screen.KEYBOARD -> {
                    lost = 0
                    backStreak = 0
                    if (inHold) {
                        holdTick(f)
                    } else if (f != null && Profile.isPage(f, labelOcr)) {
                        // окно уже закрыто, клавиатура ещё «доживает» — это уже страница, повторный выход
                        // дал бы лишний тап по ней
                        pageTick()
                    } else {
                        exitHold(); needRefresh = true
                    }
                }
                Screen.PAGE -> {
                    lost = 0
                    backStreak = 0
                    unknownBacks = 0
                    pageTick()
                }
                Screen.DIALOG -> {
                    // неожиданное окно (не мы его открывали) — закрываем и пробуем снова с чистой страницы
                    lost = 0
                    inHold = false
                    unexpectedScreens++
                    if (unexpectedScreens == 1 && f != null) {
                        DebugLog.add("=== Экран не распознан как страница/поле ввода (первый раз) — разбираюсь ===\n" + Profile.diagnose(f, labelOcr))
                        DebugLog.saveFrame(f)
                    } else if (unexpectedScreens % 25 == 0) {
                        DebugLog.add("Экран не распознан как страница/поле ввода, раз №$unexpectedScreens")
                    }
                    backStreak++
                    if (backStreak > 6) {
                        log("Не узнаю экран и не могу вернуться — остановился. Открой страницу предмета и запусти заново")
                        break
                    }
                    recoverScreen()
                }
                Screen.UNKNOWN -> {
                    lost++
                    if (lost == 200) DebugLog.add("Кадры экрана не приходят уже ~3 секунды (grab.frame()==null)")
                    if (lost > 400) { log("Открой страницу предмета в маркете"); break }
                    delay(15)
                }
            }
            delay(4)
        }
    }
}
